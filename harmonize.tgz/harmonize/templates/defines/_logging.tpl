{{/*
dotnet Log Level
https://learn.microsoft.com/en-us/aspnet/core/fundamentals/logging/?view=aspnetcore-7.0#log-level
# input: trace | debug | info | warning | error | fatal
*/}}
{{- define "defines.logging.loglevel.dotnet" -}} 
{{- $dotnetLogLevelMapping := dict -}}
{{- $dotnetLogLevelMapping = set $dotnetLogLevelMapping "trace" "Trace" -}}
{{- $dotnetLogLevelMapping = set $dotnetLogLevelMapping "debug" "Debug" -}}
{{- $dotnetLogLevelMapping = set $dotnetLogLevelMapping "info" "Information" -}}
{{- $dotnetLogLevelMapping = set $dotnetLogLevelMapping "warn" "Warning" -}}
{{- $dotnetLogLevelMapping = set $dotnetLogLevelMapping "error" "Error" -}}
{{- $dotnetLogLevelMapping = set $dotnetLogLevelMapping "fatal" "Critical" -}}
{{- $targetLogLevel := ((.Values.logging).logLevel | default (.Values.harmonize.logging).logLevel) | default "trace"  -}}
{{- $dotnetLogLevel := get $dotnetLogLevelMapping ($targetLogLevel | lower) -}}
{{- if empty $dotnetLogLevel -}}
{{- fail (print "loglevel \"" $targetLogLevel "\" is not supported, please use one of the following: trace | debug | info | warn | error | fatal") -}}
{{- end -}}
{{- print $dotnetLogLevel -}}
{{- end -}}

{{/*
serilog Log Level
https://github.com/serilog/serilog/wiki/Configuration-Basics#minimum-level
# input: trace | debug | info | warning | error | fatal
*/}}
{{- define "defines.logging.loglevel.dotnet.serilog" -}} 
{{- $dotnetLogLevelMapping := dict -}}
{{- $dotnetLogLevelMapping = set $dotnetLogLevelMapping "trace" "Verbose" -}}
{{- $dotnetLogLevelMapping = set $dotnetLogLevelMapping "debug" "Debug" -}}
{{- $dotnetLogLevelMapping = set $dotnetLogLevelMapping "info" "Information" -}}
{{- $dotnetLogLevelMapping = set $dotnetLogLevelMapping "warn" "Warning" -}}
{{- $dotnetLogLevelMapping = set $dotnetLogLevelMapping "error" "Error" -}}
{{- $dotnetLogLevelMapping = set $dotnetLogLevelMapping "fatal" "Fatal" -}}
{{- $targetLogLevel := ((.Values.logging).logLevel | default (.Values.harmonize.logging).logLevel) | default "trace"  -}}
{{- $dotnetLogLevel := get $dotnetLogLevelMapping ($targetLogLevel | lower) -}}
{{- if empty $dotnetLogLevel -}}
{{- fail (print "loglevel \"" $targetLogLevel "\" is not supported, please use one of the following: trace | debug | info | warn | error | fatal") -}}
{{- end -}}
{{- print $dotnetLogLevel -}}
{{- end -}}

{{/*
Core Log Level
*/}}
{{- define "defines.logging.loglevel" -}} 
{{- $coreLogLevelMapping := dict -}}
{{- $coreLogLevelMapping = set $coreLogLevelMapping "trace" "TRACE" -}}
{{- $coreLogLevelMapping = set $coreLogLevelMapping "debug" "DEBUG" -}}
{{- $coreLogLevelMapping = set $coreLogLevelMapping "info" "INFO" -}}
{{- $coreLogLevelMapping = set $coreLogLevelMapping "warn" "WARN" -}}
{{- $coreLogLevelMapping = set $coreLogLevelMapping "error" "ERROR" -}}
{{- $coreLogLevelMapping = set $coreLogLevelMapping "fatal" "ERROR" -}}
{{- $targetLogLevel := ((.Values.logging).logLevel | default (.Values.harmonize.logging).logLevel) | default "trace"  -}}
{{- $coreLogLevel := get $coreLogLevelMapping ($targetLogLevel | lower) -}}
{{- if empty $coreLogLevel -}}
{{- fail (print "loglevel \"" $targetLogLevel "\" is not supported, please use one of the following: trace | debug | info | warn | error | fatal") -}}
{{- end -}}
{{- print ($coreLogLevel) -}}
{{- end -}}

{{/*
Apps Log Level
# https://github.com/winstonjs/winston#logging-levels
*/}}
{{- define "defines.logging.loglevel.apps" -}} 
{{- $appsLogLevelMapping := dict -}}
{{- $appsLogLevelMapping = set $appsLogLevelMapping "trace" "silly" -}}
{{- $appsLogLevelMapping = set $appsLogLevelMapping "debug" "debug" -}}
{{- $appsLogLevelMapping = set $appsLogLevelMapping "info" "info" -}}
{{- $appsLogLevelMapping = set $appsLogLevelMapping "warn" "warn" -}}
{{- $appsLogLevelMapping = set $appsLogLevelMapping "error" "error" -}}
{{- $appsLogLevelMapping = set $appsLogLevelMapping "fatal" "error" -}}
{{- $targetLogLevel := ((.Values.logging).logLevel | default (.Values.harmonize.logging).logLevel) | default "trace"  -}}
{{- $appsLogLevel := get $appsLogLevelMapping ($targetLogLevel | lower) -}}
{{- if empty $appsLogLevel -}}
{{- fail (print "loglevel \"" $targetLogLevel "\" is not supported, please use one of the following: trace | debug | info | warn | error | fatal") -}}
{{- end -}}
{{- print $appsLogLevel -}}
{{- end -}}

{{/*
nestjs Log Level
# https://docs.nestjs.com/techniques/logger#basic-customization
*/}}
{{- define "defines.logging.loglevel.nestjs.2" -}} 
{{- $appsLogLevelMapping := dict -}}
{{- $appsLogLevelMapping = set $appsLogLevelMapping "trace" "verbose" -}}
{{- $appsLogLevelMapping = set $appsLogLevelMapping "debug" "debug" -}}
{{- $appsLogLevelMapping = set $appsLogLevelMapping "info" "log" -}}
{{- $appsLogLevelMapping = set $appsLogLevelMapping "warn" "warn" -}}
{{- $appsLogLevelMapping = set $appsLogLevelMapping "error" "error" -}}
{{- $appsLogLevelMapping = set $appsLogLevelMapping "fatal" "error" -}}
{{- $targetLogLevel := ((.Values.logging).logLevel | default (.Values.harmonize.logging).logLevel) | default "trace"  -}}
{{- $appsLogLevel := get $appsLogLevelMapping ($targetLogLevel | lower) -}}
{{- if empty $appsLogLevel -}}
{{- fail (print "loglevel \"" $targetLogLevel "\" is not supported, please use one of the following: trace | debug | info | warn | error | fatal") -}}
{{- end -}}
{{- print $appsLogLevel -}}
{{- end -}}


{{/* 
Vault Log levels
 */}}
{{- define "defines.logging.loglevel.vault" -}}
{{- $vaultLogLevelMapping := dict -}}
{{- $vaultLogLevelMapping = set $vaultLogLevelMapping "trace" "7" -}}
{{- $vaultLogLevelMapping = set $vaultLogLevelMapping "debug" "7" -}}
{{- $vaultLogLevelMapping = set $vaultLogLevelMapping "info" "6" -}}
{{- $vaultLogLevelMapping = set $vaultLogLevelMapping "warn" "4" -}}
{{- $vaultLogLevelMapping = set $vaultLogLevelMapping "error" "3" -}}
{{- $vaultLogLevelMapping = set $vaultLogLevelMapping "fatal" "3" -}}
{{- $targetLogLevel := ((.Values.logging).logLevel | default (.Values.harmonize.logging).logLevel) | default "trace"  -}}
{{- $vaultLogLevel := get $vaultLogLevelMapping ($targetLogLevel | lower) -}}
{{- if empty $vaultLogLevel -}}
{{- fail (print "loglevel \"" $targetLogLevel "\" is not supported, please use one of the following: trace | debug | info | warn | error | fatal") -}}
{{- end -}}
{{- print $vaultLogLevel -}}
{{- end -}}
