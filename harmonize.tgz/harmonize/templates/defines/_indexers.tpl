{{/*
PRIVATE: Base indexer mapping shared by both name and settings.name functions.
Returns the base indexer name for a given ledger protocol.
This is the single source of truth for ledger-to-indexer mappings.
*/}}
{{- define "harmonize.defines.indexers.PRIVATE.base-mapping" -}}
{{- $indexerMapping := dict -}}
{{/* Bitcoin-family ledgers use nbxplorer */}}
{{- $indexerMapping = set $indexerMapping "bitcoin" "nbxplorer" -}}
{{- $indexerMapping = set $indexerMapping "bitcoincash" "nbxplorer" -}}
{{- $indexerMapping = set $indexerMapping "litecoin" "nbxplorer" -}}
{{- $indexerMapping = set $indexerMapping "dogecoin" "nbxplorer" -}}
{{- $indexerMapping = set $indexerMapping "dash" "nbxplorer" -}}
{{/* EVM-family ledgers use ethindexer */}}
{{- $indexerMapping = set $indexerMapping "ethereum" "ethindexer" -}}
{{- $indexerMapping = set $indexerMapping "polygon" "ethindexer" -}}
{{- $indexerMapping = set $indexerMapping "avalanche-c-chain" "ethindexer" -}}
{{- $indexerMapping = set $indexerMapping "bsc" "ethindexer" -}}
{{/* Other ledgers */}}
{{- $indexerMapping = set $indexerMapping "xrpl" "xrplindexer" -}}
{{- $indexerMapping = set $indexerMapping "tezos" "xtzindexer" -}}
{{- $indexerMapping = set $indexerMapping "substrate" "substrate-indexer" -}}
{{- $indexerMapping = set $indexerMapping "stellar" "stellar-indexer" -}}
{{- $indexerMapping = set $indexerMapping "solana" "solana-indexer" -}}
{{- $indexerMapping = set $indexerMapping "cardano" "cardano" -}}
{{- $indexerMapping = set $indexerMapping "hedera" "hederaindexer" -}}
{{- $indexerMapping = set $indexerMapping "algorand" "algorandindexer" -}}
{{/* UIS-enabled ledgers: tracker name must match HOCON key in reference.conf */}}
{{- $indexerMapping = set $indexerMapping "tron" "tron-indexer" -}}
{{- $indexerMapping = set $indexerMapping "evm" "evm-indexer" -}}
{{- $indexerMapping | toYaml -}}
{{- end -}}

{{/*
PRIVATE: EVM chains that need chain-specific indexer names (e.g., ethindexer-polygon).
These chains share the ethindexer base but have separate deployments.
*/}}
{{- define "harmonize.defines.indexers.PRIVATE.evm-chain-suffix" -}}
{{- $evmChainSuffix := dict -}}
{{- $evmChainSuffix = set $evmChainSuffix "polygon" "polygon" -}}
{{- $evmChainSuffix = set $evmChainSuffix "avalanche-c-chain" "avalanche-c-chain" -}}
{{- $evmChainSuffix = set $evmChainSuffix "bsc" "bsc" -}}
{{- $evmChainSuffix | toYaml -}}
{{- end -}}

{{/*
Indexer names - returns the full indexer name for a ledger.
For EVM chains (polygon, avalanche-c-chain, bsc), returns chain-specific name (e.g., ethindexer-polygon).
For other ledgers, returns the base indexer name.
*/}}
{{- define "harmonize.defines.indexers.name" -}}
{{- $ledger := . -}}
{{- $baseMapping := include "harmonize.defines.indexers.PRIVATE.base-mapping" . | fromYaml -}}
{{- $evmSuffix := include "harmonize.defines.indexers.PRIVATE.evm-chain-suffix" . | fromYaml -}}
{{- $indexer := get $baseMapping $ledger -}}
{{- if empty $indexer -}}
{{- fail (printf "ledger \"%s\" is not supported, please use one of the following: %s" $ledger (keys $baseMapping )) -}}
{{- end -}}
{{/* For EVM chains with suffix, append the chain name */}}
{{- $suffix := get $evmSuffix $ledger -}}
{{- if $suffix -}}
{{- $indexer = printf "%s-%s" $indexer $suffix -}}
{{- end -}}
{{- print $indexer -}}
{{- end -}}

{{/*
Indexer setting name - returns the base indexer name for settings/configuration.
Always returns the base name (e.g., "ethindexer" for polygon, not "ethindexer-polygon").
Used for HOCON configuration keys in ledger-accounting.
*/}}
{{- define "harmonize.defines.indexers.settings.name" -}}
{{- $ledger := . -}}
{{- $baseMapping := include "harmonize.defines.indexers.PRIVATE.base-mapping" . | fromYaml -}}
{{- $indexer := get $baseMapping $ledger -}}
{{- if empty $indexer -}}
{{- fail (printf "ledger \"%s\" is not supported, please use one of the following: %s" $ledger (keys $baseMapping )) -}}
{{- end -}}
{{- print $indexer -}}
{{- end -}}