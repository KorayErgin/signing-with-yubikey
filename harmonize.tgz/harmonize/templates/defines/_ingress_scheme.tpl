{{- define "harmonize.defines.ingress.scheme" -}}
  {{- if .Values.harmonize.urls.tls -}}
    https://
  {{- else -}}
    http://
  {{- end -}}
{{- end -}}