{{- define "harmonize.defines.http_proxy_uris.nbxplorer" -}}
{{- if (index $.Values.indexers.nbxplorer.configMaps "httpProxy" "enabled") -}}

    {{- $protocol := index $.Values.harmonize "httpProxy" "protocol" | default "http" -}}
    {{- $host := index $.Values.harmonize "httpProxy" "host" | default "localhost" -}}

    {{- $defaultPort := (eq $protocol "http" | ternary "80" "443") -}}
    {{- $port := (index $.Values.harmonize "httpProxy" "port" | default $defaultPort | toString) -}}

    {{- $username := index $.Values.harmonize "httpProxy" "username" -}}
    {{- $password := index $.Values.harmonize "httpProxy" "password" -}}

    {{- if and $username $password -}}
        {{ printf "%s://%s:%s@%s:%s" $protocol $username $password $host $port }}
    {{- else -}}
        {{ printf "%s://%s:%s" $protocol $host $port }}
    {{- end -}}

{{- else -}}
    ""
{{- end -}}
{{- end }}

{{- define "harmonize.defines.http_proxy_uris.eth_indexer" -}}
{{- if (index $.Values.indexers.ethindexer.configMaps "httpProxy" "enabled") -}}

    {{- $protocol := index $.Values.harmonize "httpProxy" "protocol" | default "http" -}}
    {{- $host := index $.Values.harmonize "httpProxy" "host" | default "localhost" -}}

    {{- $defaultPort := (eq $protocol "http" | ternary "80" "443") -}}
    {{- $port := (index $.Values.harmonize "httpProxy" "port" | default $defaultPort | toString) -}}

    {{- $username := index $.Values.harmonize "httpProxy" "username" -}}
    {{- $password := index $.Values.harmonize "httpProxy" "password" -}}

    {{- if and $username $password -}}
        {{ printf "%s://%s:%s@%s:%s" $protocol $username $password $host $port }}
    {{- else -}}
        {{ printf "%s://%s:%s" $protocol $host $port }}
    {{- end -}}

{{- else -}}
    ""
{{- end -}}
{{- end }}

{{- define "harmonize.defines.http_proxy_uris.xrpl_indexer" -}}
{{- if (index $.Values.indexers.xrplindexer.configMaps "httpProxy" "enabled") -}}

    {{- $protocol := index $.Values.harmonize "httpProxy" "protocol" | default "http" -}}
    {{- $host := index $.Values.harmonize "httpProxy" "host" | default "localhost" -}}

    {{- $defaultPort := (eq $protocol "http" | ternary "80" "443") -}}
    {{- $port := (index $.Values.harmonize "httpProxy" "port" | default $defaultPort | toString) -}}

    {{- $username := index $.Values.harmonize "httpProxy" "username" -}}
    {{- $password := index $.Values.harmonize "httpProxy" "password" -}}

    {{- if and $username $password -}}
        {{ printf "%s://%s:%s@%s:%s" $protocol $username $password $host $port }}
    {{- else -}}
        {{ printf "%s://%s:%s" $protocol $host $port }}
    {{- end -}}

{{- else -}}
    ""
{{- end -}}
{{- end }}