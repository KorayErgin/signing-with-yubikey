{{/*
See: https://jdbc.postgresql.org/documentation/use/#connecting-to-the-database
*/}}
{{- define "harmonize.defines.uris.jdbc" -}}
  {{- $env := index . 0 -}}
  {{- $schema := index . 1 -}}

  {{- $Pg := $env.Values.harmonize.postgresql }}
  {{- $extraUrlParams := $Pg.urlParams | default "" | split "&" }}
  {{- $host := $Pg.host }}
  {{- $port := $Pg.port | toString | default "5432" }}
  {{- $username := $Pg.username }}
  {{- $password := $Pg.password }}
  {{- $database := $Pg.database }}
  {{- if $env.Values.postgresql.enabled }}
    {{- $username = empty $username | ternary $env.Values.postgresql.auth.username $username }}
    {{- $password = empty $password | ternary $env.Values.postgresql.auth.password $password }}
    {{- $database = empty $database | ternary $env.Values.postgresql.auth.database $database }}
    {{- $host = printf "%s-postgresql" $env.Release.Name }}
    {{- $port = $env.Values.postgresql.primary.service.ports.postgresql | toString | default "5432" }}
  {{- end }}

  {{- $currentSchema := empty $schema | ternary "" (printf "currentSchema=%s&search_path=%s" $schema $schema) -}}

  {{- $params := list -}}
  {{- $params = append $params $currentSchema -}}
  {{- $params = append $params (empty $username | ternary "" (printf "%s=%s" "user" ($username | urlquery ))) -}}
  {{- $params = append $params (empty $password | ternary "" (printf "%s=%s" "password" ($password | urlquery ))) -}}
  {{- $params = append $params (empty $Pg.sslmode | ternary "" (printf "%s=%s" "sslmode" ($Pg.sslmode | urlquery ))) -}}
  {{- $params = append $params (empty $Pg.sslrootcert | ternary "" (printf "%s=%s" "sslrootcert" ($Pg.sslrootcert | urlquery ))) -}}
  {{- $params = append $params (empty $Pg.sslcert | ternary "" (printf "%s=%s" "sslcert" ($Pg.sslcert | urlquery ))) -}}
  {{- $params = append $params (empty $Pg.sslkeypkcs8 | ternary "" (printf "%s=%s" "sslkey" ($Pg.sslkeypkcs8 | urlquery ))) -}}
  {{- range $extraUrlParams }}
    {{- $params = append $params . }}
  {{- end }}  

  {{- $qs := join "&" (compact $params) }}

  {{- urlJoin (dict "host" (printf "%s:%s" $host $port) "path" $database "query" $qs "scheme" "jdbc:postgresql") }}

{{- end }}


{{/* Dotnet URL postgresql */}}
{{- define "harmonize.defines.uris.dotnet" -}}
  {{- $env := index . 0 -}}
  {{- $schema := index . 1 -}}

  {{- $Pg := $env.Values.harmonize.postgresql }}
  {{- $extraUrlParams := $Pg.dotNetParams | default "" | split ";" }}
  {{- $host := $Pg.host }}
  {{- $port := $Pg.port | toString | default "5432" }}
  {{- $username := $Pg.username }}
  {{- $password := $Pg.password }}
  {{- $database := $Pg.database }}
  {{- if $env.Values.postgresql.enabled }}
    {{- $username = empty $username | ternary $env.Values.postgresql.auth.username $username }}
    {{- $password = empty $password | ternary $env.Values.postgresql.auth.password $password }}
    {{- $database = empty $database | ternary $env.Values.postgresql.auth.database $database }}
    {{- $host = printf "%s-postgresql" $env.Release.Name }}
    {{- $port = $env.Values.postgresql.primary.service.ports.postgresql | toString | default "5432" }}
  {{- end }}

  {{- $currentSchema := empty $schema | ternary "" (printf "SearchPath=%s" $schema) -}}

  {{- $params := list -}}
  {{- $params = append $params $currentSchema -}}

  {{- $params = append $params (printf "%s=%s" "Server" ($host)) -}}
  {{- $params = append $params (printf "%s=%s" "Port" ($port)) -}}
  {{- $params = append $params (printf "%s=%s" "Database" ($database)) -}}
  {{- $params = append $params (empty $username | ternary "" (printf "%s=%s" "Username" ($username))) -}}
  {{- $params = append $params (empty $password | ternary "" (printf "%s=%s" "Password" ($password))) -}}
  {{/* Map PostgreSQL sslmode values to .NET Npgsql Ssl Mode values:
       disable -> Disable, allow -> Allow, prefer -> Prefer, require -> Require,
       verify-ca -> VerifyCA, verify-full -> VerifyFull */}}
  {{- $sslModeMap := dict "disable" "Disable" "allow" "Allow" "prefer" "Prefer" "require" "Require" "verify-ca" "VerifyCA" "verify-full" "VerifyFull" -}}
  {{- $dotnetSslMode := index $sslModeMap $Pg.sslmode | default "Require" -}}
  {{- $params = append $params (empty $Pg.sslmode | ternary "" (printf "%s=%s" "Ssl Mode" $dotnetSslMode)) -}}
  {{/*
  Set Trust Server Certificate=true due to Google Cloud SQL constraints.
  failed to verify certificate: x509: “Google Cloud SQL Server CA” certificate is not standards compliant
  */}}
  {{- $params = append $params (empty $Pg.sslrootcert | ternary "" (printf "%s=%s" "Trust Server Certificate" "true")) -}}
  {{- $params = append $params (empty $Pg.sslrootcert | ternary "" (printf "%s=%s" "Root Certificate" ($Pg.sslrootcert))) -}}

  {{- if empty $Pg.sslcertpfx }}
    {{- $params = append $params (empty $Pg.sslcert | ternary "" (printf "%s=%s" "Ssl Certificate" ($Pg.sslcert))) -}}
    {{- $params = append $params (empty $Pg.sslkey | ternary "" (printf "%s=%s" "Ssl Key" ($Pg.sslkey))) -}}
  {{- else }}
    {{- $params = append $params (empty $Pg.sslcertpfx | ternary "" (printf "%s=%s" "Ssl Certificate" ($Pg.sslcertpfx))) -}}
  {{- end }}

  {{- range $extraUrlParams }}
    {{- $params = append $params . }}
  {{- end }}  

  {{- join ";" (compact $params) }}

{{- end }}

{{/* PostgreSQL URL postgresql */}}
{{- define "harmonize.defines.uris" -}}
  {{- $env := index . 0 -}}
  {{- $schema := index . 1 -}}

  {{- $Pg := $env.Values.harmonize.postgresql }}
  {{- $extraUrlParams := $Pg.urlParams | default "" | split "&" }}
  {{- $host := $Pg.host }}
  {{- $port := $Pg.port | toString | default "5432" }}
  {{- $username := $Pg.username }}
  {{- $password := $Pg.password }}
  {{- $database := $Pg.database }}
  {{- if $env.Values.postgresql.enabled }}
    {{- $username = empty $username | ternary $env.Values.postgresql.auth.username $username }}
    {{- $password = empty $password | ternary $env.Values.postgresql.auth.password $password }}
    {{- $database = empty $database | ternary $env.Values.postgresql.auth.database $database }}
    {{- $host = printf "%s-postgresql" $env.Release.Name }}
    {{- $port = $env.Values.postgresql.primary.service.ports.postgresql | toString | default "5432" }}
  {{- end }}

  {{- $currentSchema := empty $schema | ternary "" (printf "currentSchema=%s&search_path=%s" $schema $schema) -}}

  {{- $params := list -}}
  {{- $params = append $params (empty $schema | ternary "" (printf "%s=%s" "schema" ($schema | urlquery ))) -}}
  {{- $params = append $params (empty $Pg.sslmode | ternary "" (printf "%s=%s" "sslmode" ($Pg.sslmode | urlquery ))) -}}
  {{- $params = append $params (empty $Pg.sslrootcert | ternary "" (printf "%s=%s" "sslrootcert" ($Pg.sslrootcert | urlquery ))) -}}
  {{- $params = append $params (empty $Pg.sslcert | ternary "" (printf "%s=%s" "sslcert" ($Pg.sslcert | urlquery ))) -}}
  {{- $params = append $params (empty $Pg.sslkey | ternary "" (printf "%s=%s" "sslkey" ($Pg.sslkey | urlquery ))) -}}
  {{- range $extraUrlParams }}
    {{- $params = append $params . }}
  {{- end }}  

  {{- $qs := join "&" (compact $params) }}

  {{- $userSpec := empty $password | ternary ($username | urlquery) (printf "%s:%s" $username $password) }}

  {{- urlJoin (dict "userinfo" $userSpec "host" (printf "%s:%s" $host $port) "path" $database "query" $qs "scheme" "postgresql") }}

{{- end }}


{{/*
PostgreSQL Connection URL for node containers
format = [database type]://[username]:[password]@[host]/[database name]
*/}}
{{- define "harmonize.defines.uris.node" -}}
  {{- $env := index . 0 -}}
  {{- $schema := index . 1 -}}

  {{- $Pg := $env.Values.harmonize.postgresql }}
  {{- $extraUrlParams := $Pg.urlParams | default "" | split "&" }}
  {{- $host := $Pg.host }}
  {{- $port := $Pg.port | toString | default "5432" }}
  {{- $username := $Pg.username }}
  {{- $password := $Pg.password }}
  {{- $database := $Pg.database }}
  {{- if $env.Values.postgresql.enabled }}
    {{- $username = empty $username | ternary $env.Values.postgresql.auth.username $username }}
    {{- $password = empty $password | ternary $env.Values.postgresql.auth.password $password }}
    {{- $database = empty $database | ternary $env.Values.postgresql.auth.database $database }}
    {{- $host = printf "%s-postgresql" $env.Release.Name }}
    {{- $port = $env.Values.postgresql.primary.service.ports.postgresql | toString | default "5432" }}
  {{- end }}

  {{- $currentSchema := empty $schema | ternary "" (printf "currentSchema=%s&search_path=%s" $schema $schema) -}}

  {{- $params := list -}}
  {{- $params = append $params (empty $schema | ternary "" (printf "%s=%s" "schema" ($schema | urlquery ))) -}}
  {{- $params = append $params (empty $Pg.sslmode | ternary "" (printf "%s=%s" "sslmode" ($Pg.sslmode | urlquery ))) -}}
  {{- $params = append $params (empty $Pg.sslrootcert | ternary "" (printf "%s=%s" "sslrootcert" ($Pg.sslrootcert | urlquery ))) -}}
  {{- $params = append $params (empty $Pg.sslcert | ternary "" (printf "%s=%s" "sslcert" ($Pg.sslcert | urlquery ))) -}}
  {{- $params = append $params (empty $Pg.sslkey | ternary "" (printf "%s=%s" "sslkey" ($Pg.sslkey | urlquery ))) -}}
  {{- range $extraUrlParams }}
    {{- $params = append $params . }}
  {{- end }}  

  {{- $qs := join "&" (compact $params) }}

  {{- $userSpec := empty $password | ternary ($username | urlquery) (printf "%s:%s" $username $password) }}

  {{- urlJoin (dict "userinfo" $userSpec "host" (printf "%s:%s" $host $port) "path" $database "query" $qs "scheme" "postgres") }}

{{- end }}

{{/*
PostgreSQL Connection URL for rust containers
format = [database type]://[username]:[password]@[host]/[database name]
*/}}
{{- define "harmonize.defines.uris.rust" -}}
  {{- $env := index . 0 -}}
  {{- $schema := index . 1 -}}

  {{- $Pg := $env.Values.harmonize.postgresql }}
  {{- $extraUrlParams := $Pg.urlParams | default "" | split "&" }}
  {{- $host := $Pg.host }}
  {{- $port := $Pg.port | toString | default "5432" }}
  {{- $username := $Pg.username }}
  {{- $password := $Pg.password }}
  {{- $database := $Pg.database }}
  {{- if $env.Values.postgresql.enabled }}
    {{- $username = empty $username | ternary $env.Values.postgresql.auth.username $username }}
    {{- $password = empty $password | ternary $env.Values.postgresql.auth.password $password }}
    {{- $database = empty $database | ternary $env.Values.postgresql.auth.database $database }}
    {{- $host = printf "%s-postgresql" $env.Release.Name }}
    {{- $port = $env.Values.postgresql.primary.service.ports.postgresql | toString | default "5432" }}
  {{- end }}

  {{- $currentSchema := empty $schema | ternary "" (printf "options=-c%%20search_path%%3D%s" (urlquery $schema)) -}}

  {{- $params := list -}}
  {{- $params = append $params $currentSchema -}}
  {{- $params = append $params (empty $Pg.sslmode | ternary "" (printf "%s=%s" "sslmode" ($Pg.sslmode | urlquery ))) -}}
  {{- $params = append $params (empty $Pg.sslrootcert | ternary "" (printf "%s=%s" "sslrootcert" ($Pg.sslrootcert | urlquery ))) -}}
  {{- $params = append $params (empty $Pg.sslcert | ternary "" (printf "%s=%s" "sslcert" ($Pg.sslcert | urlquery ))) -}}
  {{- $params = append $params (empty $Pg.sslkey | ternary "" (printf "%s=%s" "sslkey" ($Pg.sslkey | urlquery ))) -}}
  {{- range $extraUrlParams }}
    {{- $params = append $params . }}
  {{- end }}  

  {{- $qs := join "&" (compact $params) }}

  {{- $userSpec := empty $password | ternary ($username | urlquery) (printf "%s:%s" $username $password) }}

  {{- urlJoin (dict "userinfo" $userSpec "host" (printf "%s:%s" $host $port) "path" $database "query" $qs "scheme" "postgres") }}

{{- end }}
