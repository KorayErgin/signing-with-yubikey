{{/* Generate Clients JSON object in a deterministic way */}}
{{- define "harmonize.defines.oauth.clients" -}}
{{- $orderedClientList := list -}}
{{- $clientDict := . -}}
{{- $sortedClientKey := keys $clientDict | sortAlpha -}}
{{- range $sortedClientKey -}}
  {{- $orderedClientList = append $orderedClientList (get $clientDict .) -}}
{{- end -}}
{{- $orderedClientList | toJson -}}
{{- end -}}


{{- define "harmonize.defines.oauth.server_url" -}}
  {{- $base :=  tpl .Values.harmonize.urls.base . -}}
  {{ (printf "auth-ui.%s" $base) }}
{{- end -}}

