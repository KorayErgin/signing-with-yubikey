{{/* Blocksafe main configuration */}}
{{/* We are loading Blocksafe settings by first looking at a secret if it has been configured using kms_blocksafe.secretRef attribute */}}
{{/* Otherwise, we are loading Blocksafe settings from the kms_blocksafe section (device, slot and pin values) */}}
{{- define "harmonize.defines.kms_blocksafe_variables" -}}
  {{- if .Values.kms_blocksafe.secretRef }}
    {{- $kms_blocksafe_secret := (lookup "v1" "Secret" $.Release.Namespace .Values.kms_blocksafe.secretRef) }}
    device: {{ index $kms_blocksafe_secret.data "device" | b64dec }}
    slot: {{ index $kms_blocksafe_secret.data "slot" | b64dec }}
    pin: {{ index $kms_blocksafe_secret.data "pin" | b64dec }}
  {{- else }}
    device: {{ .Values.kms_blocksafe.device }}
    slot: {{ .Values.kms_blocksafe.slot }}
    pin: {{ .Values.kms_blocksafe.pin }}
  {{- end }}  
{{- end }}

{{- define "harmonize.defines.kms.sidecars" -}}
{{- $isKmsRust := eq .Values.platform "kms_aws" -}}

kmsconnect:
  image: '{{tpl .Values.image.kmsconnect.repository .}}:{{tpl .Values.image.kmsconnect.tag . }}'
  imagePullPolicy: '{{ tpl .Values.image.pullPolicy . }}'
  env:
  {{- if eq "kms_blocksafe" .Values.platform }}
    {{/* BLOCKSAFE_DEVICE is mandatory here because it is used for replacing @BSAFEDEV@ entry in the Blocksafe CS_PKCS11_R2_CFG file */}}
    {{- $kms_blocksafe_device := (include "harmonize.defines.kms_blocksafe_variables" . | fromYaml).device}}
    BLOCKSAFE_DEVICE: {{ $kms_blocksafe_device }}
  {{- else if eq "kms_luna" .Values.platform }}
    LUNA_HOST: '{{ .Values.kms_luna.host | default "localhost" }}'
    LUNA_PORT: '{{ .Values.kms_luna.port | default 1792 }}'
  {{- else if (and (eq "kms_soft" .Values.platform) (.Values.kms_soft.kms_rewrapping_key)) }}
    KMS_REWRAPPING_KEY: '{{ .Values.kms_soft.kms_rewrapping_key }}'
  {{- if hasPrefix "gcp:" .Values.kms_soft.kms_rewrapping_key }}
    GOOGLE_APPLICATION_CREDENTIALS: '/app/cfg/gcp_json'
  {{- end }}
  {{- else if eq .Values.platform "kms_soft_gcp_wrap" }}
    KMS_REWRAPPING_KEY: '{{ .Values.kms_soft_gcp_wrap.kms_rewrapping_key }}'
    {{- if hasPrefix "gcp:" .Values.kms_soft_gcp_wrap.kms_rewrapping_key }}
    GOOGLE_APPLICATION_CREDENTIALS: '/app/cfg/gcp_json'
    {{- end }}
  {{- else if eq .Values.platform "kms_andro" }}
    ANDRO_BROKER: '{{ .Values.kms_andro.broker | quote }}'
    ANDRO_TOKEN: '{{ .Values.kms_andro.token | quote }}'
  {{- else if eq .Values.platform "kms_aws" }}
    PKCS11_RW_USER_PIN: '{{ required "aws_cloud_hsm_crypto_user_username is required for kms_aws" .Values.kms_aws.aws_cloud_hsm_crypto_user_username }}:{{ required "aws_cloud_hsm_crypto_user_password is required for kms_aws" .Values.kms_aws.aws_cloud_hsm_crypto_user_password }}'
    {{- $eni_ip := required "aws_cloud_hsm_cluster_eni_ip is required for kms_aws" .Values.kms_aws.aws_cloud_hsm_cluster_eni_ip }}
    {{- if not (regexMatch "^(([0-9]{1,3}\\.){3}[0-9]{1,3})$" $eni_ip) }}
      {{- fail "Invalid IP address format for aws_cloud_hsm_cluster_eni_ip, must be valid IPv4 address" }}
    {{- end }}
    AWS_CLOUDHSM_CLUSTER_ENI_IP: '{{ $eni_ip }}'
  {{- else if eq .Values.platform "kms_mpc" }}
    KMS_MPC_URL: '{{ required "url is required for kms_mpc" (default (include "harmonize.mpc.node-0.internal-url" .) .Values.kms_mpc.url) }}'
    KMS_MPC_THRESHOLD: '{{ required "threshold is required for kms_mpc" (default (len .Values.harmonize.mpc.nodes) .Values.kms_mpc.threshold) }}'
    KMS_MPC_CLUSTER_SIZE: '{{ required "cluster_size is required for kms_mpc" ( default (len .Values.harmonize.mpc.nodes) .Values.kms_mpc.cluster_size) }}'
  {{- end }}
  volumeMounts:
    - name: kmsconnect
      mountPath: '/app/cfg/'
  {{- if (or (eq "kms_blocksafe" .Values.platform) (eq "kms_luna" .Values.platform)) }}
    - name: kmstmp
      mountPath: '/tmp'
  {{- else if (eq .Values.platform "kms_aws") }}
    - name: kmsconnect
      mountPath: '/opt/cloudhsm/etc/customerCA.crt'
      subPath: 'customerCA.crt'
      readOnly: false
    - name: kms-aws-pkcs11-config
      mountPath: /opt/cloudhsm/etc
      readOnly: false
    - name: kms-rs-log-dir
      mountPath: /var/log/kms
      readOnly: false
  {{- end }}
  securityContext: 
  {{ .Values.image.kmsconnect.securityContext | default .Values.securityContext | toYaml | nindent 6 }}

{{/* Blocksafe emulator: only enabled if device is set to 3001@localhost */}}
{{- if eq "kms_blocksafe" .Values.platform }}
{{- $kms_blocksafe_device := (include "harmonize.defines.kms_blocksafe_variables" . | fromYaml).device}}
{{- if eq $kms_blocksafe_device "3001@localhost" }}
emulator:
  image: '{{tpl .Values.harmonize.repository.base .}}/blocksafe-sim:4.0.0.0'
  imagePullPolicy: '{{ tpl .Values.image.pullPolicy . }}'
{{- end }}
{{- end }}
{{- end }}

{{- define "harmonize.defines.kms.secrets" -}}
kmsconnect:
  enabled: '{{ contains "kms_" .Values.platform  }}'
  secretRef:
  stringData:
    {{- if eq .Values.platform "kms_soft" }}
    soft.cfg: |-
      master = {{ required "master is required for kms_soft" .Values.kms_soft.master }}
    {{- if and (.Values.kms_soft.kms_rewrapping_key) (hasPrefix "gcp:" .Values.kms_soft.kms_rewrapping_key) }}
    gcp_json: |
      {{ .Values.kms_soft.gcp_json | toString | fromJson | toJson }}
    {{- end }}
    {{- else if eq .Values.platform "kms_soft_gcp_wrap" }}
    soft.cfg: |-
      master = {{ required "master is required for kms_soft_gcp_wrap" .Values.kms_soft_gcp_wrap.master }}
    {{- if and (.Values.kms_soft_gcp_wrap.kms_rewrapping_key) (hasPrefix "gcp:" .Values.kms_soft_gcp_wrap.kms_rewrapping_key) }}
    gcp_json: |
      {{ .Values.kms_soft_gcp_wrap.gcp_json | toString | fromJson | toJson }}
    {{- end }}
    {{- else if eq .Values.platform "kms_mock" }}
    mock.cfg: |-
      phrase = {{ .Values.kms_mock.phrase }}
      norandom = {{ .Values.kms_mock.norandom }}
    {{- else if eq .Values.platform "kms_blocksafe" }}
      {{/* Here, we are creating the blocksafe.cfg file which is used by Ripple kmsconnect component when it starts up */}}
      {{- $kms_blocksafe_variables := (include "harmonize.defines.kms_blocksafe_variables" . | fromYaml)}}
      blocksafe.cfg: |-
        device =  {{ $kms_blocksafe_variables.device }}
        slot = {{ $kms_blocksafe_variables.slot }}
        pin = {{ $kms_blocksafe_variables.pin }}
    {{- else if eq .Values.platform "kms_luna" }}
    luna.cfg: |-
      slot = {{ .Values.kms_luna.slot }}
      pin  = {{ .Values.kms_luna.pin }}
    luna-clientKey.pem: {{ .Values.kms_luna.client.key | quote }}
    luna-server.pem: {{ .Values.kms_luna.server.cert | quote }}
    luna-client.pem: {{ .Values.kms_luna.client.cert | quote }}
    {{- else if eq .Values.platform "kms_ibm" }}
    ibm.cfg: |-
      system = {{ .Values.kms_ibm.system }}
      instance = {{ .Values.kms_ibm.instance }}
      endpoint = {{ .Values.kms_ibm.endpoint }}
      apikey = {{ .Values.kms_ibm.apikey }}
    {{- else if eq .Values.platform "kms_andro" }}
    andro.cfg: |-
      broker = {{ required "broker is required for kms_andro" .Values.kms_andro.broker }}
      token  = {{ required "token is required for kms_andro" .Values.kms_andro.token  }}
    {{- else if eq .Values.platform "kms_gcp" }}
    gcp.cfg: |-
      location = {{ .Values.kms_gcp.location }}
      project = {{ .Values.kms_gcp.project }}
      keyring  = {{ .Values.kms_gcp.keyring }}
      authfile = {{ .Values.kms_gcp.authfile }}
    gcp_json: |-
      {{ .Values.kms_gcp.gcp_json | fromJson | toJson }}
    {{- else if eq .Values.platform "kms_hybrid" }}
    hybrid.cfg: |-
      location = {{ .Values.kms_hybrid.location }}
      project = {{ .Values.kms_hybrid.project }}
      keyring  = {{ .Values.kms_hybrid.keyring }}
    gcp_json: |-
      {{ .Values.kms_hybrid.gcp_json | fromJson | toJson }}
    {{- else if eq .Values.platform "kms_aws" }}
    customerCA.crt: {{ required "aws_cloud_hsm_customer_certificate is required for kms_aws" .Values.kms_aws.aws_cloud_hsm_customer_certificate | quote }}
    {{- end }}
{{- end }}

{{- define "harmonize.defines.kms.volumes" -}}
{{- $isKmsRust := eq .Values.platform "kms_aws" -}}
kmsconnect:
  enabled: {{ contains "kms_" .Values.platform }}
  name: '{{ printf "%s-kmsconnect" ( include "bjw-s.common.lib.chart.names.fullname" . ) }}'
  type: secret
  mountPath: /app/cfg
kmstmp:
  enabled: {{ contains "kms_" .Values.platform }}
  name: '{{ printf "%s-kmstmp" ( include "bjw-s.common.lib.chart.names.fullname" . ) }}'
  type: emptyDir
  mountPath: /kmstmp
kms-aws-pkcs11-config:
  enabled: {{ eq "kms_aws" .Values.platform }}
  name: '{{ printf "%s-kms-aws-pkcs11-config" ( include "bjw-s.common.lib.chart.names.fullname" . ) }}'
  type: emptyDir
  mountPath: /opt/cloudhsm/etc
kms-rs-log-dir:
  enabled: {{ $isKmsRust}}
  name: '{{ printf "%s-kms-rs-log-dir" ( include "bjw-s.common.lib.chart.names.fullname" . ) }}'
  type: emptyDir
  mountPath: /var/log/kms
{{- end }}

{{- define "harmonize.defines.kms.service" -}}
{{- end }}

{{/* TODO: [QAS-2512] [Helm-Flat] Add KMS AWS double Wrapping */}}
