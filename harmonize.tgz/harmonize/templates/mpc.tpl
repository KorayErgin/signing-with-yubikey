{{/*
Include components and generate Kubernetes objects
*/}}

{{/* Make sure all variables are set properly */}}
{{- include "bjw-s.common.loader.init" . -}}

{{- $original := . -}}

{{- $isAnyVaultUsingMpc := false -}}
{{- range $key, $vault := .Values.harmonize.vaults }}
  {{- if eq $vault.platform "kms_mpc" }}
    {{- $isAnyVaultUsingMpc = true -}}
  {{- end }}
{{- end }}
{{- $isHarmonizeUsingMpc := or $isAnyVaultUsingMpc (eq .Values.components.notary.platform "kms_mpc") -}}
{{- $isMpcClusterRequired := or $isHarmonizeUsingMpc .Values.harmonize.mpc.enable -}}

{{/* 
  template "debug.fail" $isMpcClusterRequired 
*/}}

{{- if $isMpcClusterRequired -}}
  
  {{- $relay := $original.Values.harmonize.mpc.relay -}}

  {{/* 
    template "debug.fail" $relay 
  */}}

  {{- if $relay.enable -}}

    {{/* Create environment copy */}}
    {{- $copyForRelay := mustDeepCopy $original -}}

    {{/* Add a reference to the original */}}
    {{- $_ := set $copyForRelay "Original" $ -}}

    {{/* Set node name */}}
    {{- $_ := set $copyForRelay.Values "node_name" $relay.name -}}
    
    {{/* Set chart name to <parent chart name>-node-<node name> */}}
    {{- $_ := set $copyForRelay.Values "nameOverride" (printf "%s-%s" $original.Chart.Name $relay.name) -}}

    {{/* Ensure each node's internal URL is set correctly */}}
    {{- $_ := set $relay "internal_url" ( printf "http://%s" (printf "%s-%s" $original.Chart.Name $relay.name) ) -}}
    
    {{/* Copy common node settings, if any */}}
    {{- $_ := mergeOverwrite $copyForRelay.Values $copyForRelay.Values.mpc.relay -}}

    {{/* Copy values for this specific node */}}
    {{- $_ := mergeOverwrite $copyForRelay.Values $relay -}}

    {{- include "harmonize.components.all" $copyForRelay -}}

    {{/* With all the values set properly, render the component using the library chart */}}
    {{- include "bjw-s.common.loader.all" $copyForRelay -}}
    
  {{- end -}}

  {{/* 
    template "debug.fail" $isMpcClusterRequired 
  */}}

  {{- range $index, $node := .Values.harmonize.mpc.nodes -}}

    {{/* Create environment copy */}}
    {{- $copy := mustDeepCopy $original -}}

    {{/* Add a reference to the original */}}
    {{- $_ := set $copy "Original" $ -}}

    {{/* Set node name */}}
    {{- $_ := set $copy.Values "node_name" $node.name -}}

    {{/* Set node index */}}
    {{- $_ := set $copy.Values "node_index" $index -}}
    
    {{/* Set chart name to <parent chart name>-node-<node name> */}}
    {{- $_ := set $copy.Values "nameOverride" (printf "%s-mpc-node-%s" $original.Chart.Name $node.name) -}}

    {{/* Ensure each node's internal URL is set correctly */}}
    {{- $_ := set $node "internal_url" ( printf "http://%s" (printf "%s-%s" $original.Chart.Name $node.name) ) -}}
    
    {{/* Copy common node settings, if any */}}
    {{- $_ := mergeOverwrite $copy.Values $copy.Values.mpc.node -}}

    {{/* Copy values for this specific node */}}
    {{- $_ := mergeOverwrite $copy.Values $node -}}

    {{- if $node.enabled -}}

      {{/* Include node-specific rules */}}
      {{- include "harmonize.mpc.all" $copy -}}

      {{/* With all the values set properly, render the component using the library chart */}}
      {{- include "bjw-s.common.loader.all" $copy -}}
    
    {{- end -}}

  {{- end -}}

{{- end -}}

{{- define "harmonize.mpc.node-0.internal-url" -}}
    {{- $node0 := index .Values.harmonize.mpc.nodes 0 -}}
    {{- printf "http://%s-%s-mpc-node-%s:%s" .Release.Name .Chart.Name $node0.name "8888" -}}
{{- end -}}

{{/* 
  template "debug.fail" $isMpcClusterRequired 
*/}}