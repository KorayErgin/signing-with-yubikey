{{/*
Include components and generate Kubernetes objects
*/}}

{{/* Make sure all variables are set properly */}}
{{- include "bjw-s.common.loader.init" . -}}

{{- $original := . -}}

{{- range $ledger_name, $ledger := .Values.harmonize.ledgers -}}

  {{ $indexerName := include "harmonize.defines.indexers.name" $ledger_name }}
  {{ $indexerSettingsName := include "harmonize.defines.indexers.settings.name" $ledger_name }}


  {{/* nbxplorer needs special handling */}}
  {{- if (eq $indexerName "nbxplorer" ) -}}
    {{- continue -}}
  {{- end -}}

  {{- range $network_name, $network := $ledger -}}
    {{/* Check if this network is enabled */}}
    {{- if not $network.enabled -}}
      {{- continue -}}
    {{- end -}}

    {{/* If this ledger is remote, skip it */}}
    {{- if $network.indexerUrl -}}
      {{- continue -}}
    {{- end -}}

    {{/* If this network is using UIS mode, skip legacy indexer */}}
    {{- if (index $network "enableUIS") -}}
      {{- continue -}}
    {{- end -}}

    {{/* Skip UIS-only ledgers (tron, evm) - they have no legacy indexer */}}
    {{- $uisOnlyLedgers := list "tron" "evm" -}}
    {{- if has $ledger_name $uisOnlyLedgers -}}
      {{- continue -}}
    {{- end -}}

    {{/* Create environment copy */}}
    {{- $copy := mustDeepCopy $original -}}

    {{/* Add a reference to the original */}}
    {{- $_ := set $copy "Original" $ -}}

    {{/* Pass ledger name */}}
    {{- $_ := set $copy "Ledger_Name" $ledger_name -}}

    {{/* Pass network name */}}
    {{- $_ := set $copy "Network_Name" $network_name -}}

    {{/* Pass network */}}
    {{- $_ := set $copy "Network" (mustDeepCopy $network) -}}
    
    {{/* Set chart name to <parent chart name><component name> */}}
    {{- $_ := set $copy.Values "nameOverride" (printf "%s-%s-%s" $.Chart.Name $ledger_name $network_name) -}}

    {{/* Copy chart settings for ledger */}}
    {{- $_ := mergeOverwrite $copy.Values (index $copy.Values.indexers $indexerSettingsName) -}}
    
    {{/* Include component rules, both common and component specific */}}
    {{- include "harmonize.indexers.all" $copy -}}
    {{- include (printf "harmonize.indexers.%s" $indexerSettingsName) $copy -}}

    {{/* With all the values set properly then render the component using the library chart */}}
    {{ include "bjw-s.common.loader.all" $copy }}

  {{- end -}}
{{- end -}}