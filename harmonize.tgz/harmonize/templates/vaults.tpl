{{/*
Include components and generate Kubernetes objects
*/}}

{{/* Make sure all variables are set properly */}}
{{- include "bjw-s.common.loader.init" . -}}

{{- $original := . -}}

{{- range $vault_id, $vault := .Values.harmonize.vaults -}}

  {{/* Check if this vault is enabled */}}
  {{- if not $vault.enabled -}}
    {{- continue -}}
  {{- end -}}

  {{/* Create environment copy */}}
  {{- $copy := mustDeepCopy $original -}}

  {{/* Add a reference to the original */}}
  {{- $_ := set $copy "Original" $ -}}

  {{/* Set id */}}
  {{- $_ := set $copy.Values "vault_id" $vault_id -}}
  
  {{/* Set chart name to <parent chart name>-vault-<vault id> */}}
  {{- $_ := set $copy.Values "nameOverride" (printf "%s-vault-%s" $original.Chart.Name $vault_id) -}}
  
  {{/* Copy common vault setting */}}
  {{- $_ := mergeOverwrite $copy.Values $copy.Values.vault  -}}

  {{/* Copy values for this instance  */}}
  {{- $_ := mergeOverwrite $copy.Values $vault -}}

  {{/* Include vault rules */}}
  {{- include "harmonize.vaults.all" $copy -}}

  {{/* With all the values set properly then render the component using the library chart */}}
  {{ include "bjw-s.common.loader.all" $copy }}

{{- end -}}