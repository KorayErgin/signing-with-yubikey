{{- define "harmonize.indexers.solana-indexer" -}}
  {{- $_ := merge .Values (include "harmonize.indexers.solana-indexer.PRIVATE.hardcoded_values" . | fromYaml) -}}
  {{- $_ := set .Values.podAnnotations "checksum.secrets"  (tpl (.Values.secrets | toYaml) . | sha256sum ) -}}
{{- end -}}



{{/* Templates defined after this line are private and only used in this file */}}


{{- define "harmonize.indexers.solana-indexer.PRIVATE.hardcoded_values" -}}
podAnnotations: {}

{{- end -}}