{{- define "harmonize.indexers.nbxplorer" -}}
  {{- $_ := merge .Values (include "harmonize.indexers.nbxplorer.PRIVATE.hardcoded_values" . | fromYaml) -}}
  {{- $_ := set .Values.podAnnotations "checksum.secrets"  (tpl (.Values.secrets | toYaml) . | sha256sum ) -}}
{{- end -}}


{{/* Templates defined after this line are private and only used in this file */}}


{{- define "harmonize.indexers.nbxplorer.PRIVATE.hardcoded_values" -}}
podAnnotations: {}

env:
{{- $chains := list }}
{{- if (hasKey .Ledgers "bitcoin") }}
  {{- $chains = append $chains "btc" }}
  NBXPLORER_BTCNODEENDPOINT: {{ .Ledgers.bitcoin.nodeEndpoint }}
  NBXPLORER_BTCRPCURL: {{ .Ledgers.bitcoin.url }}
  NBXPLORER_BTCRPCUSER: {{ .Ledgers.bitcoin.user }}
{{- end }}
{{- if (hasKey .Ledgers "bitcoincash") }}
  {{- $chains = append $chains "bch" }}
  NBXPLORER_BCHNODEENDPOINT: {{ .Ledgers.bitcoincash.nodeEndpoint }}
  NBXPLORER_BCHRPCURL: {{ .Ledgers.bitcoincash.url }}
  NBXPLORER_BCHRPCUSER: {{ .Ledgers.bitcoincash.user }}
{{- end }}
{{- if (hasKey .Ledgers "dogecoin") }}
  {{- $chains = append $chains "doge" }}
  NBXPLORER_CHAINS: "doge"
  NBXPLORER_DOGENODEENDPOINT: {{ .Ledgers.dogecoin.nodeEndpoint }}
  NBXPLORER_DOGERPCURL: {{ .Ledgers.dogecoin.url }}
  NBXPLORER_DOGERPCUSER: {{ .Ledgers.dogecoin.user }}
  NBXPLORER_DOGEFALLBACKFEERATE: {{ .Ledgers.dogecoin.fallbackFeeRate | default 100 }}
{{- end }}
{{- if (hasKey .Ledgers "dash") }}
  {{- $chains = append $chains "dash" }}
  NBXPLORER_DASHNODEENDPOINT: {{ .Ledgers.dash.nodeEndpoint }}
  NBXPLORER_DASHRPCURL: {{ .Ledgers.dash.url }}
  NBXPLORER_DASHRPCUSER: {{ .Ledgers.dash.user }}
  NBXPLORER_DASHFALLBACKFEERATE: {{ .Ledgers.dash.fallbackFeeRate | default 100 }}
{{- end }}
{{- if (hasKey .Ledgers "litecoin") }}
  {{- $chains = append $chains "ltc" }}
  NBXPLORER_LTCNODEENDPOINT: {{ .Ledgers.litecoin.nodeEndpoint }}
  NBXPLORER_LTCRPCURL: {{ .Ledgers.litecoin.url }}
  NBXPLORER_LTCRPCUSER: {{ .Ledgers.litecoin.user }}
{{- end }}
  NBXPLORER_CHAINS: {{ join "," $chains }}

secrets:
  passwords:
    enabled: true
    stringData:
      {{- if (hasKey .Ledgers "bitcoin") }}
      NBXPLORER_BTCRPCPASSWORD: '{{ .Ledgers.bitcoin.password }}'
      {{- end }}
      {{- if (hasKey .Ledgers "bitcoincash") }}
      NBXPLORER_BCHRPCPASSWORD: '{{ .Ledgers.bitcoincash.password }}'
      {{- end }}
      {{- if (hasKey .Ledgers "dogecoin") }}
      NBXPLORER_DOGERPCPASSWORD: '{{ .Ledgers.dogecoin.password }}'
      {{- end }}
      {{- if (hasKey .Ledgers "dash") }}
      NBXPLORER_DASHRPCPASSWORD: '{{ .Ledgers.dash.password }}'
      {{- end }}
      {{- if (hasKey .Ledgers "litecoin") }}
      NBXPLORER_LTCRPCPASSWORD: '{{ .Ledgers.litecoin.password }}'
      {{- end }}

{{- end -}}