{{- define "harmonize.indexers.xtzindexer" -}}
  {{- $_ := merge .Values (include "harmonize.indexers.xtzindexer.PRIVATE.hardcoded_values" . | fromYaml) -}}
  {{- $_ := set .Values.podAnnotations "checksum.secrets"  (tpl (.Values.secrets | toYaml) . | sha256sum ) -}}
{{- end -}}



{{/* Templates defined after this line are private and only used in this file */}}


{{- define "harmonize.indexers.xtzindexer.PRIVATE.hardcoded_values" -}}
podAnnotations: {}

{{- end -}}