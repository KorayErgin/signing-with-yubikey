{{/*
api-management-uis Helper - YARP reverse proxy for UIS routing

This component routes requests to either Events API or UIS API services based on path prefix:
- Requests with ledger prefix (e.g., /tron-testnet/*) -> UIS API for that ledger
- Requests without matching prefix -> Events API (fallback)

Architecture follows charts-next pattern:
- Events API service registered without Prefix (catches unmatched requests for /track, /events)
- Each UIS API service registered with Prefix (catches ledger-specific balance/transaction requests)
*/}}

{{- define "harmonize.components.api-management-uis" -}}
{{- $root := . -}}
{{- $originalRoot := $root.Original | default $root -}}

{{/* Set pod annotations for config checksums */}}
{{- $_ := set $root.Values.podAnnotations "checksum/config" (include "harmonize.components.api-management-uis.PRIVATE.gateway_services" $originalRoot | sha256sum) -}}

{{/* Configure api-management-uis */}}
{{- $_ := mergeOverwrite .Values (include "harmonize.components.api-management-uis.PRIVATE.config" (dict "Original" $originalRoot) | fromYaml) -}}

{{- end -}}


{{- define "harmonize.components.api-management-uis.url.internal" -}}
  {{- $root := . -}}
  {{- if .Original -}}
    {{- $root = .Original -}}
  {{- end -}}
  {{/* api-management-uis listens on port 8080 */}}
  {{- printf "http://%s-harmonize-api-management-uis:8080" $root.Release.Name -}}
{{- end -}}


{{/* Templates defined after this line are private and only used in this file */}}

{{- define "harmonize.components.api-management-uis.PRIVATE.config" -}}
{{/*
api-management-uis Configuration
Builds Gateway.Services dynamically from enabled UIS ledgers
*/}}
{{- $root := .Original -}}

{{/* Build Gateway.Services list */}}
{{- $services := include "harmonize.components.api-management-uis.PRIVATE.gateway_services" $root | fromYamlArray -}}

configMaps:
  config:
    enabled: true
    data:
      appsettings.json: |
        {
          "Logging": {
            "LogLevel": {
              "Default": "{{ include "defines.logging.loglevel.dotnet" $root }}",
              "Microsoft.AspNetCore": "Warning",
              "Yarp.ReverseProxy": "Warning"
            },
            "Console": {
              "FormatterName": "Simple",
              "FormatterOptions": {
                "SingleLine": true,
                "IncludeScopes": false,
                "ColorBehavior": 1
              }
            }
          },
          "AllowedHosts": "*",
          "Port": "8080",
          "HealthcheckPort": "8081",
          "CORS": {
            "AllowedOrigins": "http://{{ $root.Release.Name }}-harmonize-ledger-accounting"
          },
          "Gateway": {
            "Services": {{ $services | toJson }}
          }
        }

{{/* Service exposes port 8080 for HTTP and 8081 for health */}}
service:
  main:
    ports:
      http:
        port: 8080
        targetPort: 8080
      healthcheck:
        port: 8081
        targetPort: 8081

{{/* Health probes - using named port from service */}}
probes:
  liveness:
    enabled: true
    type: HTTP
    path: /health/live
    port: healthcheck
  startup:
    enabled: true
    type: HTTP
    path: /health/ready
    port: healthcheck
  readiness:
    enabled: true
    type: HTTP
    path: /health/ready
    port: healthcheck

persistence:
  config:
    enabled: true
    name: {{ printf "%s-harmonize-api-management-uis-config" $root.Release.Name | quote }}
    type: configMap
    mountPath: /opt/app-root/appsettings.json
    subPath: appsettings.json

{{- end -}}


{{- define "harmonize.components.api-management-uis.PRIVATE.gateway_services" -}}
{{/*
Builds the Gateway.Services YAML array for api-management-uis
- First entry: Events API (no Prefix, catches /track, /events)
- Subsequent entries: Each UIS API with Prefix matching ledger-id
*/}}
{{- $root := . -}}

{{/* Events API - catches unmatched requests (like /track, /events) */}}
- Id: events
  BaseUrl: {{ include "harmonize.components.events-api.url.internal" $root | quote }}
  SpecificationPath: swagger/v1/swagger.json
  CanFail: false
{{/* UIS API services - each with Prefix for routing */}}
{{- range $ledgerName, $ledger := $root.Values.harmonize.ledgers -}}
  {{- range $networkName, $network := $ledger -}}
    {{- if and $network.enabled (index $network "enableUIS" | default false) -}}
      {{- $ledgerId := $ledgerName -}}
      {{- if ne $networkName "mainnet" -}}
        {{- $ledgerId = printf "%s-%s" $ledgerName $networkName -}}
      {{- end -}}
      {{- $apiPort := include "harmonize.indexers.uis.api-port" $root -}}
      {{- $uisApiUrl := printf "http://%s-harmonize-uis-api-%s-%s:%s" $root.Release.Name $ledgerName $networkName $apiPort }}
- Id: {{ $ledgerId | quote }}
  BaseUrl: {{ $uisApiUrl | quote }}
  SpecificationPath: swagger/v1/swagger.json
  Prefix: {{ $ledgerId | quote }}
  Tag: {{ printf "%s %s" ($ledgerName | title) ($networkName | title) | quote }}
  CanFail: true
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- end -}}

