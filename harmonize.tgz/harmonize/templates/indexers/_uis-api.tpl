{{- define "harmonize.indexers.uis-api-xrpl" -}}
{{- include "harmonize.indexers.uis-api.PRIVATE.configure" (list "xrpl" .) -}}
{{- end -}}


{{- define "harmonize.indexers.uis-api-xrpl.url.internal" -}}
  {{- include "harmonize.indexers.uis-api.PRIVATE.url.internal" (list . "xrpl") -}}
{{- end -}}


{{- define "harmonize.indexers.uis-api-solana" -}}
{{- include "harmonize.indexers.uis-api.PRIVATE.configure" (list "solana" .) -}}
{{- end -}}


{{- define "harmonize.indexers.uis-api-solana.url.internal" -}}
  {{- include "harmonize.indexers.uis-api.PRIVATE.url.internal" (list . "solana") -}}
{{- end -}}


{{- define "harmonize.indexers.uis-api-tron" -}}
{{- include "harmonize.indexers.uis-api.PRIVATE.configure" (list "tron" .) -}}
{{- end -}}


{{- define "harmonize.indexers.uis-api-tron.url.internal" -}}
  {{- include "harmonize.indexers.uis-api.PRIVATE.url.internal" (list . "tron") -}}
{{- end -}}


{{- define "harmonize.indexers.uis-api-evm" -}}
{{- include "harmonize.indexers.uis-api.PRIVATE.configure" (list "evm" .) -}}
{{- end -}}


{{- define "harmonize.indexers.uis-api-evm.url.internal" -}}
  {{- include "harmonize.indexers.uis-api.PRIVATE.url.internal" (list . "evm") -}}
{{- end -}}


{{- define "harmonize.indexers.uis-api-avalanche-c-chain" -}}
{{- include "harmonize.indexers.uis-api.PRIVATE.configure" (list "avalanche-c-chain" .) -}}
{{- end -}}


{{- define "harmonize.indexers.uis-api-avalanche-c-chain.url.internal" -}}
  {{- include "harmonize.indexers.uis-api.PRIVATE.url.internal" (list . "avalanche-c-chain") -}}
{{- end -}}


{{- define "harmonize.indexers.uis-api-stellar" -}}
{{- include "harmonize.indexers.uis-api.PRIVATE.configure" (list "stellar" .) -}}
{{- end -}}


{{- define "harmonize.indexers.uis-api-stellar.url.internal" -}}
  {{- include "harmonize.indexers.uis-api.PRIVATE.url.internal" (list . "stellar") -}}
{{- end -}}


{{/* Ethereum - unified legacy/UIS support (uses EVM images when enableUIS=true) */}}
{{- define "harmonize.indexers.uis-api-ethereum" -}}
{{- include "harmonize.indexers.uis-api.PRIVATE.configure" (list "ethereum" .) -}}
{{- end -}}


{{- define "harmonize.indexers.uis-api-ethereum.url.internal" -}}
  {{- include "harmonize.indexers.uis-api.PRIVATE.url.internal" (list . "ethereum") -}}
{{- end -}}


{{/* Polygon - unified legacy/UIS support (uses EVM images when enableUIS=true) */}}
{{- define "harmonize.indexers.uis-api-polygon" -}}
{{- include "harmonize.indexers.uis-api.PRIVATE.configure" (list "polygon" .) -}}
{{- end -}}


{{- define "harmonize.indexers.uis-api-polygon.url.internal" -}}
  {{- include "harmonize.indexers.uis-api.PRIVATE.url.internal" (list . "polygon") -}}
{{- end -}}


{{/* BSC - unified legacy/UIS support (uses EVM images when enableUIS=true) */}}
{{- define "harmonize.indexers.uis-api-bsc" -}}
{{- include "harmonize.indexers.uis-api.PRIVATE.configure" (list "bsc" .) -}}
{{- end -}}


{{- define "harmonize.indexers.uis-api-bsc.url.internal" -}}
  {{- include "harmonize.indexers.uis-api.PRIVATE.url.internal" (list . "bsc") -}}
{{- end -}}


{{/* Templates defined after this line are private and only used in this file */}}

{{/* Private helper: Configure API for any protocol */}}
{{/* NOTE: XRPL uses .NET API (shared-indexer_xrpl-api), others use Rust (shared-indexer_generic-api) */}}
{{/* Each deployment serves a SINGLE network (like charts-next) */}}
{{- define "harmonize.indexers.uis-api.PRIVATE.configure" -}}
{{- $protocol := index . 0 -}}
{{- $root := index . 1 -}}

{{/* Get the target network from _uisNetwork (set by uis-deployments.tpl) */}}
{{- $network := $root.Values._uisNetwork -}}

{{/* Load protocol metadata */}}
{{- $meta := include "harmonize.indexers.uis.PRIVATE.protocol-metadata" $protocol | fromJson -}}

{{/* Merge common hardcoded values */}}
{{- $_ := merge $root.Values (include "harmonize.indexers.uis-api.PRIVATE.hardcoded_values" $root | fromYaml) -}}

{{/* Build dynamic environment variables for this specific network */}}
{{- $env := dict -}}

{{/* Add RUST_LOG (LOG_LEVEL not used by API - only RUST_LOG per next chart) */}}
{{- $_ := set $env "RUST_LOG" (include "defines.logging.loglevel" $root) -}}

{{/* Get network configuration for this specific network */}}
{{- $ledgers := index $root.Values.harmonize.ledgers $meta.ledgerKey | default dict -}}
{{- $networkConfig := index $ledgers $network | default dict -}}

{{/* Set NODE_ADDR for API - uses this network's URI */}}
{{- if $networkConfig -}}
  {{- $uri := index $networkConfig $meta.uriField | default "" -}}
  {{- if $uri -}}
    {{- $_ := set $env "NODE_ADDR" $uri -}}
  {{- end -}}
{{- end -}}

{{/* Set CHAIN_ID if protocol requires it */}}
{{- if and $meta.hasChainId $networkConfig -}}
  {{- $chainIdValue := index $networkConfig "chainId" | default 0 -}}
  {{- if $chainIdValue -}}
    {{- $_ := set $env "CHAIN_ID" (printf "%.0f" (float64 $chainIdValue)) -}}
  {{- end -}}
{{- end -}}

{{/* Telemetry configuration with specific network */}}
{{- $componentName := printf "uis-api-%s-%s" $protocol $network -}}
{{- $_ := set $env "TelemetryServiceName" $componentName -}}
{{- $grpcEndpoint := tpl (index $root.Values.harmonize.telemetry.otel "grpcEndpoint") $root -}}
{{- $_ := set $env "TelemetryGrpcEndpoint" $grpcEndpoint -}}

{{/* IncludeScopes for .NET (XRPL) OpenTelemetry logging (optional) */}}
{{- if $meta.isDotnet -}}
  {{- if and (hasKey $root.Values.harmonize "opentelemetry") (hasKey $root.Values.harmonize.opentelemetry "includeScopes") -}}
    {{- $_ := set $env "IncludeScopes" (toString $root.Values.harmonize.opentelemetry.includeScopes) -}}
  {{- end -}}
{{- end -}}

{{/* LISTEN_ADDR - both .NET and Rust APIs use the standard UIS API port */}}
{{- $apiPort := include "harmonize.indexers.uis.api-port" . -}}
{{- $_ := set $env "LISTEN_ADDR" (printf "0.0.0.0:%s" $apiPort) -}}

{{/* API does NOT use DATABASE_URL (no database access per next chart) */}}

{{/* TLS: Configure SSL_CERT_FILE based on protocol (.NET or Rust) to trust rootCA */}}
{{- include "harmonize.indexers.uis.configure-tls-env" (list $root $env $protocol) -}}

{{/* Merge environment variables using shared helper */}}
{{- include "harmonize.indexers.uis.merge-env" (list $root $env) -}}

{{- end -}}

{{/*
API URL helper - now includes network for per-network deployments
Args: (list $ctx $protocol) where $ctx can be:
  - (list $root $network) for per-network URLs
  - $root for legacy compatibility
*/}}
{{- define "harmonize.indexers.uis-api.PRIVATE.url.internal" -}}
  {{- $ctx := index . 0 -}}
  {{- $protocol := index . 1 -}}
  {{- $root := $ctx -}}
  {{- $network := "" -}}
  {{/* Handle (list $root $network) pattern for per-network URLs */}}
  {{- if kindIs "slice" $ctx -}}
    {{- $root = index $ctx 0 -}}
    {{- $network = index $ctx 1 -}}
  {{- else if hasKey $ctx "Original" -}}
    {{/* Handle bjw-s context with Original field */}}
    {{- $root = $ctx.Original -}}
  {{- end -}}
  {{/* Load protocol metadata for port determination */}}
  {{- $meta := include "harmonize.indexers.uis.PRIVATE.protocol-metadata" $protocol | fromJson -}}
  {{/* XRPL (.NET) uses port 9001, Rust APIs use port 8080 */}}
  {{- $defaultPort := 8080 -}}
  {{- if $meta.isDotnet -}}
    {{- $defaultPort = 9001 -}}
  {{- end -}}
  {{/* Get port from uis.api.<protocol>.service.main.ports.http.port */}}
  {{- $port := index $root.Values.uis "api" $protocol "service" "main" "ports" "http" "port" | default $defaultPort -}}
  {{/* Include network in URL if provided (per-network pattern) */}}
  {{- if $network -}}
    {{- printf "http://%s-%s-uis-api-%s-%s:%d" $root.Release.Name $root.Chart.Name $protocol $network ($port | int) -}}
  {{- else -}}
    {{/* Legacy pattern without network */}}
    {{- printf "http://%s-%s-uis-api-%s:%d" $root.Release.Name $root.Chart.Name $protocol ($port | int) -}}
  {{- end -}}
{{- end -}}

{{- define "harmonize.indexers.uis-api.PRIVATE.hardcoded_values" -}}
{{- include "harmonize.indexers.uis.common-hardcoded-values" . }}
secrets:
  db:
    enabled: false
    stringData: {}
{{- end -}}

