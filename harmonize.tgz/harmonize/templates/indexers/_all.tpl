{{/* These changes are applied to all harmonize indexers */}}
{{- define "harmonize.indexers.all" -}}

  {{- include "harmonize.components.all" . -}}

{{- end -}}