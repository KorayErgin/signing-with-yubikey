{{- define "harmonize.indexers.uis-processor-xrpl" -}}
{{- include "harmonize.indexers.uis-processor.PRIVATE.configure" (list "xrpl" .) -}}
{{- end -}}


{{- define "harmonize.indexers.uis-processor-solana" -}}
{{- include "harmonize.indexers.uis-processor.PRIVATE.configure" (list "solana" .) -}}
{{- end -}}


{{- define "harmonize.indexers.uis-processor-tron" -}}
{{- include "harmonize.indexers.uis-processor.PRIVATE.configure" (list "tron" .) -}}
{{- end -}}


{{- define "harmonize.indexers.uis-processor-evm" -}}
{{- include "harmonize.indexers.uis-processor.PRIVATE.configure" (list "evm" .) -}}
{{- end -}}

{{- define "harmonize.indexers.uis-processor-avalanche-c-chain" -}}
{{- include "harmonize.indexers.uis-processor.PRIVATE.configure" (list "avalanche-c-chain" .) -}}
{{- end -}}

{{- define "harmonize.indexers.uis-processor-stellar" -}}
{{- include "harmonize.indexers.uis-processor.PRIVATE.configure" (list "stellar" .) -}}
{{- end -}}


{{/* Ethereum - unified legacy/UIS support */}}
{{- define "harmonize.indexers.uis-processor-ethereum" -}}
{{- include "harmonize.indexers.uis-processor.PRIVATE.configure" (list "ethereum" .) -}}
{{- end -}}


{{/* Polygon - unified legacy/UIS support */}}
{{- define "harmonize.indexers.uis-processor-polygon" -}}
{{- include "harmonize.indexers.uis-processor.PRIVATE.configure" (list "polygon" .) -}}
{{- end -}}


{{/* BSC - unified legacy/UIS support */}}
{{- define "harmonize.indexers.uis-processor-bsc" -}}
{{- include "harmonize.indexers.uis-processor.PRIVATE.configure" (list "bsc" .) -}}
{{- end -}}


{{/* Templates defined after this line are private and only used in this file */}}

{{/* Private helper: Configure processor for any protocol */}}
{{/* NOTE: Processor is a .NET application for ALL protocols (same image: shared-indexer_processor) */}}
{{/* Each deployment processes a SINGLE network with its own database schema (like charts-next) */}}
{{- define "harmonize.indexers.uis-processor.PRIVATE.configure" -}}
{{- $protocol := index . 0 -}}
{{- $root := index . 1 -}}

{{/* Get the target network from _uisNetwork (set by uis-deployments.tpl) */}}
{{- $network := $root.Values._uisNetwork -}}

{{/* Merge common hardcoded values and processor-specific secrets structure */}}
{{- $_ := merge $root.Values (include "harmonize.indexers.uis-processor.PRIVATE.hardcoded_values" $root | fromYaml) -}}

{{/* Static env vars (ASPNETCORE_URLS, SkipServiceBusConnection, EventCleanupRetentionDays) come from values.yaml */}}

{{/* Build dynamic environment variables for .NET processor */}}
{{- $env := dict -}}

{{/* Set ledger and network (single network per deployment) */}}
{{- $_ := set $env "ledger" $protocol -}}
{{- $_ := set $env "network" $network -}}
{{/* QueueNameLedgerSuffix format: {protocol}-{network} */}}
{{- $_ := set $env "QueueNameLedgerSuffix" (printf "%s-%s" $protocol $network) -}}

{{/* Telemetry configuration - component name for tracing/metrics */}}
{{- $componentName := printf "uis-processor-%s-%s" $protocol $network -}}
{{- $_ := set $env "TelemetryServiceName" $componentName -}}
{{- $grpcEndpoint := tpl (index $root.Values.harmonize.telemetry.otel "grpcEndpoint") $root -}}
{{- $_ := set $env "TelemetryGrpcEndpoint" $grpcEndpoint -}}

{{/* IncludeScopes for .NET OpenTelemetry logging (optional) */}}
{{- if and (hasKey $root.Values.harmonize "opentelemetry") (hasKey $root.Values.harmonize.opentelemetry "includeScopes") -}}
  {{- $_ := set $env "IncludeScopes" (toString $root.Values.harmonize.opentelemetry.includeScopes) -}}
{{- end -}}

{{/* Build secrets for .NET database connections using network-specific schema */}}
{{- $schemaName := include "harmonize.indexers.uis.schema-name" (list $protocol $network) -}}
{{- $eventsSchema := "uis_events" -}}
{{- $secretsData := dict -}}
{{/* PostgresConnectionStringEvents points to events API schema */}}
{{- $eventsConnStr := include "harmonize.defines.uris.dotnet" (list $root $eventsSchema) -}}
{{- $_ := set $secretsData "PostgresConnectionStringEvents" $eventsConnStr -}}
{{/* PostgresConnectionStringOutbox points to network-specific schema (uis_{protocol}_{network}) */}}
{{- $outboxConnStr := include "harmonize.defines.uris.dotnet" (list $root $schemaName) -}}
{{- $_ := set $secretsData "PostgresConnectionStringOutbox" $outboxConnStr -}}

{{/* Configure secrets and envFrom using shared helper */}}
{{- include "harmonize.indexers.uis.configure-db-secret" (list $root $secretsData) -}}

{{/* TLS: Configure SSL_CERT_FILE for .NET processor to trust rootCA */}}
{{- include "harmonize.indexers.uis.configure-tls-env-processor" (list $root $env) -}}

{{/* Merge environment variables using shared helper */}}
{{- include "harmonize.indexers.uis.merge-env" (list $root $env) -}}

{{- end -}}

{{- define "harmonize.indexers.uis-processor.PRIVATE.hardcoded_values" -}}
{{- include "harmonize.indexers.uis.common-hardcoded-values" . }}
secrets:
  db:
    enabled: false
    stringData: {}
{{- end -}}

