{{/*
UIS Helper Templates
Reusable helper functions for UIS component configuration
*/}}

{{/*
Helper: Construct truncated component name for Kubernetes resources
K8s names are limited to 63 chars. This helper creates a nameOverride that,
when combined with the release name, stays within the limit.

Args: list with [releaseName, chartName, componentType, protocol, network]
Returns: truncated nameOverride like "harmonize-uis-indexer-avalanche-c-chain-fuj"

The format is: {releaseName}-{chartName}-{componentType}-{protocol}-{network}
We truncate from the END of the name to stay within 63 chars total.

Example:
  Release: "my-release"
  Result: "my-release-harmonize-uis-indexer-avalanche-c-chain-fuji" (truncated if needed)
*/}}
{{- define "harmonize.indexers.uis.truncated-name" -}}
  {{- $releaseName := index . 0 -}}
  {{- $chartName := index . 1 -}}
  {{- $componentType := index . 2 -}}
  {{- $protocol := index . 3 -}}
  {{- $network := index . 4 -}}
  {{- $fullSuffix := printf "%s-%s-%s-%s" $chartName $componentType $protocol $network -}}
  {{/* Calculate max length for suffix: 63 - len(release) - 1 (for hyphen) */}}
  {{- $maxSuffixLen := sub 63 (add (len $releaseName) 1) | int -}}
  {{/* Ensure we have at least some space for the suffix */}}
  {{- if lt $maxSuffixLen 10 -}}
    {{- $maxSuffixLen = 10 -}}
  {{- end -}}
  {{/* Truncate and trim trailing hyphen */}}
  {{- $fullSuffix | trunc $maxSuffixLen | trimSuffix "-" -}}
{{- end -}}

{{/*
Helper: Construct ADDRESS_API_URL for account lookups
Args: list with [protocol, network, eventsApiUrl]
Returns: string like "http://events-api:8080/tron-mainnet/accounts"

Example:
  {{- $url := include "harmonize.indexers.uis.address-api-url" (list "tron" "mainnet" "http://events-api:8080") -}}
  Result: "http://events-api:8080/tron-mainnet/accounts"
*/}}
{{- define "harmonize.indexers.uis.address-api-url" -}}
  {{- $protocol := index . 0 -}}
  {{- $network := index . 1 -}}
  {{- $eventsApiUrl := index . 2 -}}
  {{- printf "%s/%s-%s/accounts" $eventsApiUrl $protocol $network -}}
{{- end -}}

{{/*
Helper: Construct environment variable name with protocol and network suffix
Args: list with [prefix, protocol, network]
Returns: string like "NODE_URI_TRON_MAINNET"

Example:
  {{- $varName := include "harmonize.indexers.uis.env-var-name" (list "NODE_URI" "tron" "mainnet") -}}
  Result: "NODE_URI_TRON_MAINNET"

  {{- $varName := include "harmonize.indexers.uis.env-var-name" (list "ADAPTER_ENDPOINT" "solana" "devnet") -}}
  Result: "ADAPTER_ENDPOINT_SOLANA_DEVNET"
*/}}
{{- define "harmonize.indexers.uis.env-var-name" -}}
  {{- $prefix := index . 0 -}}
  {{- $protocol := index . 1 -}}
  {{- $network := index . 2 -}}
  {{- printf "%s_%s_%s" $prefix (upper $protocol) (upper $network | replace "-" "_") -}}
{{- end -}}

{{/*
Helper: Construct ledger ID from protocol and network
Ledger ID format: {protocol} for mainnet, {protocol}-{network} for other networks

Args: list with [protocol, network]
Returns: string like "xrpl" for mainnet, "xrpl-testnet" for testnet

Example:
  {{- $ledgerId := include "harmonize.indexers.uis.ledger-id" (list "xrpl" "mainnet") -}}
  Result: "xrpl"

  {{- $ledgerId := include "harmonize.indexers.uis.ledger-id" (list "xrpl" "testnet") -}}
  Result: "xrpl-testnet"

  {{- $ledgerId := include "harmonize.indexers.uis.ledger-id" (list "tron" "nile") -}}
  Result: "tron-nile"
*/}}
{{- define "harmonize.indexers.uis.ledger-id" -}}
  {{- $protocol := index . 0 -}}
  {{- $network := index . 1 -}}
  {{- if eq $network "mainnet" -}}
    {{- $protocol -}}
  {{- else -}}
    {{- printf "%s-%s" $protocol $network -}}
  {{- end -}}
{{- end -}}

{{/*
Helper: Build list of enabled UIS ledgers with their API URLs for Caddy routing
Iterates through harmonize.ledgers and returns enabled UIS ledgers with URLs

Args: root context (typically $originalRoot or . with access to .Values.harmonize.ledgers and .Release.Name)
Returns: YAML list of dicts: [{name: "xrpl-testnet", uisApiUrl: "http://..."}]

Usage:
  {{- $uisLedgers := include "harmonize.indexers.uis.enabled-ledgers-with-urls" $originalRoot | fromYaml -}}
  {{- range $uisLedgers.items -}}
    Ledger: {{ .name }}, URL: {{ .uisApiUrl }}
  {{- end -}}

Note: Returns YAML with 'items' key containing the list to allow fromYaml parsing
*/}}
{{- define "harmonize.indexers.uis.enabled-ledgers-with-urls" -}}
  {{- $root := . -}}
  {{- $uisLedgers := list -}}
  {{- $apiPort := include "harmonize.indexers.uis.api-port" . -}}
  {{- range $ledgerName, $ledgerConfig := $root.Values.harmonize.ledgers -}}
    {{- range $networkName, $networkConfig := $ledgerConfig -}}
      {{- if and $networkConfig.enabled $networkConfig.enableUIS -}}
        {{/* Construct ledger ID using the helper */}}
        {{- $ledgerId := include "harmonize.indexers.uis.ledger-id" (list $ledgerName $networkName) -}}
        {{/* UIS API URL format: {release}-harmonize-uis-api-{ledger}-{network}:{port} */}}
        {{- $uisApiUrl := printf "http://%s-harmonize-uis-api-%s-%s:%s" $root.Release.Name $ledgerName $networkName $apiPort -}}
        {{- $uisLedgers = append $uisLedgers (dict "name" $ledgerId "uisApiUrl" $uisApiUrl) -}}
      {{- end -}}
    {{- end -}}
  {{- end -}}
items:
{{ $uisLedgers | toYaml }}
{{- end -}}

{{/*
Helper: Default UIS API port
Returns the standard port for UIS API services.
*/}}
{{- define "harmonize.indexers.uis.api-port" -}}
9001
{{- end -}}

{{/*
Helper: Default instance token for UIS services
Returns the default instance token used when none is configured.
This is a placeholder token for development/testing.
*/}}
{{- define "harmonize.indexers.uis.default-instance-token" -}}
11111111-1111-1111-1111-111111111111
{{- end -}}

{{/*
Helper: Configure telemetry environment variables
Sets TelemetryServiceName and TelemetryGrpcEndpoint in the provided env dict.

Args: list with [$env, $componentName, $grpcEndpoint]
Returns: nothing (modifies $env in place)

Usage:
  {{- include "harmonize.indexers.uis.configure-telemetry" (list $env $componentName $grpcEndpoint) -}}
*/}}
{{- define "harmonize.indexers.uis.configure-telemetry" -}}
  {{- $env := index . 0 -}}
  {{- $componentName := index . 1 -}}
  {{- $grpcEndpoint := index . 2 -}}
  {{- $_ := set $env "TelemetryServiceName" $componentName -}}
  {{- if $grpcEndpoint -}}
  {{- $_ := set $env "TelemetryGrpcEndpoint" $grpcEndpoint -}}
  {{- end -}}
{{- end -}}


{{/*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TLS/Certificate Helper Functions for UIS Components
These helpers enable TLS support for UIS components following existing Harmonize patterns
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
*/}}


{{/*
Helper: Get rootCA persistence configuration for UIS components
Returns persistence configuration to mount the rootCA certificate into pods.
This follows the same pattern used by other Harmonize components (oauth, frontend, etc.)

IMPORTANT: The ConfigMap name uses a template string that will be evaluated by bjw-s.
The harmonize.certificates.rootCA.secret_name helper internally uses (.Original | default .)
to get the main chart context, ensuring all components reference the same shared rootCA
ConfigMap created by certificates.yaml.

Args: $root context
Returns: YAML dict with rootca persistence configuration

Usage:
  {{- include "harmonize.indexers.uis.rootca-persistence" . | nindent 2 }}
*/}}
{{- define "harmonize.indexers.uis.rootca-persistence" -}}
rootca:
  # -- Enable configmap with rootCA for TLS certificate trust
  # @default -- .Values.harmonize.certificates.rootCA.enabled
  enabled: "{{ .Values.harmonize.certificates.rootCA.enabled }}"
  # The secret_name helper uses (.Original | default .) internally for correct ConfigMap name
  name: '{{ include "harmonize.certificates.rootCA.secret_name" . }}'
  type: configMap
  mountPath: /app/rootCA.crt
  subPath: rootCA.crt
{{- end -}}


{{/*
Helper: Get TLS environment variables for .NET components
.NET applications use SSL_CERT_FILE to trust additional CA certificates.
This is used by processor (all protocols) and XRPL indexer/api.

Args: $root context
Returns: YAML dict with TLS-related environment variables

Usage:
  {{- $tlsEnv := include "harmonize.indexers.uis.tls-env-dotnet" . | fromYaml -}}
  {{- $_ := merge $env $tlsEnv -}}
*/}}
{{- define "harmonize.indexers.uis.tls-env-dotnet" -}}
{{- if eq (tpl (.Values.harmonize.certificates.rootCA.enabled | toString) .) "true" -}}
# Trust custom CA certificate for HTTPS connections
SSL_CERT_FILE: "/app/rootCA.crt"
{{- end -}}
{{- end -}}


{{/*
Helper: Get TLS environment variables for Rust components
Rust applications use SSL_CERT_FILE to trust additional CA certificates.
This is used by generic indexer, adapter, and API (non-XRPL protocols).

Args: $root context
Returns: YAML dict with TLS-related environment variables

Usage:
  {{- $tlsEnv := include "harmonize.indexers.uis.tls-env-rust" . | fromYaml -}}
  {{- $_ := merge $env $tlsEnv -}}
*/}}
{{- define "harmonize.indexers.uis.tls-env-rust" -}}
{{- if eq (tpl (.Values.harmonize.certificates.rootCA.enabled | toString) .) "true" -}}
# Trust custom CA certificate for HTTPS connections
SSL_CERT_FILE: "/app/rootCA.crt"
{{- end -}}
{{- end -}}


{{/*
Helper: Configure TLS environment variables based on protocol metadata
Automatically selects .NET or Rust TLS configuration based on isDotnet flag.

Args: list with [$root, $env, $protocol]
Returns: nothing (modifies $env in place)

Usage:
  {{- include "harmonize.indexers.uis.configure-tls-env" (list $root $env $protocol) -}}
*/}}
{{- define "harmonize.indexers.uis.configure-tls-env" -}}
{{- $root := index . 0 -}}
{{- $env := index . 1 -}}
{{- $protocol := index . 2 -}}
{{- $meta := include "harmonize.indexers.uis.PRIVATE.protocol-metadata" $protocol | fromJson -}}
{{- if eq (tpl ($root.Values.harmonize.certificates.rootCA.enabled | toString) $root) "true" -}}
  {{- $_ := set $env "SSL_CERT_FILE" "/app/rootCA.crt" -}}
{{- end -}}
{{- end -}}


{{/*
Helper: Configure TLS environment variables for processor (.NET for all protocols)
The processor is always .NET regardless of protocol.

Args: list with [$root, $env]
Returns: nothing (modifies $env in place)

Usage:
  {{- include "harmonize.indexers.uis.configure-tls-env-processor" (list $root $env) -}}
*/}}
{{- define "harmonize.indexers.uis.configure-tls-env-processor" -}}
{{- $root := index . 0 -}}
{{- $env := index . 1 -}}
{{- if eq (tpl ($root.Values.harmonize.certificates.rootCA.enabled | toString) $root) "true" -}}
  {{- $_ := set $env "SSL_CERT_FILE" "/app/rootCA.crt" -}}
{{- end -}}
{{- end -}}
