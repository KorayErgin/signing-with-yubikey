{{- define "harmonize.indexers.xrplindexer" -}}
  {{- $_ := merge .Values (include "harmonize.indexers.xrplindexer.PRIVATE.hardcoded_values" . | fromYaml) -}}
  {{- $_ := set .Values.podAnnotations "checksum.secrets"  (tpl (.Values.secrets | toYaml) . | sha256sum ) -}}
{{- end -}}


{{/* Templates defined after this line are private and only used in this file */}}


{{- define "harmonize.indexers.xrplindexer.PRIVATE.hardcoded_values" -}}
podAnnotations: {}

{{- end -}}