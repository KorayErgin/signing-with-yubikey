{{- define "harmonize.indexers.stellar-indexer" -}}
  {{- $_ := merge .Values (include "harmonize.indexers.stellar-indexer.PRIVATE.hardcoded_values" . | fromYaml) -}}
  {{- $_ := set .Values.podAnnotations "checksum.secrets"  (tpl (.Values.secrets | toYaml) . | sha256sum ) -}}
{{- end -}}



{{/* Templates defined after this line are private and only used in this file */}}


{{- define "harmonize.indexers.stellar-indexer.PRIVATE.hardcoded_values" -}}
podAnnotations: {}

{{- end -}}