{{/*
UIS Protocol Metadata
Defines protocol-specific configuration variations to enable shared helper patterns

Metadata Fields Explained:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. uriField (string: "uri" or "url")
   - Specifies which field name to read from values.yaml for blockchain node endpoints
   - Use "uri": For protocols using `.harmonize.ledgers.<protocol>.<network>.uri`
   - Use "url": For protocols using `.harmonize.ledgers.<protocol>.<network>.url`
   - Controls NODE_URI environment variable generation
   - Example: XRPL uses "uri", Solana uses "url"

2. hasAdapter (bool)
   - Determines if protocol requires a separate adapter component
   - true: Generates ADAPTER_ENDPOINT environment variables for indexer
   - false: Indexer communicates directly with blockchain node
   - Example: XRPL does NOT use adapter (false), Solana DOES use adapter (true)

3. hasChainId (bool)
   - Determines if protocol requires CHAIN_ID environment variable
   - true: Reads chainId from network config and sets CHAIN_ID_{PROTOCOL}_{NETWORK}
   - false: No CHAIN_ID variable generated
   - Example: Tron requires chainId (mainnet=728126428, testnet=2494104990), others don't

4. hasCups (bool)
   - Determines if protocol uses CUPS (Calls Unified Per Second) rate limiting
   - true: Reads cups value from adapter config and sets CUPS environment variable
   - false: No CUPS configuration
   - Currently only used by Tron (default: 400 CUPS)

5. adapterUriField (string: "httpUri", "uri", "url", or null)
   - Specifies which field name to read for the adapter's NODE_ADDR
   - Use when the adapter uses a different endpoint type than other components
   - Example: Tron uses "httpUri" because the adapter needs HTTP API, but other
     components may use gRPC via "uri"
   - If not specified, falls back to uriField

6. ledgerKey (string)
   - Maps to the top-level key under `.harmonize.ledgers` in values.yaml
   - Used to lookup network configurations for this protocol
   - Must match values.yaml structure
   - Example: "xrpl" maps to `.harmonize.ledgers.xrpl`

6. isDotnet (bool)
   - Indicates whether the protocol uses .NET components (indexer, api)
   - true: Uses .NET connection strings, ASPNETCORE_URLS, NODE_ADDR pattern
   - false: Uses Rust connection strings, NODE_URI_{PROTOCOL}_{NETWORK} pattern
   - XRPL uses .NET components; Solana, Tron, EVM use Rust components
   - Note: The processor is .NET for ALL protocols (same shared-indexer_processor image)

Adding a New Protocol:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. Add entry to $metadata dict below with all 5 fields
2. Ensure values.yaml has matching structure under harmonize.ledgers.<ledgerKey>
3. Create corresponding templates:
   - _uis-indexer.tpl: Public entrypoint (harmonize.indexers.uis-indexer-<protocol>)
   - _uis-processor.tpl: Public entrypoint (harmonize.indexers.uis-processor-<protocol>)
   - _uis-api.tpl: Public entrypoint (harmonize.indexers.uis-api-<protocol>)
   - _uis-adapter.tpl: Only if hasAdapter=true (harmonize.indexers.uis-adapter-<protocol>)
4. Add image configuration to values.yaml indexers.uis-api.<protocol> section
*/}}

{{- define "harmonize.indexers.uis.PRIVATE.protocol-metadata" -}}
{{- $protocol := . -}}

{{/*
Protocol metadata registry - protocols are added incrementally per commit.
Each protocol commit adds its entry here and to all-protocols list.

IMPORTANT: Protocols with legacy indexer support (ethereum, polygon, bsc) use "uri" field
to match their existing legacy configuration, allowing users to add enableUIS: true + chainId
without changing existing uri values.
*/}}
{{- $metadata := dict
  "xrpl" (dict "uriField" "uri" "hasAdapter" false "hasChainId" false "hasCups" false "ledgerKey" "xrpl" "isDotnet" true)
  "solana" (dict "uriField" "url" "hasAdapter" true "hasChainId" true "hasCups" false "ledgerKey" "solana" "isDotnet" false)
  "tron" (dict "uriField" "uri" "adapterUriField" "httpUri" "hasAdapter" true "hasChainId" true "hasCups" true "ledgerKey" "tron" "isDotnet" false)
  "evm" (dict "uriField" "url" "hasAdapter" true "hasChainId" true "hasCups" true "ledgerKey" "evm" "isDotnet" false)
  "avalanche-c-chain" (dict "uriField" "url" "hasAdapter" true "hasChainId" true "hasCups" true "ledgerKey" "avalanche-c-chain" "isDotnet" false)
  "stellar" (dict "uriField" "url" "hasAdapter" true "hasChainId" false "hasCups" true "ledgerKey" "stellar" "isDotnet" false)
  "ethereum" (dict "uriField" "uri" "hasAdapter" true "hasChainId" true "hasCups" true "ledgerKey" "ethereum" "isDotnet" false "hasLegacyIndexer" true)
  "polygon" (dict "uriField" "uri" "hasAdapter" true "hasChainId" true "hasCups" true "ledgerKey" "polygon" "isDotnet" false "hasLegacyIndexer" true)
  "bsc" (dict "uriField" "uri" "hasAdapter" true "hasChainId" true "hasCups" true "ledgerKey" "bsc" "isDotnet" false "hasLegacyIndexer" true)
-}}

{{- $protocolMeta := index $metadata $protocol -}}
{{- if not $protocolMeta -}}
  {{- fail (printf "Unknown protocol '%s' in metadata lookup" $protocol) -}}
{{- end -}}

{{- $protocolMeta | toJson -}}
{{- end -}}


{{/*
Get list of all known UIS protocols from metadata
Returns: list of protocol names
NOTE: Protocols are added incrementally per commit
      ethereum/polygon/bsc added to unify legacy and UIS configurations
*/}}
{{- define "harmonize.indexers.uis.all-protocols" -}}
{{/* XRPL added in Commit 2, Solana added in Commit 3, Tron added in Commit 4, EVM added in Commit 5, Avalanche C-Chain added in Commit 6, Stellar added in Commit 7 */}}
{{/* ethereum/polygon/bsc added to unify legacy ethindexer and UIS configurations under same ledger key */}}
{{- list "xrpl" "solana" "tron" "evm" "avalanche-c-chain" "stellar" "ethereum" "polygon" "bsc" | toJson -}}
{{- end -}}


{{/*
Build components list for a protocol based on metadata
Args: protocol name (string)
Returns: list of components (e.g., ["indexer", "processor", "api", "adapter"])
*/}}
{{- define "harmonize.indexers.uis.protocol-components" -}}
{{- $protocol := . -}}
{{- $meta := include "harmonize.indexers.uis.PRIVATE.protocol-metadata" $protocol | fromJson -}}
{{- $components := list "indexer" "processor" "api" -}}
{{- if $meta.hasAdapter -}}
  {{- $components = append $components "adapter" -}}
{{- end -}}
{{- $components | toJson -}}
{{- end -}}


{{/*
Validate network configuration against protocol metadata
Args: (list $root $protocol $networkName $networkConfig)
Fails with descriptive error if configuration is invalid
*/}}
{{- define "harmonize.indexers.uis.validate-network-config" -}}
{{- $root := index . 0 -}}
{{- $protocol := index . 1 -}}
{{- $networkName := index . 2 -}}
{{- $networkConfig := index . 3 -}}
{{- $meta := include "harmonize.indexers.uis.PRIVATE.protocol-metadata" $protocol | fromJson -}}

{{/* Validation 1: UIS-only protocols (tron, evm) MUST have enableUIS=true when enabled */}}
{{- $uisOnlyProtocols := list "tron" "evm" -}}
{{- if and $networkConfig.enabled (has $protocol $uisOnlyProtocols) (not (index $networkConfig "enableUIS")) -}}
  {{- fail (printf "Configuration error for %s.%s: Protocol '%s' is UIS-only (no legacy indexer exists). When enabled=true, you must also set enableUIS=true. Add 'enableUIS: true' to harmonize.ledgers.%s.%s" $protocol $networkName $protocol $protocol $networkName) -}}
{{- end -}}

{{/* Validation 2: chainId should not be set if hasChainId is false */}}
{{- if and (not $meta.hasChainId) (index $networkConfig "chainId") -}}
  {{- fail (printf "Configuration error for %s.%s: 'chainId' is set but protocol '%s' has hasChainId=false in metadata. Either remove chainId from values.yaml or update _uis-metadata.tpl to set hasChainId=true for this protocol." $protocol $networkName $protocol) -}}
{{- end -}}

{{/* Validation 3: Warn if hasChainId is true but chainId is not set */}}
{{- if and $meta.hasChainId (not (index $networkConfig "chainId")) $networkConfig.enabled (index $networkConfig "enableUIS") -}}
  {{- fail (printf "Configuration error for %s.%s: Protocol '%s' has hasChainId=true but 'chainId' is not set in values.yaml. Add chainId to harmonize.ledgers.%s.%s" $protocol $networkName $protocol $protocol $networkName) -}}
{{- end -}}

{{/* Validation 4: URL field must be set if UIS is enabled */}}
{{- if and $networkConfig.enabled (index $networkConfig "enableUIS") -}}
  {{- $uriValue := index $networkConfig $meta.uriField | default "" -}}
  {{- if not $uriValue -}}
    {{- fail (printf "Configuration error for %s.%s: UIS is enabled but '%s' (RPC endpoint) is not set. Add %s to harmonize.ledgers.%s.%s" $protocol $networkName $meta.uriField $meta.uriField $protocol $networkName) -}}
  {{- end -}}
{{- end -}}

{{/* Validation 5: Detect conflicting configurations between unified ledger keys and evm ledger key */}}
{{/* e.g., both ethereum.mainnet and evm.ethereum-mainnet enabled with UIS would create duplicate deployments */}}
{{- $conflictMap := dict
  "ethereum" (dict "mainnet" "ethereum-mainnet" "testnet-sepolia" "ethereum-testnet-sepolia" "testnet-goerli" "ethereum-testnet-goerli")
  "polygon" (dict "mainnet" "polygon-mainnet" "testnet-mumbai" "polygon-testnet-mumbai" "testnet-amoy" "polygon-testnet-amoy")
  "bsc" (dict "mainnet" "bsc-mainnet" "testnet" "bsc-testnet")
-}}
{{- if and $networkConfig.enabled (index $networkConfig "enableUIS") (hasKey $conflictMap $protocol) -}}
  {{- $evmNetworkName := index (index $conflictMap $protocol) $networkName -}}
  {{- if $evmNetworkName -}}
    {{- $evmLedger := index $root.Values.harmonize.ledgers "evm" | default dict -}}
    {{- $evmNetwork := index $evmLedger $evmNetworkName | default dict -}}
    {{- if and (index $evmNetwork "enabled") (index $evmNetwork "enableUIS") -}}
      {{- fail (printf "Configuration conflict: Both '%s.%s' and 'evm.%s' have enabled=true and enableUIS=true. This would create duplicate UIS deployments. Please use only ONE of these configurations:\n  - RECOMMENDED: harmonize.ledgers.%s.%s (unified with legacy ethindexer)\n  - ALTERNATIVE: harmonize.ledgers.evm.%s (UIS-only)\nDisable one of them by setting enabled=false or enableUIS=false." $protocol $networkName $evmNetworkName $protocol $networkName $evmNetworkName) -}}
    {{- end -}}
  {{- end -}}
{{- end -}}

{{- end -}}


{{/*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Shared Helper Functions for UIS Components
These helpers reduce duplication across processor, indexer, and API templates
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
*/}}


{{/*
Get enabled networks for a protocol as comma-separated string
Args: (list $root $protocol)
Returns: comma-separated string of enabled network names (e.g., "mainnet,testnet")
*/}}
{{- define "harmonize.indexers.uis.enabled-networks-csv" -}}
{{- $root := index . 0 -}}
{{- $protocol := index . 1 -}}
{{- $meta := include "harmonize.indexers.uis.PRIVATE.protocol-metadata" $protocol | fromJson -}}
{{- $enabledNetworks := list -}}
{{- $ledgers := index $root.Values.harmonize.ledgers $meta.ledgerKey -}}
{{- range $networkName, $network := $ledgers -}}
  {{- if and $network.enabled (index $network "enableUIS") -}}
    {{- $enabledNetworks = append $enabledNetworks $networkName -}}
  {{- end -}}
{{- end -}}
{{- join "," $enabledNetworks -}}
{{- end -}}


{{/*
Get first enabled network for a protocol
Args: (list $root $protocol)
Returns: first enabled network name (string)
*/}}
{{- define "harmonize.indexers.uis.first-enabled-network" -}}
{{- $root := index . 0 -}}
{{- $protocol := index . 1 -}}
{{- $meta := include "harmonize.indexers.uis.PRIVATE.protocol-metadata" $protocol | fromJson -}}
{{- $firstNetwork := "" -}}
{{- $ledgers := index $root.Values.harmonize.ledgers $meta.ledgerKey -}}
{{- range $networkName, $network := $ledgers -}}
  {{- if and (not $firstNetwork) $network.enabled (index $network "enableUIS") -}}
    {{- $firstNetwork = $networkName -}}
  {{- end -}}
{{- end -}}
{{- $firstNetwork -}}
{{- end -}}


{{/*
Get schema name for a protocol and network (converts dashes to underscores)
Args: (list $protocol $network) OR $protocol (string) for backward compatibility
Returns: schema name like "uis_evm_arbitrum_sepolia" or "uis_xrpl_mainnet"
This matches the charts-next naming convention: uis_{protocol}_{network}
*/}}
{{- define "harmonize.indexers.uis.schema-name" -}}
{{- if kindIs "slice" . -}}
  {{- $protocol := index . 0 -}}
  {{- $network := index . 1 -}}
  {{- printf "uis_%s_%s" (replace "-" "_" $protocol) (replace "-" "_" $network) -}}
{{- else -}}
  {{/* Backward compatibility: single protocol argument (deprecated, kept for events API) */}}
  {{- $protocol := . -}}
  {{- printf "uis_%s" (replace "-" "_" $protocol) -}}
{{- end -}}
{{- end -}}


{{/*
Get DATABASE_URL in correct format based on protocol tech stack
Args: (list $root $protocol $schemaName)
Returns: Connection string in .NET format (XRPL) or Rust format (others)
*/}}
{{- define "harmonize.indexers.uis.database-url" -}}
{{- $root := index . 0 -}}
{{- $protocol := index . 1 -}}
{{- $schemaName := index . 2 -}}
{{- $meta := include "harmonize.indexers.uis.PRIVATE.protocol-metadata" $protocol | fromJson -}}
{{- if $meta.isDotnet -}}
  {{- include "harmonize.defines.uris.dotnet" (list $root $schemaName) -}}
{{- else -}}
  {{- include "harmonize.defines.uris.rust" (list $root $schemaName) -}}
{{- end -}}
{{- end -}}


{{/*
Get base database URL without schema (for init containers that create schemas)
Args: $root
Returns: postgres://user:pass@host:port/database (no schema in search_path)
*/}}
{{- define "harmonize.indexers.uis.database-url-base" -}}
{{- $root := . -}}
{{- include "harmonize.defines.uris.rust" (list $root "") -}}
{{- end -}}


{{/*
Get first enabled network's URI, name, chainId, and adapterUri for API components
Args: (list $root $protocol)
Returns: dict with "uri", "adapterUri", "networkName", and "chainId" keys
  - uri: The standard endpoint (used by most components)
  - adapterUri: The adapter-specific endpoint (falls back to uri if not configured)
*/}}
{{- define "harmonize.indexers.uis.first-network-uri" -}}
{{- $root := index . 0 -}}
{{- $protocol := index . 1 -}}
{{- $meta := include "harmonize.indexers.uis.PRIVATE.protocol-metadata" $protocol | fromJson -}}
{{- $result := dict "uri" "" "adapterUri" "" "networkName" "" "chainId" "" -}}
{{- $ledgers := index $root.Values.harmonize.ledgers $meta.ledgerKey -}}
{{- range $networkName, $network := $ledgers -}}
  {{- if and $network.enabled (index $network "enableUIS") -}}
    {{- $_ := set $result "uri" (index $network $meta.uriField | default "") -}}
    {{- $_ := set $result "networkName" $networkName -}}
    {{/* Set adapterUri - use adapterUriField if defined, otherwise fall back to uriField */}}
    {{- $adapterField := $meta.adapterUriField | default $meta.uriField -}}
    {{- $adapterUri := index $network $adapterField | default "" -}}
    {{/* If adapterUri is empty but uri is not, fall back to uri (for backwards compatibility) */}}
    {{- if and (not $adapterUri) (index $network $meta.uriField) -}}
      {{- $adapterUri = index $network $meta.uriField -}}
    {{- end -}}
    {{- $_ := set $result "adapterUri" $adapterUri -}}
    {{- if index $network "chainId" -}}
      {{/* Use printf %.0f to handle large numeric chainId values without scientific notation */}}
      {{- $_ := set $result "chainId" (printf "%.0f" (float64 (index $network "chainId"))) -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- $result | toJson -}}
{{- end -}}


{{/*
Common hardcoded values for UIS components (telemetry envFrom, TLS persistence)
This is the single source of truth for telemetry and TLS configuration
*/}}
{{- define "harmonize.indexers.uis.common-hardcoded-values" -}}
podAnnotations: {}
{{/* Inherit imagePullSecrets from harmonize.repository.pullSecrets */}}
{{- $imagePullSecrets := list -}}
{{- range $name, $config := .Values.harmonize.repository.pullSecrets -}}
  {{- if $config.enabled -}}
    {{- $imagePullSecrets = append $imagePullSecrets (dict "name" (printf "%s-harmonize-image-pull-secret-%s" $.Release.Name $name)) -}}
  {{- end -}}
{{- end -}}
{{- if $imagePullSecrets }}
imagePullSecrets:
{{ toYaml $imagePullSecrets | indent 2 }}
{{- end }}
envFrom:
  - configMapRef:
      name: '{{ include "harmonize.telemetry-config.open-telemetry-sdk-grpc" . }}'
      optional: true
  - configMapRef:
      name: '{{ include "harmonize.telemetry-config.syslog.configmap_name" . }}'
      optional: true
{{/* TLS: Mount rootCA certificate for trusting self-signed certificates */}}
{{/* This follows the same pattern used by other Harmonize components (oauth, frontend, etc.) */}}
persistence:
{{- include "harmonize.indexers.uis.rootca-persistence" . | nindent 2 }}
{{- end -}}


{{/*
Configure database secret and add to envFrom with pod annotations
Args: (list $root $secretsData)
- $root: Root context
- $secretsData: Dict of secret key-value pairs to add
*/}}
{{- define "harmonize.indexers.uis.configure-db-secret" -}}
{{- $root := index . 0 -}}
{{- $secretsData := index . 1 -}}

{{/* Ensure secrets structure exists */}}
{{- if not (index $root.Values "secrets") -}}
  {{- $_ := set $root.Values "secrets" (dict "db" (dict "enabled" false "stringData" (dict))) -}}
{{- end -}}

{{/* Configure secrets */}}
{{- $_ := set $root.Values.secrets.db "enabled" true -}}
{{- $_ := set $root.Values.secrets.db "stringData" $secretsData -}}

{{/* Add secret to envFrom */}}
{{- $secretName := printf "%s-%s" (include "bjw-s.common.lib.chart.names.fullname" $root) "db" -}}
{{- $secretEnvFrom := dict "secretRef" (dict "name" $secretName) -}}
{{- $_ := set $root.Values "envFrom" (append $root.Values.envFrom $secretEnvFrom) -}}

{{/* Set pod annotations for secret checksums */}}
{{- $_ := set $root.Values.podAnnotations "checksum.secrets" (tpl ($root.Values.secrets | toYaml) $root | sha256sum) -}}
{{- end -}}


{{/*
Safely merge environment variables avoiding cross-contamination between protocols
Args: (list $root $newEnv)
- $root: Root context
- $newEnv: Dict of new env vars to merge
*/}}
{{- define "harmonize.indexers.uis.merge-env" -}}
{{- $root := index . 0 -}}
{{- $newEnv := index . 1 -}}
{{/* Handle case where .Values.env doesn't exist (e.g., API which has no env in values.yaml) */}}
{{- $existingEnv := $root.Values.env | default dict -}}
{{/* Use deepCopy to prevent cross-contamination between protocol deployments */}}
{{- $mergedEnv := merge $newEnv (deepCopy $existingEnv) -}}
{{- $_ := set $root.Values "env" $mergedEnv -}}
{{- end -}}

