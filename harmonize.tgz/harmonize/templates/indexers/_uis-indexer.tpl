{{- define "harmonize.indexers.uis-indexer-xrpl" -}}
{{- include "harmonize.indexers.uis-indexer.PRIVATE.configure" (list "xrpl" .) -}}
{{- end -}}


{{- define "harmonize.indexers.uis-indexer-solana" -}}
{{- include "harmonize.indexers.uis-indexer.PRIVATE.configure" (list "solana" .) -}}
{{- end -}}


{{- define "harmonize.indexers.uis-indexer-tron" -}}
{{- include "harmonize.indexers.uis-indexer.PRIVATE.configure" (list "tron" .) -}}
{{- end -}}


{{- define "harmonize.indexers.uis-indexer-evm" -}}
{{- include "harmonize.indexers.uis-indexer.PRIVATE.configure" (list "evm" .) -}}
{{- end -}}

{{- define "harmonize.indexers.uis-indexer-avalanche-c-chain" -}}
{{- include "harmonize.indexers.uis-indexer.PRIVATE.configure" (list "avalanche-c-chain" .) -}}
{{- end -}}

{{- define "harmonize.indexers.uis-indexer-stellar" -}}
{{- include "harmonize.indexers.uis-indexer.PRIVATE.configure" (list "stellar" .) -}}
{{- end -}}


{{/* Ethereum - unified legacy/UIS support (uses EVM images when enableUIS=true) */}}
{{- define "harmonize.indexers.uis-indexer-ethereum" -}}
{{- include "harmonize.indexers.uis-indexer.PRIVATE.configure" (list "ethereum" .) -}}
{{- end -}}


{{/* Polygon - unified legacy/UIS support (uses EVM images when enableUIS=true) */}}
{{- define "harmonize.indexers.uis-indexer-polygon" -}}
{{- include "harmonize.indexers.uis-indexer.PRIVATE.configure" (list "polygon" .) -}}
{{- end -}}


{{/* BSC - unified legacy/UIS support (uses EVM images when enableUIS=true) */}}
{{- define "harmonize.indexers.uis-indexer-bsc" -}}
{{- include "harmonize.indexers.uis-indexer.PRIVATE.configure" (list "bsc" .) -}}
{{- end -}}


{{/* Templates defined after this line are private and only used in this file */}}

{{/* Private helper: Configure indexer for any protocol using metadata */}}
{{/* NOTE: XRPL uses .NET indexer (shared-indexer_xrpl-indexer), others use Rust (shared-indexer_generic-indexer) */}}
{{/* Each deployment indexes a SINGLE network with its own database schema (like charts-next) */}}
{{- define "harmonize.indexers.uis-indexer.PRIVATE.configure" -}}
{{- $protocol := index . 0 -}}
{{- $root := index . 1 -}}

{{/* Get the target network from _uisNetwork (set by uis-deployments.tpl) */}}
{{- $network := $root.Values._uisNetwork -}}

{{/* Load protocol metadata */}}
{{- $meta := include "harmonize.indexers.uis.PRIVATE.protocol-metadata" $protocol | fromJson -}}

{{/* Merge common hardcoded values and indexer-specific secrets structure */}}
{{- $_ := merge $root.Values (include "harmonize.indexers.uis-indexer.PRIVATE.hardcoded_values" $root | fromYaml) -}}

{{/* NOTE: Protocol-specific values (probes, service, env) are already merged by uis-deployments.tpl
     The orchestrator merges uis.indexer and uis.indexer.<protocol> before calling this template */}}

{{/* Build dynamic environment variables for this specific network */}}
{{- $env := dict -}}

{{/* Add RUST_LOG for Rust components (also works for .NET as fallback) */}}
{{- $_ := set $env "RUST_LOG" (include "defines.logging.loglevel" $root) -}}

{{/* Add metadata variables for metrics/logging */}}
{{- $_ := set $env "IS_ON_PREM" (toString $root.Values.harmonize.isOnPrem) -}}
{{/* Ledger is just the protocol name - the indexer code appends -{network} to construct the full ledger ID */}}
{{- $_ := set $env "ledger" $protocol -}}
{{/* Single network per deployment (like charts-next) */}}
{{- $_ := set $env "network" $network -}}

{{/* Telemetry configuration with specific network */}}
{{- $componentName := printf "uis-indexer-%s-%s" $protocol $network -}}
{{- $_ := set $env "TelemetryServiceName" $componentName -}}
{{- $grpcEndpoint := tpl (index $root.Values.harmonize.telemetry.otel "grpcEndpoint") $root -}}
{{- $_ := set $env "TelemetryGrpcEndpoint" $grpcEndpoint -}}

{{/* IncludeScopes for .NET (XRPL) OpenTelemetry logging (optional) */}}
{{- if $meta.isDotnet -}}
  {{- if and (hasKey $root.Values.harmonize "opentelemetry") (hasKey $root.Values.harmonize.opentelemetry "includeScopes") -}}
    {{- $_ := set $env "IncludeScopes" (toString $root.Values.harmonize.opentelemetry.includeScopes) -}}
  {{- end -}}
{{- end -}}

{{/* Build DATABASE_URL secret with network-specific schema (uis_{protocol}_{network}) */}}
{{- $secretsData := dict -}}
{{- $schemaName := include "harmonize.indexers.uis.schema-name" (list $protocol $network) -}}
{{- $dbUrl := include "harmonize.indexers.uis.database-url" (list $root $protocol $schemaName) -}}
{{- $_ := set $secretsData "DATABASE_URL" $dbUrl -}}

{{/* Get events API URL */}}
{{- $eventsApiUrl := include "harmonize.components.events-api.url.internal" $root -}}
{{/* EVENT_API_URL - points to events API root for event publishing */}}
{{- $_ := set $env "EVENT_API_URL" $eventsApiUrl -}}

{{/* Set ADAPTER_ADDR pointing to network-specific adapter */}}
{{- if $meta.hasAdapter -}}
  {{- $adapterEndpoint := include (printf "harmonize.indexers.uis-adapter-%s.endpoint" $protocol) (list $root $network) -}}
  {{- $_ := set $env "ADAPTER_ADDR" (printf "grpc://%s" $adapterEndpoint) -}}
{{- end -}}

{{/* Get network configuration for this specific network */}}
{{- $ledgers := index $root.Values.harmonize.ledgers $meta.ledgerKey | default dict -}}
{{- $networkConfig := index $ledgers $network | default dict -}}

{{/* Configure node URI for this network */}}
{{- $uriValue := "" -}}
{{- if $networkConfig -}}
  {{- $uriValue = index $networkConfig $meta.uriField | default "" -}}
{{- end -}}
{{- if $meta.isDotnet -}}
  {{/* XRPL (.NET) uses NODE_ADDR */}}
  {{- $_ := set $env "NODE_ADDR" $uriValue -}}
{{- else -}}
  {{/* Rust indexers use NODE_URI_{PROTOCOL}_{NETWORK} */}}
  {{- $uriVar := include "harmonize.indexers.uis.env-var-name" (list "NODE_URI" $protocol $network) -}}
  {{- $_ := set $env $uriVar $uriValue -}}
{{- end -}}

{{/* Set CHAIN_ID if protocol requires it */}}
{{- if and $meta.hasChainId $networkConfig -}}
  {{- $chainIdVar := include "harmonize.indexers.uis.env-var-name" (list "CHAIN_ID" $protocol $network) -}}
  {{- $chainIdValue := index $networkConfig "chainId" | default 0 -}}
  {{- $_ := set $env $chainIdVar (printf "%.0f" (float64 $chainIdValue)) -}}
{{- end -}}

{{/* Set ADDRESS_API_URL for this network */}}
{{- $addressApiVar := include "harmonize.indexers.uis.env-var-name" (list "ADDRESS_API_URL" $protocol $network) -}}
{{- $addressApiValue := include "harmonize.indexers.uis.address-api-url" (list $protocol $network $eventsApiUrl) -}}
{{- $_ := set $env $addressApiVar $addressApiValue -}}

{{/* Configure secrets and envFrom using shared helper */}}
{{- include "harmonize.indexers.uis.configure-db-secret" (list $root $secretsData) -}}

{{/* TLS: Configure SSL_CERT_FILE based on protocol (.NET or Rust) to trust rootCA */}}
{{- include "harmonize.indexers.uis.configure-tls-env" (list $root $env $protocol) -}}

{{/* Merge environment variables using shared helper */}}
{{- include "harmonize.indexers.uis.merge-env" (list $root $env) -}}

{{/* Add initContainer for Rust indexers to create schema before migrations run */}}
{{- if not $meta.isDotnet -}}
  {{- $initContainers := dict -}}
  {{- $_ := set $initContainers "init-db-schema" (dict
    "image" "docker.io/bitnamilegacy/postgresql:11.14.0"
    "imagePullPolicy" "IfNotPresent"
    "command" (list "sh" "-c" (printf "until psql \"$DATABASE_URL_BASE\" -c '\\q'; do echo 'Database is unavailable - sleeping'; sleep 1; done; echo 'Database is up - creating schema'; psql \"$DATABASE_URL_BASE\" -c 'CREATE SCHEMA IF NOT EXISTS %s'" $schemaName))
    "env" (list
      (dict "name" "DATABASE_URL_BASE" "value" (include "harmonize.indexers.uis.database-url-base" $root))
    )
  ) -}}
  {{- $_ := set $root.Values "initContainers" $initContainers -}}
{{- end -}}

{{- end -}}

{{- define "harmonize.indexers.uis-indexer.PRIVATE.hardcoded_values" -}}
{{- include "harmonize.indexers.uis.common-hardcoded-values" . }}
secrets:
  db:
    enabled: false
    stringData: {}
{{- end -}}

