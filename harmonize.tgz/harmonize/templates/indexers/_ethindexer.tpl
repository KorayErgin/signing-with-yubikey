{{- define "harmonize.indexers.ethindexer" -}}
  {{- $_ := merge .Values (include "harmonize.indexers.ethindexer.PRIVATE.hardcoded_values" . | fromYaml) -}}
  {{- $_ := set .Values.podAnnotations "checksum.secrets"  (tpl (.Values.secrets | toYaml) . | sha256sum ) -}}
{{- end -}}



{{/* Templates defined after this line are private and only used in this file */}}

env:
  OTEL_SDK_DISABLED: "true"
{{- define "harmonize.indexers.ethindexer.PRIVATE.hardcoded_values" -}}
podAnnotations: {}

{{- end -}}