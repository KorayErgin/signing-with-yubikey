{{- define "harmonize.indexers.uis-adapter-solana" -}}
{{- include "harmonize.indexers.uis-adapter.PRIVATE.configure" (list "solana" .) -}}
{{- end -}}


{{/*
Adapter endpoint helper - now includes network for per-network deployments
Args: (list $root $network) for per-network, or $root for legacy calls
*/}}
{{- define "harmonize.indexers.uis-adapter-solana.endpoint" -}}
  {{- include "harmonize.indexers.uis-adapter.PRIVATE.endpoint" (list . "solana") -}}
{{- end -}}


{{- define "harmonize.indexers.uis-adapter-tron" -}}
{{- include "harmonize.indexers.uis-adapter.PRIVATE.configure" (list "tron" .) -}}
{{- end -}}


{{- define "harmonize.indexers.uis-adapter-tron.endpoint" -}}
  {{- include "harmonize.indexers.uis-adapter.PRIVATE.endpoint" (list . "tron") -}}
{{- end -}}


{{- define "harmonize.indexers.uis-adapter-evm" -}}
{{- include "harmonize.indexers.uis-adapter.PRIVATE.configure" (list "evm" .) -}}
{{- end -}}


{{- define "harmonize.indexers.uis-adapter-evm.endpoint" -}}
  {{- include "harmonize.indexers.uis-adapter.PRIVATE.endpoint" (list . "evm") -}}
{{- end -}}


{{- define "harmonize.indexers.uis-adapter-avalanche-c-chain" -}}
{{- include "harmonize.indexers.uis-adapter.PRIVATE.configure" (list "avalanche-c-chain" .) -}}
{{- end -}}


{{- define "harmonize.indexers.uis-adapter-avalanche-c-chain.endpoint" -}}
  {{- include "harmonize.indexers.uis-adapter.PRIVATE.endpoint" (list . "avalanche-c-chain") -}}
{{- end -}}


{{- define "harmonize.indexers.uis-adapter-stellar" -}}
{{- include "harmonize.indexers.uis-adapter.PRIVATE.configure" (list "stellar" .) -}}
{{- end -}}


{{- define "harmonize.indexers.uis-adapter-stellar.endpoint" -}}
  {{- include "harmonize.indexers.uis-adapter.PRIVATE.endpoint" (list . "stellar") -}}
{{- end -}}


{{/* Ethereum - unified legacy/UIS support (uses EVM adapter when enableUIS=true) */}}
{{- define "harmonize.indexers.uis-adapter-ethereum" -}}
{{- include "harmonize.indexers.uis-adapter.PRIVATE.configure" (list "ethereum" .) -}}
{{- end -}}


{{- define "harmonize.indexers.uis-adapter-ethereum.endpoint" -}}
  {{- include "harmonize.indexers.uis-adapter.PRIVATE.endpoint" (list . "ethereum") -}}
{{- end -}}


{{/* Polygon - unified legacy/UIS support (uses EVM adapter when enableUIS=true) */}}
{{- define "harmonize.indexers.uis-adapter-polygon" -}}
{{- include "harmonize.indexers.uis-adapter.PRIVATE.configure" (list "polygon" .) -}}
{{- end -}}


{{- define "harmonize.indexers.uis-adapter-polygon.endpoint" -}}
  {{- include "harmonize.indexers.uis-adapter.PRIVATE.endpoint" (list . "polygon") -}}
{{- end -}}


{{/* BSC - unified legacy/UIS support (uses EVM adapter when enableUIS=true) */}}
{{- define "harmonize.indexers.uis-adapter-bsc" -}}
{{- include "harmonize.indexers.uis-adapter.PRIVATE.configure" (list "bsc" .) -}}
{{- end -}}


{{- define "harmonize.indexers.uis-adapter-bsc.endpoint" -}}
  {{- include "harmonize.indexers.uis-adapter.PRIVATE.endpoint" (list . "bsc") -}}
{{- end -}}


{{/* Templates defined after this line are private and only used in this file */}}


{{/*
Adapter endpoint helper - supports both legacy and per-network patterns
Args: (list $ctx $protocol) where $ctx can be:
  - (list $root $network) for per-network endpoints
  - $root for legacy compatibility
Returns: service endpoint like "release-chart-uis-adapter-evm-arbitrum-sepolia:8080"
Note: Uses truncated name to match the actual K8s service name (63 char limit)
*/}}
{{- define "harmonize.indexers.uis-adapter.PRIVATE.endpoint" -}}
  {{- $ctx := index . 0 -}}
  {{- $protocol := index . 1 -}}
  {{- $root := $ctx -}}
  {{- $network := "" -}}
  {{/* Handle (list $root $network) pattern for per-network endpoints */}}
  {{- if kindIs "slice" $ctx -}}
    {{- $root = index $ctx 0 -}}
    {{- $network = index $ctx 1 -}}
  {{- else if hasKey $ctx "Original" -}}
    {{/* Handle bjw-s context with Original field */}}
    {{- $root = $ctx.Original -}}
  {{- end -}}
  {{/* Get port from uis.adapter.<protocol>.service.main.ports.http.port */}}
  {{- $port := index $root.Values.uis "adapter" $protocol "service" "main" "ports" "http" "port" | default 8080 -}}
  {{/* Include network in endpoint if provided (per-network pattern) */}}
  {{- if $network -}}
    {{/* Use truncated name to match actual K8s service name (63 char limit) */}}
    {{- $truncatedName := include "harmonize.indexers.uis.truncated-name" (list $root.Release.Name $root.Chart.Name "uis-adapter" $protocol $network) -}}
    {{- printf "%s-%s:%d" $root.Release.Name $truncatedName ($port | int) -}}
  {{- else -}}
    {{/* Legacy pattern without network */}}
    {{- printf "%s-%s-uis-adapter-%s:%d" $root.Release.Name $root.Chart.Name $protocol ($port | int) -}}
  {{- end -}}
{{- end -}}

{{/* Private helper: Configure adapter for any protocol using metadata */}}
{{/* NOTE: Adapters are Rust components for protocols that need blockchain translation */}}
{{/* Each deployment serves a SINGLE network (like charts-next) */}}
{{- define "harmonize.indexers.uis-adapter.PRIVATE.configure" -}}
{{- $protocol := index . 0 -}}
{{- $root := index . 1 -}}

{{/* Get the target network from _uisNetwork (set by uis-deployments.tpl) */}}
{{- $network := $root.Values._uisNetwork -}}

{{/* Load protocol metadata */}}
{{- $meta := include "harmonize.indexers.uis.PRIVATE.protocol-metadata" $protocol | fromJson -}}

{{/* Merge common hardcoded values */}}
{{- $_ := merge $root.Values (include "harmonize.indexers.uis-adapter.PRIVATE.hardcoded_values" $root | fromYaml) -}}

{{/* Build dynamic environment variables for this specific network */}}
{{- $env := dict -}}

{{/* Add RUST_LOG (LOG_LEVEL not used by adapter - only RUST_LOG per next chart) */}}
{{- $_ := set $env "RUST_LOG" (include "defines.logging.loglevel" $root) -}}

{{/* LISTEN_ADDR for gRPC server */}}
{{- $_ := set $env "LISTEN_ADDR" "0.0.0.0:8080" -}}

{{/* Tron-specific CUPS configuration */}}
{{/* NOTE: Protocol-specific config is already merged by uis-deployments.tpl from uis.adapter.<protocol> */}}
{{- if $meta.hasCups -}}
  {{- $cups := $root.Values.config.cups | default 400 -}}
  {{- $_ := set $env "CUPS" (toString $cups) -}}
{{- end -}}

{{/* Get network configuration for this specific network */}}
{{- $ledgers := index $root.Values.harmonize.ledgers $meta.ledgerKey | default dict -}}
{{- $networkConfig := index $ledgers $network | default dict -}}

{{/* Set NODE_ADDR - use adapterUriField from metadata if defined, otherwise fall back to uriField */}}
{{- if $networkConfig -}}
  {{- $adapterUriField := $meta.adapterUriField | default $meta.uriField -}}
  {{- $adapterUri := index $networkConfig $adapterUriField | default "" -}}
  {{- if $adapterUri -}}
    {{- $_ := set $env "NODE_ADDR" $adapterUri -}}
  {{- else -}}
    {{/* Fallback to uriField if adapterUriField value is empty */}}
    {{- $uri := index $networkConfig $meta.uriField | default "" -}}
    {{- if $uri -}}
      {{- $_ := set $env "NODE_ADDR" $uri -}}
    {{- end -}}
  {{- end -}}
{{- end -}}

{{/* Set CHAIN_ID if protocol requires it */}}
{{- if and $meta.hasChainId $networkConfig -}}
  {{- $chainIdValue := index $networkConfig "chainId" | default 0 -}}
  {{- if $chainIdValue -}}
    {{- $_ := set $env "CHAIN_ID" (printf "%.0f" (float64 $chainIdValue)) -}}
  {{- end -}}
{{- end -}}

{{/* Telemetry configuration with specific network */}}
{{- $componentName := printf "uis-adapter-%s-%s" $protocol $network -}}
{{- $_ := set $env "TelemetryServiceName" $componentName -}}
{{- $grpcEndpoint := tpl (index $root.Values.harmonize.telemetry.otel "grpcEndpoint") $root -}}
{{- $_ := set $env "TelemetryGrpcEndpoint" $grpcEndpoint -}}

{{/* TLS: Configure SSL_CERT_FILE for Rust adapter to trust rootCA */}}
{{/* Adapters are always Rust, so we use the same helper as other Rust components */}}
{{- include "harmonize.indexers.uis.configure-tls-env" (list $root $env $protocol) -}}

{{/* Merge environment variables using shared helper */}}
{{- include "harmonize.indexers.uis.merge-env" (list $root $env) -}}

{{/* Set pod annotations */}}
{{- $_ := set $root.Values.podAnnotations "checksum.secrets" (tpl ($root.Values.secrets | toYaml) $root | sha256sum) -}}

{{- end -}}

{{- define "harmonize.indexers.uis-adapter.PRIVATE.hardcoded_values" -}}
{{- include "harmonize.indexers.uis.common-hardcoded-values" . }}
{{- end -}}

