{{/*
Include components and generate Kubernetes objects
*/}}

{{/* Make sure all variables are set properly */}}
{{- include "bjw-s.common.loader.init" . -}}

{{- $original := . -}}

{{/* Create a map network -> ledger -> network instance

  mainnet:
    bitcoin:
      enabled: true
      nodeEndpoint: mainnet-ledger-accounting.com
      password: myPassword
      url: http://mainnet-ledger-accounting.com
      user: myUser
    litecoin:
      enabled: true
      nodeEndpoint: mainnet-ledger-accounting.com
      password: myPassword
      url: http://mainnet-ledger-accounting.com
      user: myUser
  testnet:
    bitcoin:
      enabled: true
      nodeEndpoint: ledger-accounting.com
      password: myPassword
      url: http://testnet-ledger-accounting.com
      user: myUser
    litecoin:
      enabled: true
      nodeEndpoint: ledger-accounting.com
      password: myPassword
      url: http://testnet-ledger-accounting.com
      user: myUser
*/}}
{{- $networks_dict := dict -}}

{{- range $ledger_name, $ledger := .Values.harmonize.ledgers -}}

  {{ $indexerName := include "harmonize.defines.indexers.name" $ledger_name }}

  {{/* nbxplorer needs special handling */}}
  {{- if ( not (eq $indexerName "nbxplorer" )) -}}
    {{- continue -}}
  {{- end -}}

  {{- range $network_name, $network := $ledger -}}
    {{/* Check if this network is enabled */}}
    {{- if not $network.enabled -}}
      {{- continue -}}
    {{- end -}}

    {{/* If this ledger is remote, skip it */}}
    {{- if $network.indexerUrl -}}
      {{- continue -}}
    {{- end -}}

    {{/* Add this ledger to this network */}}
    {{- if (not (hasKey $networks_dict $network_name)) -}}
      {{- $_ := set $networks_dict $network_name dict -}}
    {{- end -}}
    {{- $_ := set (get $networks_dict $network_name) $ledger_name $network -}}

  {{- end -}}
{{- end -}}


{{- range $network_name, $ledgers := $networks_dict -}}

  {{ $indexerName := include "harmonize.defines.indexers.name" (first (keys $ledgers)) }}

  {{/* Create environment copy */}}
  {{- $copy := mustDeepCopy $original -}}

  {{/* Add a reference to the original */}}
  {{- $_ := set $copy "Original" $ -}}

  {{/* Pass network name */}}
  {{- $_ := set $copy "Network_Name" $network_name -}}

  {{/* Pass ledgers */}}
  {{- $_ := set $copy "Ledgers" (mustDeepCopy $ledgers) -}}
  
  {{/* Set chart name to <parent chart name><indexer name> */}}
  {{- $_ := set $copy.Values "nameOverride" (printf "%s-%s-%s" $.Chart.Name $indexerName $network_name) -}}

  {{/* Copy chart settings for ledger */}}
  {{- $_ := mergeOverwrite $copy.Values (index $copy.Values.indexers $indexerName) -}}
  
  {{/* Include component rules, both common and component specific */}}
  {{- include "harmonize.indexers.all" $copy -}}
  {{- include (printf "harmonize.indexers.%s" $indexerName) $copy -}}

  {{/* With all the values set properly then render the component using the library chart */}}
  {{ include "bjw-s.common.loader.all" $copy }}

{{- end -}}