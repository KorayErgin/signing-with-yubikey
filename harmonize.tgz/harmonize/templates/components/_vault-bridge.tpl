{{- define "harmonize.components.vault-bridge" -}}
  {{- $_ := merge .Values (include "harmonize.components.vault-bridge.PRIVATE.hardcoded_values" . | fromYaml) -}}
{{- end -}}


{{/* Templates defined after this line are private and only used in this file */}}


{{- define "harmonize.components.vault-bridge.PRIVATE.hardcoded_values" -}}

{{- if .Values.harmonize.urls.tls }}
ingress:
  main:
    tls:
    - hosts:
      - {{ tpl (index .Values.harmonize.urls "vault-bridge") . }}
      {{- if (index .Values.harmonize.certificates "vault-bridge" "enabled") }}
      secretName: {{ include "harmonize.certificates.vault-bridge.secret_name" . }}
      {{- end }}
{{- end }}

{{- end -}}