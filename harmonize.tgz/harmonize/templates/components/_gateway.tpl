{{- define "harmonize.components.gateway" -}}
  {{- $_ := merge .Values (include "harmonize.components.gateway.PRIVATE.hardcoded_values" . | fromYaml) -}}
{{/*
  TBD: add checksum from AMQP_URI
*/}}
{{- end -}}


{{- define "harmonize.components.gateway.url.internal" -}}
  {{ printf "http://%s-gateway" ( include "bjw-s.common.lib.chart.names.fullname" .Original ) }}
{{- end -}}


{{- define "harmonize.components.gateway.url.healthcheck.internal" -}}
  {{ printf "%s-healthcheck%s" ( include "harmonize.components.gateway.url.internal" .) (.Values.probes.readiness.path)}}
{{- end -}}


{{/* Templates defined after this line are private and only used in this file */}}


{{- define "harmonize.components.gateway.PRIVATE.hardcoded_values" -}}

{{- end -}}