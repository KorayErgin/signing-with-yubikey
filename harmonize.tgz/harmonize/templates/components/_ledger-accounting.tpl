{{- define "harmonize.components.ledger-accounting" -}}
  {{- $_ := merge .Values (include "harmonize.components.ledger-accounting.PRIVATE.hardcoded_values" . | fromYaml) -}}
{{- end -}}

{{/* TBD: add checksum from AMQP_URI */}}

{{- define "harmonize.components.ledger-accounting.url.internal" -}}
{{ printf "%s-ledger-accounting" ( include "bjw-s.common.lib.chart.names.fullname" .Original ) }}
{{- end -}}

{{/* Templates defined after this line are private and only used in this file */}}

{{- define "harmonize.components.ledger-accounting.PRIVATE.hardcoded_values" -}}

{{- end -}}


{{/*
EVM Network to Reference.conf Ledger ID Mapping
Maps EVM network names (as used in values.yaml) to the ledger IDs expected by reference.conf.
This is necessary because reference.conf uses specific ledger IDs like "bsc-testnet" while
the Helm chart uses "evm" as the ledger family with network names like "bsc-testnet".

The mapping also includes the tracker name (ethindexer-{ledger-id}) for HOCON configuration.
*/}}
{{- define "harmonize.components.ledger-accounting.PRIVATE.evm-ledger-mapping" -}}
{{- $mapping := dict -}}
{{/* BSC Networks */}}
{{- $mapping = set $mapping "bsc-mainnet" (dict "ledgerId" "bsc-mainnet" "trackerId" "ethindexer-bsc-mainnet") -}}
{{- $mapping = set $mapping "bsc-testnet" (dict "ledgerId" "bsc-testnet" "trackerId" "ethindexer-bsc-testnet") -}}
{{/* Arbitrum Networks */}}
{{- $mapping = set $mapping "arbitrum-mainnet" (dict "ledgerId" "arbitrum-mainnet" "trackerId" "ethindexer-arbitrum-mainnet") -}}
{{- $mapping = set $mapping "arbitrum-sepolia" (dict "ledgerId" "arbitrum-testnet-sepolia" "trackerId" "ethindexer-arbitrum-testnet-sepolia") -}}
{{- $mapping = set $mapping "arbitrum-testnet-sepolia" (dict "ledgerId" "arbitrum-testnet-sepolia" "trackerId" "ethindexer-arbitrum-testnet-sepolia") -}}
{{/* Optimism Networks */}}
{{- $mapping = set $mapping "optimism-mainnet" (dict "ledgerId" "optimism-mainnet" "trackerId" "ethindexer-optimism-mainnet") -}}
{{- $mapping = set $mapping "optimism-sepolia" (dict "ledgerId" "optimism-testnet-sepolia" "trackerId" "ethindexer-optimism-testnet-sepolia") -}}
{{- $mapping = set $mapping "optimism-testnet-sepolia" (dict "ledgerId" "optimism-testnet-sepolia" "trackerId" "ethindexer-optimism-testnet-sepolia") -}}
{{/* Base Networks */}}
{{- $mapping = set $mapping "base-mainnet" (dict "ledgerId" "base-mainnet" "trackerId" "ethindexer-base-mainnet") -}}
{{- $mapping = set $mapping "base-sepolia" (dict "ledgerId" "base-testnet-sepolia" "trackerId" "ethindexer-base-testnet-sepolia") -}}
{{- $mapping = set $mapping "base-testnet-sepolia" (dict "ledgerId" "base-testnet-sepolia" "trackerId" "ethindexer-base-testnet-sepolia") -}}
{{/* Polygon Networks */}}
{{- $mapping = set $mapping "polygon-mainnet" (dict "ledgerId" "polygon" "trackerId" "ethindexer-polygon-mainnet") -}}
{{- $mapping = set $mapping "polygon-testnet-amoy" (dict "ledgerId" "polygon-testnet-amoy" "trackerId" "ethindexer-polygon-testnet-amoy") -}}
{{- $mapping = set $mapping "polygon-testnet-mumbai" (dict "ledgerId" "polygon-testnet-mumbai" "trackerId" "ethindexer-polygon-testnet-mumbai") -}}
{{/* Avalanche Networks */}}
{{- $mapping = set $mapping "avalanche-mainnet" (dict "ledgerId" "avalanche-c-chain" "trackerId" "ethindexer-avalanche-c-chain-mainnet") -}}
{{- $mapping = set $mapping "avalanche-c-chain-mainnet" (dict "ledgerId" "avalanche-c-chain" "trackerId" "ethindexer-avalanche-c-chain-mainnet") -}}
{{- $mapping = set $mapping "avalanche-testnet-fuji" (dict "ledgerId" "avalanche-c-chain-testnet-fuji" "trackerId" "ethindexer-avalanche-c-chain-testnet-fuji") -}}
{{- $mapping = set $mapping "avalanche-c-chain-testnet-fuji" (dict "ledgerId" "avalanche-c-chain-testnet-fuji" "trackerId" "ethindexer-avalanche-c-chain-testnet-fuji") -}}
{{/* Ethereum Networks (for completeness) */}}
{{- $mapping = set $mapping "ethereum-mainnet" (dict "ledgerId" "ethereum" "trackerId" "ethindexer-mainnet") -}}
{{- $mapping = set $mapping "ethereum-testnet-sepolia" (dict "ledgerId" "ethereum-testnet-sepolia" "trackerId" "ethindexer-testnet-sepolia") -}}
{{- $mapping | toYaml -}}
{{- end -}}

{{- define "harmonize.components.ledger-accounting.ledgers.config" -}}
  {{- $count := 0 -}}

  {{- if eq (index .Values.components "coinbase-adapter" "enabled") true -}}
  {{- $count = add1 $count -}}
  {{ printf "ledgers += ${silo.ledger-accounting.ledger.coinbase-prime}" }}

  {{ printf "tracker.coinbase-adapter.base-url = \"http://%s-coinbase-adapter\"" ( include "bjw-s.common.lib.chart.names.fullname" $.Original ) }}

  {{ printf "tracker.coinbase-adapter.provider-id = \"%s\"" (get $.Values.harmonize "coinbase-adapter").provider_uuid }}
  {{- end -}}

  {{/* Load EVM ledger mapping for reference.conf compatibility */}}
  {{- $evmMapping := include "harmonize.components.ledger-accounting.PRIVATE.evm-ledger-mapping" . | fromYaml -}}

  {{- range $ledger_name, $ledger := .Values.harmonize.ledgers -}}

    {{- $indexer_name := include "harmonize.defines.indexers.name" $ledger_name }}

    {{- range $network_name, $network := $ledger -}}

      {{/* If network is disabled, skip */}}
      {{- if not $network.enabled -}}
        {{- continue -}}
      {{- end -}}

      {{- $count = add1 $count -}}

      {{/* If raw_config is provided, use it directly instead of auto-generating */}}
      {{/* This allows custom HOCON configuration for ledgers that need it */}}
      {{- if $network.raw_config }}
{{ $network.raw_config }}
      {{- else -}}

      {{/* Determine the reference.conf ledger ID and tracker ID */}}
      {{/* For EVM ledgers, use the mapping; for others, use the standard format */}}
      {{- $refLedgerId := printf "%s-%s" $ledger_name $network_name -}}
      {{- $refTrackerId := printf "%s-%s" $indexer_name $network_name -}}

      {{/* Check if this is an EVM ledger with a mapping */}}
      {{- if eq $ledger_name "evm" -}}
        {{- $evmConfig := get $evmMapping $network_name -}}
        {{- if $evmConfig -}}
          {{- $refLedgerId = $evmConfig.ledgerId -}}
          {{- $refTrackerId = $evmConfig.trackerId -}}
        {{- end -}}
      {{- end -}}

      {{- $url := printf "http://%s-%s-%s" ( include "bjw-s.common.lib.chart.names.fullname" $.Original ) $ledger_name $network_name -}}
      {{/* nbxplorer needs special handling */}}
      {{- if (eq $indexer_name "nbxplorer" ) }}
      {{- $url = printf "http://%s-%s-%s" ( include "bjw-s.common.lib.chart.names.fullname" $.Original ) $indexer_name $network_name -}}
      {{- end }}
      {{/* UIS-enabled ledgers connect to api-management-uis which routes to appropriate backend:
           - Requests with ledger prefix -> UIS API (balance, transaction, etc.)
           - Requests without prefix -> Events API (/track, /events)
           The URL includes ledger prefix so requests like /track become /{ledger}/track */}}
      {{- if $network.enableUIS -}}
      {{- $ledgerId := $ledger_name -}}
      {{- if ne $network_name "mainnet" -}}
        {{- $ledgerId = printf "%s-%s" $ledger_name $network_name -}}
      {{- end -}}
      {{- $url = printf "http://%s-harmonize-api-management-uis:8080/%s" $.Release.Name $ledgerId -}}
      {{- end }}
      {{- $url = $network.indexerUrl | default $url | quote }}
      {{/* For UIS ledgers, use default instance token if not explicitly set */}}
      {{- $defaultToken := include "harmonize.indexers.uis.default-instance-token" $ -}}
      {{- $isUIS := $network.enableUIS | default false -}}
      {{- $instanceToken := $network.instanceToken | default (ternary $defaultToken "" $isUIS) | quote }}

      {{ printf "ledgers += ${silo.ledger-accounting.ledger.%s}" $refLedgerId }}

      {{ printf "tracker.%s.base-url = %s" $refTrackerId $url }}

      {{- if not (eq $instanceToken "")}}

      {{ printf "tracker.%s.instance-token = %s" $refTrackerId $instanceToken }}
      {{- end -}}

      {{- if and (eq $ledger_name "ethereum") $network.sequencer }}
        {{ printf "silo.ledger-accounting.ledger.ethereum-%s.sequencer.processor.confirmations = %d" $network_name $network_name.sequencer.processor.confirmations }}
      {{- end }}
      {{- end -}}

    {{- end -}}
  {{- end -}}

  {{- if eq $count 0 -}}
    {{ printf "ledgers = []" }}
  {{- end -}}
{{- end }}
