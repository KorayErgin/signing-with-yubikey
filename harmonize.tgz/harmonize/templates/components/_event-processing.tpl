{{- define "harmonize.components.event-processing" -}}
  {{- $_ := merge .Values (include "harmonize.components.event-processing.PRIVATE.hardcoded_values" . | fromYaml) -}}
{{- end -}}

{{- define "harmonize.components.event-processing.external-amqp-config.configmap_name" -}}
{{ printf "%s-event-processing-external-amqp-config" ( include "bjw-s.common.lib.chart.names.fullname" . ) }}
{{- end -}}

{{/* Templates defined after this line are private and only used in this file */}}

{{- define "harmonize.components.event-processing.PRIVATE.hardcoded_values" -}}
{{- $edsEnabled := index .Values.components "event-distribution-service" "enabled" | default false -}}
{{- $amqpConfig := ternary .Values.harmonize.internalAmqp .Values.harmonize.externalAmqp $edsEnabled -}}
{{- $isV1 := eq ($amqpConfig.amqpProtocolVersion | default "v09") "v1" -}}

controller:
  replicas: {{ empty .Values.harmonize.externalAmqp.host | ternary 0 1 }}

env:
{{- if $edsEnabled }}
  # Internal AMQP
  {{- if $isV1 }}
  # v1: Individual variables
  AMQP_HOST: "{{ $amqpConfig.host }}"
  AMQP_PORT: "{{ $amqpConfig.port }}"
  AMQP_AUTH_TYPE: "plain-authentication"
  AMQP_USERNAME: "{{ $amqpConfig.username }}"
  AMQP_PASSWORD:
    valueFrom:
      secretKeyRef:
        name: '{{ include "harmonize.components.amqp.secret_name" . }}'
        key: rabbitmq-password
  AMQP_SSL_ENABLED: "{{ $amqpConfig.sslEnabled }}"
  {{- else }}
  # v09: URI-based
  AMQP_URI:
    valueFrom:
      secretKeyRef:
        name: '{{ include "harmonize.components.amqp.secret_name" . }}'
        key: AMQP_URI
  {{- end }}

{{- else }}
  # External AMQP (always v1 in defaults)
  AMQP_HOST: "{{ .Values.harmonize.externalAmqp.host }}"
  AMQP_PORT: "{{ .Values.harmonize.externalAmqp.port }}"
  AMQP_AUTH_TYPE: "{{ .Values.harmonize.externalAmqp.authType }}"
  AMQP_USERNAME: "{{ .Values.harmonize.externalAmqp.username }}"
  AMQP_PASSWORD:
    valueFrom:
      secretKeyRef: 
        name: '{{ .Values.harmonize.externalAmqp.existingSecret | default (printf "%s-external-amqp" ( include "bjw-s.common.lib.chart.names.fullname" . ) ) }}'
        key: amqp-password
  AMQP_SSL_ENABLED: "{{ .Values.harmonize.externalAmqp.sslEnabled }}"
{{- end }}
  # Common vars (set once)
  AMQP_PROTOCOL_VERSION: '{{ $isV1 | ternary "v1" "v09" }}'
  EVENT_PROCESSING_PUBLISHER_TOPIC_NAME: "{{ $amqpConfig.topicName | default "eventsTopic" }}"

envFrom:
  - secretRef:
      name: '{{ include "harmonize.components.amqp.secret_name" . }}'
      optional: true

{{- end -}}