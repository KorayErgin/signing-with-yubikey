{{- define "harmonize.components.graph-api" -}}
  {{- $_ := merge .Values (include "harmonize.components.graph-api.PRIVATE.hardcoded_values" . | fromYaml) -}}
{{- end -}}


{{- define "harmonize.components.graph-api.url.public" -}}
  {{ printf "%s%s" (include "harmonize.defines.ingress.scheme" .) (tpl .Values.harmonize.urls.graphapi .) }}
{{- end -}}


{{- define "harmonize.components.graph-api.url.internal" -}}
  {{ printf "http://%s-graph-api" ( include "bjw-s.common.lib.chart.names.fullname" .Original ) }}
{{- end -}}


{{- define "harmonize.components.graph-api.host.internal" -}}
  {{ printf "%s-graph-api" ( include "bjw-s.common.lib.chart.names.fullname" .Original ) }}
{{- end -}}


{{/* Templates defined after this line are private and only used in this file */}}


{{- define "harmonize.components.graph-api.PRIVATE.hardcoded_values" -}}

{{- if .Values.harmonize.urls.tls }}
ingress:
  main:
    tls:
    - hosts:
      - {{ tpl .Values.harmonize.urls.graphapi . }}
      {{- if (index .Values.harmonize.certificates "graph-api" "enabled") }}
      secretName: {{ include "harmonize.certificates.graph-api.secret_name" . }}
      {{- end }}
{{- end }}

{{- end -}}