{{- define "harmonize.components.coinbase-adapter" -}}
  {{- $_ := merge .Values (include "harmonize.components.coinbase-adapter.PRIVATE.hardcoded_values" . | fromYaml) -}}
{{- end -}}

{{- define "harmonize.components.cb.url.public" -}}
  {{ printf "%s%s" (include "harmonize.defines.ingress.scheme" .) (tpl .Values.harmonize.urls.cb .) }}
{{- end -}}

{{/* Templates defined after this line are private and only used in this file */}}

{{- define "harmonize.components.coinbase-adapter.PRIVATE.hardcoded_values" -}}

{{- $_ := mergeOverwrite .Values (get .Values.harmonize "coinbase-adapter") }}

{{- if .Values.harmonize.urls.tls }}
ingress:
  main:
    tls:
    - hosts:
      - {{ tpl .Values.harmonize.urls.cb . }}
      {{- if (index .Values.harmonize.certificates "cb" "enabled") }}
      secretName: {{ include "harmonize.certificates.cb.secret_name" . }}
      {{- end }}
{{- end }}

persistence:
{{- if contains "kms_" .Values.platform  }}
  {{- include "harmonize.defines.kms.volumes" . | nindent 2 }}
{{- end }}
{{- if .Values.self_signed_ca_cert }}
  ca-crt:
    enabled: true
    name: '{{ printf "%s-ca-crt" ( include "bjw-s.common.lib.chart.names.fullname" . ) }}'
    type: secret
    mountPath: '{{ .Values.env.SELF_SIGNED_CA_CERT_PATH | default "/certs/ca.crt" }}'
    subPath: ca.crt
{{- end }}
{{ if contains "kms_" .Values.platform  }}
  kmsconnect:
    enabled: true
    name: '{{ printf "%s-kmsconnect" ( include "bjw-s.common.lib.chart.names.fullname" . ) }}'
    type: secret
    mountPath: /opt/kms/cfg
{{ end }}
secrets:
{{- if contains "kms_" .Values.platform  }}
  {{- include "harmonize.defines.kms.secrets" . | nindent 2 }}
{{- end }}
{{- if .Values.self_signed_ca_cert }}
  ca-crt:
    # -- Existing secret reference
    secretRef:
    # -- Enables or disables the Secret
    enabled: true
    stringData:
      ca.crt: |- {{ .Values.self_signed_ca_cert | nindent 8}}
{{- end }}
{{- if contains "kms_" .Values.platform  }}
sidecars:
  {{- include "harmonize.defines.kms.sidecars" . | nindent 2 }}
{{- end }}
env:
  CB_ACCESS_KEY:
    valueFrom:
      secretKeyRef:
        name: '{{ printf "%s-access-secrets" ( include "bjw-s.common.lib.chart.names.fullname" . ) }}'
        key: key
  CB_ACCESS_PASSPHRASE:
    valueFrom:
      secretKeyRef:
        name: '{{ printf "%s-access-secrets" ( include "bjw-s.common.lib.chart.names.fullname" . ) }}'
        key: passphrase
  CB_ACCESS_SIGNING_KEY:
    valueFrom:
      secretKeyRef:
        name: '{{ printf "%s-access-secrets" ( include "bjw-s.common.lib.chart.names.fullname" . ) }}'
        key: signingKey
{{- if (and .Values.self_signed_ca_cert (not .Values.env.SELF_SIGNED_CA_CERT_PATH )) }}
  SELF_SIGNED_CA_CERT_PATH: /certs/ca.crt
{{- end }}
{{- end }}
