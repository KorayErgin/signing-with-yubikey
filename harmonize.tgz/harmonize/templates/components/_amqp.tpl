{{- define "harmonize.components.amqp" -}}
  {{- $_ := merge .Values (include "harmonize.components.amqp.PRIVATE.hardcoded_values" . | fromYaml) -}}
{{- end -}}

{{- define "harmonize.components.amqp.secret_name" -}}
  {{- $amqp := .Values.harmonize.internalAmqp.enabledForCoreComponents | ternary .Values.harmonize.internalAmqp .Values.harmonize.externalAmqp -}}
  {{- if and $amqp.enabledForCoreComponents $amqp.existingSecret -}}
    {{- printf "%s" $amqp.existingSecret -}}
  {{- else -}}
    {{- printf "%s-amqp-secret" ( include "bjw-s.common.lib.chart.names.fullname" .Original ) -}}
  {{- end -}}
{{- end -}}


{{/* Templates defined after this line are private and only used in this file */}}


{{- define "harmonize.components.amqp.PRIVATE.hardcoded_values" -}}
  {{- $internal := .Values.harmonize.internalAmqp.enabledForCoreComponents -}}
  {{- $amqp := $internal | ternary .Values.harmonize.internalAmqp .Values.harmonize.externalAmqp -}}
  
  {{- $username := required "username is needed for amqp" $amqp.username -}}
  {{- $host := default ( include "bjw-s.common.lib.chart.names.fullname" . ) $amqp.host -}}
  {{- $port := toString (required "port is needed for amqp" $amqp.port) -}}
  {{- $vhost := required "vhost is needed for amqp" $amqp.vhost -}}
  {{- $erlang_cookie := "" -}}
  {{- $rabbitmq_password := "" -}}
  {{- $v1 := eq $amqp.amqpProtocolVersion "v1" -}}
  {{- $secret_name := include "harmonize.components.amqp.secret_name" . -}}
  {{- $secret_value := lookup "v1" "Secret" .Release.Namespace $secret_name -}}
  {{- $sslEnabled := $amqp.sslEnabled -}}

  {{- if $secret_value -}}
    {{- if $v1 -}}
      {{ $host                = (required (printf "key AMQP_HOST must exist in secret %s" $secret_name) (index $secret_value.data "AMQP_HOST")) | b64dec -}}
      {{ $port                = (required (printf "key AMQP_PORT must exist in secret %s" $secret_name) (index $secret_value.data "AMQP_PORT")) | b64dec -}}
      {{ $username            = (required (printf "key AMQP_USERNAME must exist in secret %s" $secret_name) (index $secret_value.data "AMQP_USERNAME")) | b64dec -}}
      {{ $rabbitmq_password   = (required (printf "key AMQP_PASSWORD must exist in secret %s" $secret_name) (index $secret_value.data "AMQP_PASSWORD")) | b64dec -}}
      {{ $sslEnabled          = (required (printf "key AMQP_SSL_ENABLED must exist in secret %s" $secret_name) (index $secret_value.data "AMQP_SSL_ENABLED")) | b64dec -}}
    {{- else -}}
      {{- $erlang_cookie      = (required (printf "key rabbitmq-erlang-cookie must exist in secret %s" $secret_name) (index $secret_value.data "rabbitmq-erlang-cookie")) | b64dec -}}
      {{- $rabbitmq_password  = (required (printf "key rabbitmq-password must exist in secret %s" $secret_name) (index $secret_value.data "rabbitmq-password")) | b64dec -}}
    {{- end -}}
  {{- else -}}
    {{- $erlang_cookie      = default (randAlpha 16) $amqp.erlang_cookie -}}
    {{- $rabbitmq_password  = default (randAlpha 16) $amqp.password  -}}
  {{- end -}}

  {{/* Disable internal amqp if external is required for core-components */}}
  {{- $_ := set .Values.controller "replicas" ($internal | ternary 1 0) -}}

  {{- if $v1 -}}
podAnnotations: {}
secrets:
  secret:
    stringData:
      AMQP_HOST: {{ $host | quote }}
      AMQP_PORT: {{ $port | quote }}
      AMQP_PROTOCOL_VERSION: {{ (required "amqpProtocolVersion must be set" $amqp.amqpProtocolVersion) | quote }}
      AMQP_USERNAME: {{ $username | quote }}
      AMQP_PASSWORD: {{ $rabbitmq_password | quote }}
      AMQP_SSL_ENABLED: {{ required "ssl toggle must be set" $sslEnabled | quote }}
env: {}
  {{- else -}}
podAnnotations: {}
secrets:
  secret:
    stringData:
      rabbitmq-erlang-cookie: {{ $erlang_cookie | quote }}
      rabbitmq-password: {{ $rabbitmq_password | quote }}
      AMQP_URI: {{ printf "amqp://%s:%s@%s:%s/%s" $username $rabbitmq_password $host $port $vhost | quote }}
env:
  RABBITMQ_DEFAULT_VHOST: {{ $vhost | quote }}
  RABBITMQ_DEFAULT_USER:  {{ $username | quote }}
  RABBITMQ_DEFAULT_PASS:
    valueFrom:
      secretKeyRef:
        key: 'rabbitmq-password'
        name: {{ $secret_name | quote }}
  {{- end -}}
{{- end -}}
