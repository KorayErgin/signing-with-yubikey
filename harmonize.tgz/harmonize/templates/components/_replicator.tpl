{{- define "harmonize.components.replicator" -}}
  {{- $_ := merge .Values (include "harmonize.components.replicator.PRIVATE.hardcoded_values" . | fromYaml) -}}
{{- end -}}


{{- define "harmonize.components.replicator.url.internal" -}}
  {{ printf "http://%s-replicator" ( include "bjw-s.common.lib.chart.names.fullname" .Original ) }}
{{- end -}}


{{- define "harmonize.components.replicator.host.internal" -}}
  {{ printf "%s-replicator" ( include "bjw-s.common.lib.chart.names.fullname" .Original ) }}
{{- end -}}


{{/* Templates defined after this line are private and only used in this file */}}


{{- define "harmonize.components.replicator.PRIVATE.hardcoded_values" -}}

{{/* Replicator is an internal service - no ingress configuration needed */}}

{{- end -}}