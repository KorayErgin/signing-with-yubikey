{{- define "harmonize.components.notary-bridge" -}}
  {{- $_ := merge .Values (include "harmonize.components.notary-bridge.PRIVATE.hardcoded_values" . | fromYaml) -}}
{{- end -}}

{{/* TBD: add checksum from AMQP_URI */}}

{{- define "harmonize.components.notary-bridge.host.internal" -}}
  {{ printf "%s-notary-bridge" ( include "bjw-s.common.lib.chart.names.fullname" .Original ) }}
{{- end -}}

{{/* Templates defined after this line are private and only used in this file */}}

{{- define "harmonize.components.notary-bridge.PRIVATE.hardcoded_values" -}}

{{- if .Values.harmonize.urls.tls }}
ingress:
  main:
    tls:
    - hosts:
      - {{ tpl (index .Values.harmonize.urls "notary-bridge") . }}
      {{- if (index .Values.harmonize.certificates "notary-bridge" "enabled") }}
      secretName: {{ include "harmonize.certificates.notary-bridge.secret_name" . }}
      {{- end }}
{{- end }}

{{- end -}}