{{- define "harmonize.components.event-distribution-service" -}}
  {{- $_ := merge .Values (include "harmonize.components.event-distribution-service.PRIVATE.hardcoded_values" . | fromYaml) -}}
{{- end -}}

{{- define "harmonize.components.event-distribution-service.url.internal" -}}
  {{ printf "http://%s-event-distribution-service-api" ( include "bjw-s.common.lib.chart.names.fullname" .Original ) }}
{{- end -}}

{{- define "harmonize.components.event-distribution-service.url.external" -}}
  {{ include "harmonize.defines.uris.external" (list . "event-distribution-service-api") }}
{{- end -}}

{{/* Templates defined after this line are private and only used in this file */}}

{{- define "harmonize.components.event-distribution-service.PRIVATE.hardcoded_values" -}}

# Parent EDS component - this template enables both child components
# The actual deployments are handled by the child component templates

{{- end -}}