
{{- define "harmonize.components.keycloak-config-cli.creds.secret_name" -}}
    {{- printf "%s-keycloak-kc" (include "bjw-s.common.lib.chart.names.fullname" . ) -}}
{{- end -}}

{{- define "harmonize.components.keycloak-config-cli.clients.secret_name" -}}
{{ if .Values.components.keycloak.secrets.clients.secretRef -}}
    {{- .Values.components.keycloak.secrets.clients.secretRef -}}
{{- else -}}
    {{- printf "%s-keycloak-clients" (include "bjw-s.common.lib.chart.names.fullname" . ) -}}
{{- end -}}
{{- end -}}

{{- define "harmonize.components.keycloak-config-cli.realm-config-export.configmap_name" -}}
    {{- printf "%s-keycloak-realm-config-export" (include "bjw-s.common.lib.chart.names.fullname" . ) -}}
{{- end -}}

{{/* Redefining the urls due to issue with .Original  */}}
{{- define "harmonize.components.keycloak-config-cli.gateway.url.internal" -}}
  {{ printf "http://%s-gateway" ( include "bjw-s.common.lib.chart.names.fullname" . ) }}
{{- end -}}

{{- define "harmonize.components.keycloak-config-cli.url.internal" -}}
  {{ printf "http://%s-keycloak" ( include "bjw-s.common.lib.chart.names.fullname" . ) }}
{{- end -}}
