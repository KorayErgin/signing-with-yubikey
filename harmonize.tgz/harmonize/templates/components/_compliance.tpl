{{- define "harmonize.components.compliance" -}}
{{- $_ := merge .Values (include "harmonize.components.compliance.PRIVATE.hardcoded_values" . | fromYaml) -}}
{{- end -}}


{{- define "harmonize.components.compliance.url.internal" -}}
  {{ printf "http://%s-compliance" ( include "bjw-s.common.lib.chart.names.fullname" .Original ) }}
{{- end -}}


{{/* Templates defined after this line are private and only used in this file */}}


{{- define "harmonize.components.compliance.PRIVATE.hardcoded_values" -}}

env:
  SPRING_DATASOURCE_URL:
    valueFrom:
      secretKeyRef:
        name: '{{ .Values.components.compliance.secrets.psql.secretRef | default (printf "%s-psql" ( include "bjw-s.common.lib.chart.names.fullname" . ) ) }}'

{{- end -}}
