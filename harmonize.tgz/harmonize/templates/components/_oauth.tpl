{{- define "harmonize.components.oauth" -}}
  {{- $_ := merge .Values (include "harmonize.components.oauth.PRIVATE.hardcoded_values" . | fromYaml) -}}
{{- end -}}


{{- define "harmonize.components.oauth.url.public" -}}
  {{ printf "%s%s" (include "harmonize.defines.ingress.scheme" .) (tpl .Values.harmonize.urls.auth .) }}
{{- end -}}


{{- define "harmonize.components.oauth.url.internal" -}}
  {{ printf "http://%s-oauth" ( include "bjw-s.common.lib.chart.names.fullname" .Original ) }}
{{- end -}}


{{- define "harmonize.components.oauth.client_secret" -}}

  {{- $env := index . 0 -}}
  {{- $client := index . 1 -}}

  {{/* Check if secret cache has been initialized. If not init from k8s Secret */}}
  {{- if empty $env.Original.oauth_clients_secrets -}}
    {{- include "harmonize.components.oauth.PRIVATE.init_client_secrets" $env -}}
  {{- end -}}

  {{/* Retrieve secret from cache. Random if not set before */}}
  {{- $secret := index $env.Original.oauth_clients_secrets $client | default (randAlpha 16) -}}
  {{- $_ := set $env.Original.oauth_clients_secrets $client $secret -}}
  {{- print $secret -}}

{{- end -}}


{{/* Templates defined after this line are private and only used in this file */}}


{{- define "harmonize.components.oauth.PRIVATE.hardcoded_values" -}}

{{- $server_secret_name := printf "%s-server"  ( include "bjw-s.common.lib.chart.names.fullname" . ) -}}
{{- $server_secret_value := lookup "v1" "Secret" .Release.Namespace $server_secret_name -}}

{{- $oauth_server_key := "" -}}
{{- if $server_secret_value -}}
  {{- $oauth_server_key = index $server_secret_value.data "OAUTH_SERVER_KEY" | b64dec -}}
{{- else -}}
  {{- $oauth_server_key = genPrivateKey "rsa" -}}
{{- end -}}

persistence:
  rootca:
    enabled: {{ tpl (.Values.harmonize.certificates.rootCA.enabled | toString) . }}

secrets:
  server:
    enabled: true
    stringData:
      OAUTH_SERVER_KEY: {{ $oauth_server_key | quote }}

{{- if .Values.harmonize.urls.tls }}
ingress:
  main:
    tls:
    - hosts:
      - {{ tpl .Values.harmonize.urls.auth . }}
      {{- if .Values.harmonize.certificates.oauth.enabled }}
      secretName: {{ include "harmonize.certificates.oauth.secret_name" . }}
      {{- end }}

  token:
    enabled: true
    annotations:
      nginx.ingress.kubernetes.io/rewrite-target: /realms/Metaco/protocol/openid-connect/token
    hosts:
      - host: {{tpl .Values.harmonize.urls.token .}}
        paths:
          - path: /token
            pathType: Prefix
            service:
              name: {{include "harmonize.components.keycloak.service" .}}
              port: {{ .Values.components.keycloak.service.main.ports.http.port }}
    tls:
    - hosts:
      - {{ tpl .Values.harmonize.urls.token . }}
      {{- if (index .Values.harmonize.certificates "oauth-token" "enabled") }}
      secretName: {{ include "harmonize.certificates.oauth-token.secret_name" . }}
      {{- end }}
{{- end }}

{{- end -}}


{{- define "harmonize.components.oauth.PRIVATE.init_client_secrets" -}}
  {{/* Retrieve k8s secret with all existing OIDC secrets */}}
  {{- $_ := set .Original "oauth_clients_secrets" dict -}}
  {{- $server_secret_name := printf "%s-oauth-clients"  ( include "bjw-s.common.lib.chart.names.fullname" .Original ) -}}
  {{- $server_secret_value := lookup "v1" "Secret" .Release.Namespace $server_secret_name -}}

  {{- if $server_secret_value -}}
    {{- $oauth_clients := index $server_secret_value.data "OAUTH_CLIENTS" | b64dec -}}
    {{- $oauth_clients_list := ((printf "{ clients: %s }" $oauth_clients) | fromYaml).clients -}}
    {{- range $client := $oauth_clients_list -}}
      {{- $_ := set $.Original.oauth_clients_secrets $client.client_id $client.client_secret -}}
    {{- end -}}
  {{- else -}}
   
  {{- end -}}
{{- end -}}
