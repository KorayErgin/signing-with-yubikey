{{- define "harmonize.components.event-distribution-service-api" -}}
  {{- $_ := merge .Values (include "harmonize.components.event-distribution-service-api.PRIVATE.hardcoded_values" . | fromYaml) -}}
{{- end -}}

{{- define "harmonize.components.event-distribution-service-api.url.internal" -}}
  {{ printf "http://%s-event-distribution-service-api" ( include "bjw-s.common.lib.chart.names.fullname" .Original ) }}
{{- end -}}

{{- define "harmonize.components.event-distribution-service-api.url.external" -}}
  {{ include "harmonize.defines.uris.external" (list . "event-distribution-service-api") }}
{{- end -}}

{{/* Templates defined after this line are private and only used in this file && test to force pipeline run again */}}

{{- define "harmonize.components.event-distribution-service-api.PRIVATE.hardcoded_values" -}}

env:
  POSTGRES_URL:
    valueFrom:
      secretKeyRef:
        name: '{{ (index .Values.components "event-distribution-service-api").secrets.psql.secretRef | default (printf "%s-psql" ( include "bjw-s.common.lib.chart.names.fullname" . ) ) }}'
        key: hmz-psql-uri-jbdc

{{- end -}}