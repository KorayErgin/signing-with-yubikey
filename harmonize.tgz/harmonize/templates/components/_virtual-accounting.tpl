{{- define "harmonize.components.virtual-accounting" -}}
  {{- $_ := merge .Values (include "harmonize.components.virtual-accounting.PRIVATE.hardcoded_values" . | fromYaml) -}}
{{- end -}}


{{- define "harmonize.components.virtual-accounting.url.internal" -}}
  {{ printf "http://%s-virtual-accounting" ( include "bjw-s.common.lib.chart.names.fullname" .Original ) }}
{{- end -}}


{{/* Templates defined after this line are private and only used in this file */}}


{{- define "harmonize.components.virtual-accounting.PRIVATE.hardcoded_values" -}}

{{- end -}}