{{- define "harmonize.components.frontend" -}}
  {{- $_ := merge .Values (include "harmonize.components.frontend.PRIVATE.hardcoded_values" . | fromYaml) -}}
{{- end -}}


{{- define "harmonize.components.frontend.url.public" -}}
  {{ printf "%s%s" (include "harmonize.defines.ingress.scheme" .) (tpl .Values.harmonize.urls.frontend .) }}
{{- end -}}


{{/* Templates defined after this line are private and only used in this file */}}


{{- define "harmonize.components.frontend.PRIVATE.hardcoded_values" -}}

persistence:
  rootca:
    enabled: {{ tpl (.Values.harmonize.certificates.rootCA.enabled | toString) . }}

{{- if .Values.harmonize.urls.tls }}
ingress:
  main:
    tls:
    - hosts:
      - {{ tpl .Values.harmonize.urls.frontend . }}
      {{- if .Values.harmonize.certificates.frontend.enabled }}
      secretName: {{ include "harmonize.certificates.frontend.secret_name" . }}
      {{- end }}
{{- end }}

{{- end -}}