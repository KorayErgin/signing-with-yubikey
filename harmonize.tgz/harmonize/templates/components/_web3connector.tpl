{{- define "harmonize.components.web3connector" -}}
{{- $_ := merge .Values (include "harmonize.components.web3connector.PRIVATE.hardcoded_values" . | fromYaml) -}}
{{- end -}}


{{- define "harmonize.components.web3connector.url.internal" -}}
  {{ printf "http://%s-web3connector" ( include "bjw-s.common.lib.chart.names.fullname" .Original ) }}
{{- end -}}


{{/* Templates defined after this line are private and only used in this file */}}


{{- define "harmonize.components.web3connector.PRIVATE.hardcoded_values" -}}

{{- end -}}