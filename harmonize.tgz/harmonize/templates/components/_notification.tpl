{{- define "harmonize.components.notification" -}}
  {{- $_ := merge .Values (include "harmonize.components.notification.PRIVATE.hardcoded_values" . | fromYaml) -}}
{{- end -}}


{{- define "harmonize.components.notification.url.internal" -}}
  {{ printf "http://%s-notification" ( include "bjw-s.common.lib.chart.names.fullname" .Original ) }}
{{- end -}}


{{/* Templates defined after this line are private and only used in this file */}}


{{- define "harmonize.components.notification.PRIVATE.hardcoded_values" -}}

persistence:
  rootca:
    enabled: {{ tpl (.Values.harmonize.certificates.rootCA.enabled | toString) . }}

{{- end -}}