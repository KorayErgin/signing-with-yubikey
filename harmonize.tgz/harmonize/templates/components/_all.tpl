{{/*
These changes are applied to all harmonize components
*/}}
{{- define "harmonize.components.all" -}}

  {{/*
  Expand the repository
  */}}
  {{- $_ := set .Values.image "repository" (tpl .Values.image.repository .) -}}

  {{/* Add image pull secrets */}}
  {{- $_ := set .Values "imagePullSecrets" (concat .Values.imagePullSecrets ((include "harmonize.imagePullSecret.nameList" .) | fromJson ).values) -}}
  
  {{/* Expand the imagePullSecrets */}}
  {{- $imagePullSecrets := list -}}
  {{- range .Values.imagePullSecrets -}}
    {{- $imagePullSecrets = append $imagePullSecrets ((tpl (.|toYaml) $)|fromYaml) -}}
  {{- end -}}
  {{- $_ := set .Values "imagePullSecrets" $imagePullSecrets -}}

  {{/* Expand the resources */}}
  {{- $_ := set .Values.resources.requests "cpu" (tpl .Values.resources.requests.cpu .) -}}
  {{- $_ := set .Values.resources.requests "memory" (tpl .Values.resources.requests.memory .) -}}

  {{- $rootContext := . -}}
  {{- $componentContext := .Values -}}

  {{/* Evaluate templates in envFrom object list */}}
  {{- range $envFromKey, $envFromObject := .Values.envFrom -}}

      {{- if $envFromObject.configMapRef -}}
        {{- $_ := set $envFromObject.configMapRef "name" (tpl $envFromObject.configMapRef.name $rootContext) -}}
      {{- else if $envFromObject.secretRef -}}
        {{- $_ := set $envFromObject.secretRef "name" (tpl $envFromObject.secretRef.name $rootContext) -}}
      {{- end -}}
      
  {{- end -}}

  {{/* Expand the persistence */}}
  {{- range $volumeKey, $volume := .Values.persistence -}}

      {{- $isEnabled := false -}}
  
      {{- if eq (typeOf $volume.enabled) "string" -}}
        {{- $isEnabled = eq (tpl $volume.enabled $rootContext) "true" -}}
      {{- else if eq (typeOf $volume.enabled) "bool"  -}}
        {{- $isEnabled = $volume.enabled -}}
      {{- else -}} 
        {{- fail (
            printf "Condition is not met. Enabled field not string or bool, type found: '%s', for volume '%s', @ '%s' ." 
            (typeOf $volume.enabled) 
            $volumeKey 
            (include "bjw-s.common.lib.chart.names.fullname" $rootContext)
          ) 
        -}}
      {{- end -}}

      {{- $_ := set $volume "enabled" $isEnabled -}}

  {{- end -}}

  {{/* Expand the secrets */}}
  {{- range $secretKey, $secret := .Values.secrets -}}

    {{- $isEnabled := false -}}
    {{- $isExternal := not (not (index $secret `secretRef`)) -}}
    {{- $excludeFromEnv := get $secret `excludeFromEnv` }}

    {{- if eq (typeOf $secret.enabled) "string" -}}
      {{- $isEnabled = eq (tpl $secret.enabled $rootContext) "true" -}}
    {{- else if eq (typeOf $secret.enabled) "bool"  -}}
      {{- $isEnabled = $secret.enabled -}}
    {{- else -}} 
      {{- fail (
          printf "Condition is not met. Enabled field not string or bool, type found: '%s', for secret '%s', @ '%s' ." 
          (typeOf $secret.enabled) 
          $secretKey 
          (include "bjw-s.common.lib.chart.names.fullname" $rootContext)
        ) 
      -}}
    {{- end -}}

    {{- $_ := set $secret "enabled" $isEnabled -}}
    {{- if and (or $isEnabled $isExternal) (not $excludeFromEnv) -}}
      
      {{- $newSecretName := or (index $secret `secretRef`) (printf "%s-%s" (include "bjw-s.common.lib.chart.names.fullname" $rootContext) $secretKey) -}}
      {{- $newElement := dict "secretRef" (dict "name" $newSecretName) -}}
      {{- $_ := set $componentContext "envFrom" (append $componentContext.envFrom $newElement) -}}
    {{- end -}}
      
  {{- end -}}

  {{/* Expand the configMaps */}}
  {{- range $configMapKey, $configMap := .Values.configMaps -}}

    {{- $isEnabled := false -}}
    {{- $isExternal := not (not (index $configMap `configMapRef`)) -}}
    {{- $excludeFromEnv := get $configMap `excludeFromEnv` }}

    {{- if eq (typeOf $configMap.enabled) "string" -}}
      {{- $isEnabled = eq (tpl $configMap.enabled $rootContext) "true" -}}
    {{- else if eq (typeOf $configMap.enabled) "bool"  -}}
      {{- $isEnabled = $configMap.enabled -}}
    {{- else -}} 
      {{- fail (
          printf "Condition is not met. Enabled field not string or bool, type found: '%s', for configMap '%s', @ '%s' ." 
          (typeOf $configMap.enabled) 
          $configMapKey 
          (include "bjw-s.common.lib.chart.names.fullname" $rootContext)
        ) 
      -}}
    {{- end -}}

    {{- $_ := set $configMap "enabled" $isEnabled -}}
    {{- if and (or $isEnabled $isExternal) (not $excludeFromEnv) -}}
      
      {{- $newConfigMapName := or (index $configMap `configMapRef`) (printf "%s-%s" (include "bjw-s.common.lib.chart.names.fullname" $rootContext) $configMapKey) -}}
      {{- $newElement := dict "configMapRef" (dict "name" $newConfigMapName) -}}
      {{- $_ := set $componentContext "envFrom" (append $componentContext.envFrom $newElement) -}}
    {{- end -}}
      
  {{- end -}}


  {{/* Expand the persistence */}}
  {{- range $persistenceKey, $persistence := .Values.persistence -}}

    {{- $isEnabled := false -}}

    {{- if eq (typeOf $persistence.enabled) "string" -}}
      {{- $isEnabled = eq (tpl $persistence.enabled $rootContext) "true" -}}
    {{- else if eq (typeOf $persistence.enabled) "bool"  -}}
      {{- $isEnabled = $persistence.enabled -}}
    {{- else -}} 
      {{- fail (
          printf "Condition is not met. Enabled field not string or bool, type found: '%s', for persistence '%s', @ '%s' ." 
          (typeOf $persistence.enabled) 
          $persistenceKey 
          (include "bjw-s.common.lib.chart.names.fullname" $rootContext)
        ) 
      -}}
    {{- end -}}
    {{- $_ := set $persistence "enabled" $isEnabled -}}
      
  {{- end -}}

{{- end -}}