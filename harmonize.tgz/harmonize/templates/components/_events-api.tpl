{{- define "harmonize.components.events-api" -}}
{{/*
Events API Helper - Configures shared events storage service for UIS
This service provides centralized event storage and retrieval for all UIS indexers, processors, and APIs

Architecture:
  - Events API listens directly on port 8080
  - api-management-uis routes requests based on path prefix
  - URL format: http://api-management-uis:8080/{ledger-id}/track, http://api-management-uis:8080/{ledger-id}/events
*/}}

{{- $root := . -}}
{{- $originalRoot := $root.Original | default $root -}}

{{/* Set pod annotations for secret checksums */}}
{{- $_ := set $root.Values.podAnnotations "checksum.secrets" (tpl ($root.Values.secrets | toYaml) $root | sha256sum) -}}

{{/* Configure events-api for direct access */}}
{{- $_ := mergeOverwrite .Values (include "harmonize.components.events-api.PRIVATE.config" . | fromYaml) -}}

{{- end -}}


{{- define "harmonize.components.events-api.url.internal" -}}
  {{- $root := . -}}
  {{- if .Original -}}
    {{- $root = .Original -}}
  {{- end -}}
  {{/* Events API always listens on port 8080 */}}
  {{- printf "http://%s-%s-events-api:8080" $root.Release.Name $root.Chart.Name -}}
{{- end -}}


{{- define "harmonize.components.events-api.host.internal" -}}
  {{- $root := . -}}
  {{- if .Original -}}
    {{- $root = .Original -}}
  {{- end -}}
  {{- printf "%s-%s-events-api" $root.Release.Name $root.Chart.Name -}}
{{- end -}}


{{/* Templates defined after this line are private and only used in this file */}}

{{- define "harmonize.components.events-api.PRIVATE.config" -}}
{{/*
Events API Configuration
- Listens on port 8080 directly
- api-management-uis routes requests with ledger prefix
*/}}
{{- $root := . -}}
{{- $originalRoot := $root.Original | default $root -}}

{{/* Events API listens on 8080 */}}
env:
  ASPNETCORE_URLS: "http://+:8080"

{{/* Service exposes port 8080 */}}
service:
  main:
    ports:
      http:
        port: 8080
        targetPort: 8080

{{/* TCP probes on port 8080 */}}
probes:
  liveness:
    enabled: true
    type: TCP
    port: http
  startup:
    enabled: true
    type: TCP
    port: http
  readiness:
    enabled: true
    type: TCP
    port: http

persistence:
  {{/* TLS: Mount rootCA certificate for trusting self-signed certificates */}}
  rootca:
    enabled: "{{ $originalRoot.Values.harmonize.certificates.rootCA.enabled }}"
    name: '{{ include "harmonize.certificates.rootCA.secret_name" $originalRoot }}'
    type: configMap
    mountPath: /app/rootCA.crt
    subPath: rootCA.crt

{{- end -}}
