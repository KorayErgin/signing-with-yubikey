{{- define "harmonize.components.frontend-v2" -}}
  {{- $_ := merge .Values (include "harmonize.components.frontend-v2.PRIVATE.hardcoded_values" . | fromYaml) -}}
{{- end -}}

{{- define "harmonize.components.frontend-v2.url.public" -}}
  {{- $ingressScheme := include "harmonize.defines.ingress.scheme" . -}}
  {{- $url := tpl (index .Values.harmonize.urls "frontend-v2") . -}}
  {{ printf "%s%s" $ingressScheme $url }}
{{- end -}}


{{/* Templates defined after this line are private and only used in this file */}}


{{- define "harmonize.components.frontend-v2.PRIVATE.hardcoded_values" -}}

persistence:
  rootca:
    enabled: {{ tpl (.Values.harmonize.certificates.rootCA.enabled | toString) . }}

{{- if .Values.harmonize.urls.tls }}
ingress:
  main:
    tls:
    - hosts:
      - {{ tpl (index .Values.harmonize.urls "frontend-v2") . }}
      {{- if (index .Values.harmonize.certificates "frontend-v2" "enabled") }}
      secretName: {{ include "harmonize.certificates.frontend-v2.secret_name" . }}
      {{- end }}
{{- end }}

{{- end -}}