{{- define "harmonize.components.event-distribution-service-processing" -}}
  {{- $_ := merge .Values (include "harmonize.components.event-distribution-service-processing.PRIVATE.hardcoded_values" . | fromYaml) -}}
{{- end -}}

{{- define "harmonize.components.event-distribution-service-processing.url.internal" -}}
  {{ printf "http://%s-event-distribution-service-processing" ( include "bjw-s.common.lib.chart.names.fullname" .Original ) }}
{{- end -}}

{{- define "harmonize.components.event-distribution-service-processing.url.external" -}}
  {{ include "harmonize.defines.uris.external" (list . "event-distribution-service-processing") }}
{{- end -}}

{{/* Templates defined after this line are private and only used in this file */}}

{{- define "harmonize.components.event-distribution-service-processing.PRIVATE.hardcoded_values" -}}

env:
{{- if eq (.Values.harmonize.internalAmqp.amqpProtocolVersion | default "v09") "v1" }}
  # Internal AMQP v1 - use individual variables
  INTERNAL_AMQP_HOST: '{{ .Values.harmonize.internalAmqp.host | default (printf "%s-amqp" (include "bjw-s.common.lib.chart.names.fullname" .)) }}'
  INTERNAL_AMQP_PORT: '{{ .Values.harmonize.internalAmqp.port | default "5672" }}'
  INTERNAL_AMQP_USERNAME: '{{ .Values.harmonize.internalAmqp.username | default "user" }}'
  INTERNAL_AMQP_SSL_ENABLED: '{{ .Values.harmonize.internalAmqp.sslEnabled | default "true" }}'
  INTERNAL_AMQP_PASSWORD:
    valueFrom:
      secretKeyRef:
        name: '{{ include "harmonize.components.amqp.secret_name" . }}'
        key: AMQP_PASSWORD
{{- else }}
  # Internal AMQP v0.9 - use AMQP_URI
  INTERNAL_AMQP_URI:
    valueFrom:
      secretKeyRef:
        name: '{{ include "harmonize.components.amqp.secret_name" . }}'
        key: AMQP_URI
{{- end }}
  # External AMQP v1 - always use individual variables
  EXTERNAL_AMQP_PASSWORD:
    valueFrom:
      secretKeyRef:
        name: '{{ printf "%s-external-amqp" ( include "bjw-s.common.lib.chart.names.fullname" . ) }}'
        key: amqp-password

{{- end -}}