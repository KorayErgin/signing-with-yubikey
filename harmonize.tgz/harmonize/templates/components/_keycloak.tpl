{{- define "harmonize.components.keycloak" -}}
  {{- $_ := merge .Values (include "harmonize.components.keycloak.PRIVATE.hardcoded_values" . | fromYaml) -}}
{{- end -}}

{{- define "harmonize.components.keycloak.url.internal" -}}
  {{ printf "http://%s-keycloak" ( include "bjw-s.common.lib.chart.names.fullname" .Original ) }}
{{- end -}}

{{- define "harmonize.components.keycloak.url.health" -}}
  {{ printf "http://%s-keycloak:9000" ( include "bjw-s.common.lib.chart.names.fullname" .Original ) }}
{{- end -}}

{{- define "harmonize.components.keycloak.service" -}}
  {{ printf "%s-keycloak" ( include "bjw-s.common.lib.chart.names.fullname" .Original ) }}
{{- end -}}

{{- define "harmonize.components.keycloak.url.public" -}}
  {{ printf "%s%s" (include "harmonize.defines.ingress.scheme" .) (tpl .Values.harmonize.urls.oidc .) }}
{{- end -}}

{{- define "harmonize.components.keycloak.java-config.configmap_name" -}}
    {{- printf "%s-java-config" (include "bjw-s.common.lib.chart.names.fullname" . ) -}}
{{- end -}}

{{- define "harmonize.components.keycloak.realm-export.configmap_name" -}}
    {{- printf "%s-realm-export" (include "bjw-s.common.lib.chart.names.fullname" . ) -}}
{{- end -}}

{{- define "harmonize.components.keycloak.creds.secret_name" -}}
    {{- printf "%s-kc" (include "bjw-s.common.lib.chart.names.fullname" . ) -}}
{{- end -}}

{{- define "harmonize.components.keycloak.psql.secret_name" -}}
    {{- printf "%s-psql" (include "bjw-s.common.lib.chart.names.fullname" . ) -}}
{{- end -}}

{{- define "harmonize.components.keycloak.oidc_discoveryurl" -}}
  {{ printf "%s/.well-known/openid-configuration" (printf "%s/realms/Metaco" (include "harmonize.components.keycloak.url.internal" .)) }}
{{- end -}}

{{- define "harmonize.components.keycloak.oauth_server_url" -}}
  {{ (printf `%s/realms/Metaco` (include `harmonize.components.keycloak.url.internal` .)) }}
{{- end -}}

{{- define "harmonize.components.keycloak.oauth_issuer_url" -}}
  {{ (printf `%s/realms/Metaco` (include `harmonize.components.keycloak.url.public` .)) }}
{{- end -}}

{{/* Templates defined after this line are private and only used in this file */}}
{{- define "harmonize.components.keycloak.PRIVATE.hardcoded_values" -}}

{{- $db_password    := default (randAlpha 32) .Values.harmonize.postgresql.password }}
{{- $kc_admin       := default "admin" .Values.harmonize.keycloak.admin.name }}
{{- $kc_admin_pass  := default (randAlpha 32) .Values.harmonize.keycloak.admin.password }}
{{- $kc_realm_admin_name    := default "realm-admin" .Values.harmonize.keycloak.realmAdmin.name }}
{{- $kc_realm_admin_secret  := default (randAlpha 32) .Values.harmonize.keycloak.realmAdmin.secret }}

{{/* Re-use existing values if exists */}}
{{- $secret_name  := include "harmonize.components.keycloak.psql.secret_name" . -}}
{{- $secret_value := lookup "v1" "Secret" .Release.Namespace $secret_name -}}

{{- if $secret_value -}}
  {{ $_ := (required (printf "key KC_DB_URL must exist in secret %s" $secret_name) (index $secret_value.data "KC_DB_URL")) | b64dec -}}
{{- end -}}

{{- $secret_name  := include "harmonize.components.keycloak.creds.secret_name" . -}}
{{- $secret_value := lookup "v1" "Secret" .Release.Namespace $secret_name -}}

{{- if $secret_value -}}
  {{ $kc_admin        = (required (printf "key KEYCLOAK_ADMIN must exist in secret %s" $secret_name) (index $secret_value.data "KEYCLOAK_ADMIN")) | b64dec -}}
  {{ $kc_admin_pass   = (required (printf "key KEYCLOAK_ADMIN_PASSWORD must exist in secret %s" $secret_name) (index $secret_value.data "KEYCLOAK_ADMIN_PASSWORD")) | b64dec -}}

  {{- if and (not (empty (index $secret_value.data "KC_BOOTSTRAP_ADMIN_CLIENT_SECRET"))) (empty .Values.harmonize.keycloak.realmAdmin.secret) -}}
    {{ $kc_realm_admin_secret   = (required (printf "key KC_BOOTSTRAP_ADMIN_CLIENT_SECRET must exist in secret %s" $secret_name) (index $secret_value.data "KC_BOOTSTRAP_ADMIN_CLIENT_SECRET")) | b64dec -}}
  {{- end -}}

  {{/* Re-use client_id value if exist */}}
  {{- if (not (empty (index $secret_value.data "KC_BOOTSTRAP_ADMIN_CLIENT_ID"))) -}}
    {{ $kc_realm_admin_name   = (required (printf "key KC_BOOTSTRAP_ADMIN_CLIENT_ID must exist in secret %s" $secret_name) (index $secret_value.data "KC_BOOTSTRAP_ADMIN_CLIENT_ID")) | b64dec -}}
  {{- end -}}
{{- end -}}

initContainers:
  dbsetup:
    env:
      DB_SCHEMA: {{ .Values.harmonize.keycloak.dbSchema | default "keycloak" }}
    envFrom:
      - secretRef:
          name: {{ include "harmonize.components.keycloak.psql.secret_name" . }}
          optional: true

{{/* create/update secrets */}}
secrets:
  kc:
    stringData:
      KEYCLOAK_ADMIN_PASSWORD: {{ $kc_admin_pass | quote }}
      KEYCLOAK_ADMIN: {{ $kc_admin | quote }}
      KC_BOOTSTRAP_ADMIN_USERNAME: {{ $kc_admin | quote }}
      KC_BOOTSTRAP_ADMIN_PASSWORD: {{ $kc_admin_pass | quote }}
      KC_BOOTSTRAP_ADMIN_CLIENT_ID: {{ $kc_realm_admin_name | quote }}
      KC_BOOTSTRAP_ADMIN_CLIENT_SECRET: {{ $kc_realm_admin_secret | quote }}

persistence:
  rootca:
    enabled: {{ tpl (.Values.harmonize.certificates.rootCA.enabled | toString) . }}

{{- if .Values.harmonize.urls.tls }}
ingress:
  main:
    tls:
    - hosts:
      - {{ tpl (index .Values.harmonize.urls "oidc") . }}
      {{- if (index .Values.harmonize.certificates "keycloak" "enabled") }}
      secretName: {{ include "harmonize.certificates.keycloak.secret_name" . }}
      {{- end }}
{{- end }}

{{/* {{- required "TLS must be enabled on for the provider auth url" .Values.harmonize.urls.tls | quote -}}  */}}

{{- end -}}
