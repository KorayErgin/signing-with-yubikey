{{- define "harmonize.components.eod-reconciliation" -}}
  {{- $_ := merge .Values (include "harmonize.components.eod-reconciliation.PRIVATE.hardcoded_values" . | fromYaml) -}}
{{- end -}}

{{- define "harmonize.components.eod-reconciliation.url.public" -}}
  {{ printf "%s%s" (include "harmonize.defines.ingress.scheme" .) (index .Values.harmonize.urls "eod-reconciliation" .) }}
{{- end -}}

{{/* Templates defined after this line are private and only used in this file */}}

{{- define "harmonize.components.eod-reconciliation.PRIVATE.hardcoded_values" -}}

{{- $_ := mergeOverwrite .Values (get .Values.harmonize "eod-reconciliation") }}

{{- if .Values.harmonize.urls.tls }}
ingress:
  main:
    tls:
    - hosts:
      - {{ tpl (index .Values.harmonize.urls "eod-reconciliation") . }}
      {{- if (index .Values.harmonize.certificates "eod-reconciliation" "enabled") }}
      secretName: {{ include "harmonize.certificates.eod-reconciliation.secret_name" . }}
      {{- end }}
{{- end }}

persistence:
{{- if .Values.self_signed_ca_cert }}
  ca-crt:
    enabled: true
    name: '{{ printf "%s-ca-crt" ( include "bjw-s.common.lib.chart.names.fullname" . ) }}'
    type: secret
    mountPath: '{{ .Values.env.SELF_SIGNED_CA_CERT_PATH | default "/certs/ca.crt" }}'
    subPath: ca.crt
{{- end }}
secrets:
{{- if .Values.self_signed_ca_cert }}
  ca-crt:
    # -- Existing secret reference
    secretRef:
    # -- Enables or disables the Secret
    enabled: true
    stringData:
      ca.crt: |- {{ .Values.self_signed_ca_cert | nindent 8}}
{{- end }}
env:
  CB_ACCESS_KEY:
    valueFrom:
      secretKeyRef:
        name: '{{ printf "%s-access-secrets" ( include "bjw-s.common.lib.chart.names.fullname" . ) }}'
        key: key
  CB_ACCESS_PASSPHRASE:
    valueFrom:
      secretKeyRef:
        name: '{{ printf "%s-access-secrets" ( include "bjw-s.common.lib.chart.names.fullname" . ) }}'
        key: passphrase
  CB_ACCESS_SIGNING_KEY:
    valueFrom:
      secretKeyRef:
        name: '{{ printf "%s-access-secrets" ( include "bjw-s.common.lib.chart.names.fullname" . ) }}'
        key: signingKey
{{- if (and .Values.self_signed_ca_cert (not .Values.env.SELF_SIGNED_CA_CERT_PATH )) }}
  SELF_SIGNED_CA_CERT_PATH: /certs/ca.crt
{{- end }}
{{- end }}
