{{- define "harmonize.components.api-management" -}}
  {{- $_ := merge .Values (include "harmonize.components.api-management.PRIVATE.hardcoded_values" . | fromYaml) -}}
{{- end -}}


{{- define "harmonize.components.api-management.url.public" -}}
  {{ printf "%s%s" (include "harmonize.defines.ingress.scheme" .) (tpl .Values.harmonize.urls.api .) }}
{{- end -}}


{{- define "harmonize.components.api-management.url.internal" -}}
  {{ printf "http://%s-api-management" ( include "bjw-s.common.lib.chart.names.fullname" .Original ) }}
{{- end -}}


{{/* Templates defined after this line are private and only used in this file */}}


{{- define "harmonize.components.api-management.PRIVATE.hardcoded_values" -}}

{{- if .Values.harmonize.urls.tls }}
ingress:
  main:
    tls:
    - hosts:
      - {{ tpl .Values.harmonize.urls.api . }}
      {{- if (index .Values.harmonize.certificates "api-management" "enabled") }}
      secretName: {{ include "harmonize.certificates.api-management.secret_name" . }}
      {{- end }}
{{- end }}

{{- end -}}