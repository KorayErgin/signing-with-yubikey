{{- define "harmonize.components.flows" -}}
  {{- $_ := merge .Values (include "harmonize.components.flows.PRIVATE.hardcoded_values" . | fromYaml) -}}
{{- end -}}


{{- define "harmonize.components.flows.url.internal" -}}
  {{ printf "http://%s-flows" ( include "bjw-s.common.lib.chart.names.fullname" .Original ) }}
{{- end -}}


{{/* Templates defined after this line are private and only used in this file */}}


{{- define "harmonize.components.flows.PRIVATE.hardcoded_values" -}}

{{- end -}}