{{- define "harmonize.components.notary" -}}
  {{- $_ := merge .Values (include "harmonize.components.notary.PRIVATE.hardcoded_values" . | fromYaml) -}}
{{- end -}}


{{/* Templates defined after this line are private and only used in this file */}}

{{- define "harmonize.components.notary.PRIVATE.hardcoded_values" -}}

{{- if contains "kms_" .Values.platform }}
secrets:
  {{- include "harmonize.defines.kms.secrets" . | nindent 2 }}
sidecars:
  {{- include "harmonize.defines.kms.sidecars" . | nindent 2 }}
persistence:
  {{- include "harmonize.defines.kms.volumes" . | nindent 2 }}
  
env:
  HMZ_NOTARY_KMS_ENABLED: true
  HMZ_NOTARY_KMS_HOST: localhost
  HMZ_NOTARY_KMS_PORT: 10000
  HMZ_NOTARY_KMS_GRPC_KEEP_ALIVE_INTERVAL: 10
  HMZ_NOTARY_KMS_GRPC_KEEP_ALIVE_TIMEOUT: 10

{{- end }}

# Define env
{{- if eq .Values.platform "andromeda" }}
  env:
    HMZ_NOTARY_ANDROMEDA_ENABLED: true
    HMZ_NOTARY_ANDROMEDA_HOST: {{ .Values.andromeda.host }}
    HMZ_NOTARY_ANDROMEDA_GRPC_PORT: {{ .Values.andromeda.port }}
    HMZ_NOTARY_ANDROMEDA_TOKEN:
      valueFrom:
        secretKeyRef:
          name:
          key: andromeda-token
{{- else if eq .Values.platform "software_legacy"  }}
  env:
    HMZ_NOTARY_SOFTWARE_ENABLED: true
{{- else if eq .Values.platform "software" }}
  env:
    HMZ_NOTARY_HTTP_HSM_ENABLED: true
    kms__platform: mock
    kms__mock__phrase: dockerComposeKmsWebMock
{{- else if eq .Values.platform "luna" }}
  env:
    kms__platform: luna
    LUNA_HOST: {{ .Values.luna.host }}
    LUNA_PORT: {{ .Values.luna.port }}
    HMZ_NOTARY_HTTP_HSM_ENABLED: true
    LUNA_SERVER_CERTIFICATE:
      valueFrom:
        secretKeyRef:
          name: {{ printf "%s-luna-config" ( include "bjw-s.common.lib.chart.names.fullname" . ) }}
          key: LUNA_SERVER_CERTIFICATE
    LUNA_CLIENT_CERTIFICATE:
      valueFrom:
        secretKeyRef:
          name: {{ printf "%s-luna-config" ( include "bjw-s.common.lib.chart.names.fullname" . ) }}
          key: LUNA_CLIENT_CERTIFICATE
    LUNA_CLIENT_KEY:
      valueFrom:
        secretKeyRef:
          name: {{ printf "%s-luna-config" ( include "bjw-s.common.lib.chart.names.fullname" . ) }}
          key: LUNA_CLIENT_KEY
    kms__luna__slot: {{ .Values.luna.slot }}
    kms__luna__pin:
      valueFrom:
        secretKeyRef:
          name: {{ printf "%s-luna-config" ( include "bjw-s.common.lib.chart.names.fullname" . ) }}
          key: LUNA_PIN
{{- end }}
{{- end }}
