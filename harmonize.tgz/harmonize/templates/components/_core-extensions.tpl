{{- define "harmonize.components.core-extensions" -}}
  {{- $_ := merge .Values (include "harmonize.components.core-extensions.PRIVATE.hardcoded_values" . | fromYaml) -}}
{{- end -}}

{{- define "harmonize.components.core-extensions.url.internal" -}}
  {{ printf "http://%s-core-extensions" ( include "bjw-s.common.lib.chart.names.fullname" .Original ) }}
{{- end -}}


{{/* Templates defined after this line are private and only used in this file */}}

{{- define "harmonize.components.core-extensions.PRIVATE.hardcoded_values" -}}

{{- end -}}