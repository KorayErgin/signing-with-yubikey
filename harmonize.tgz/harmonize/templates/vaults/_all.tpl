{{/*
These changes are applied to all harmonize components
*/}}
{{- define "harmonize.vaults.all" -}}

{{- include "harmonize.components.all" . -}}

  {{- $_ := merge .Values (include "harmonize.vaults.PRIVATE.hardcoded_values" . | fromYaml) -}}
  
{{- end -}}



{{/*
Templates defined after this line are private and only used in this file
*/}}


{{- define "harmonize.vaults.PRIVATE.hardcoded_values" -}}


{{- if contains "kms_" .Values.platform }}
secrets:
  {{- include "harmonize.defines.kms.secrets" . | nindent 2 }}
sidecars:
  {{- include "harmonize.defines.kms.sidecars" . | nindent 2 }}
persistence:
  {{- include "harmonize.defines.kms.volumes" . | nindent 2 }}
{{- end }}

# temp storage dataibm only for ibm.cfg into /data
{{- if eq .Values.platform "ibm" }}
persistence:
  dataibm:
    enabled: true
    type: emptyDir
    mountPath: /data
  secretsibm:
    enabled: true
    name: '{{ printf "%s-secretsibm" ( include "bjw-s.common.lib.chart.names.fullname" . ) }}'
    type: secret
    mountPath: /isv_secrets
{{- end }}
{{- end -}}
