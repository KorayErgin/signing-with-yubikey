{{/*
Include components and generate config maps for feature flags
*/}}

{{/* Make sure all variables are set properly */}}
{{- include "bjw-s.common.loader.init" . -}}

{{- define "harmonize.features.configmap_name" -}}
    {{- printf "%s-features-configmap" ( include "bjw-s.common.lib.chart.names.fullname" (.Original | default .) ) -}}
{{- end -}}

apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ include "harmonize.features.configmap_name" . }}
  {{- with (include "bjw-s.common.lib.metadata.allLabels" . | fromYaml) }}
  labels: {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- with (include "bjw-s.common.lib.metadata.globalAnnotations" . | fromYaml) }}
  annotations: {{- toYaml . | nindent 4 }}
  {{- end }}
data:
  HMZ_FEATURE_TRUSTED_ADDRESS: "true"
  HMZ_FEATURE_HEDERA_TOKENS: "true"
  HMZ_FEATURE_DISABLE_NOTIFICATIONS: "true"
  HMZ_FEATURE_ERC1155: "true"
  HMZ_FEATURE_BITCOIN_REPLACE_BY_FEE: "true"
  HMZ_FEATURE_OPTIONAL_MAXIMUM_FEE: "true"
  HMZ_FEATURE_EXTERNAL_ACCOUNTS: "true"
  HMZ_FEATURE_APPROVAL_REASON: "true"
  HMZ_FEATURE_GENESIS_TRACEABILITY: "true"
  HMZ_FEATURE_ADD_N_LEDGERS: "true"
  HMZ_FEATURE_AML: "true"
  HMZ_FEATURE_OIDC: "true"
  HMZ_FEATURE_LOGIN_IDS: "true"
  HMZ_FEATURE_XRPL_FUNGIBLE_TOKENS: "true"
  HMZ_FEATURE_SOLANA_FUNGIBLE_TOKENS: "true"
  HMZ_FEATURE_STELLAR_FUNGIBLE_TOKENS: "true"
