{{/*
Include components and generate Kubernetes objects
*/}}

{{/* Make sure all variables are set properly */}}
{{- include "bjw-s.common.loader.init" . -}}

{{/* Template to print a value during compile time (and fail).
To use this : {{ template "debug.fail" [insert value here]}}
Unfortunately, helm does not have a way to print to stdout -without- failing today.

  e.g {{ template "debug.fail" .Values.harmonize.included_components }}
      {{ template "debug.fail" (list .Values $components)  }}

This can be used from yaml (e.g values.yaml) or .tpl files.
*/}}
{{- define "debug.fail" -}}
{{- . | toYaml | printf "\nyaml: \n%s" | fail -}}
{{- end -}}

{{/* Template to print a string value during helm execution (and continue execution).
    Note: This requires custom build sprig and helm library or will fail */}}
{{- define "debug.msg" -}}
{{/* Disabling this until helm/sprig accept Elton's PR for the pass function (might be renamed to something else like "print") */}}
{{/* {{- . | printf "%s" | pass -}} */}}
{{- end -}}

{{/* Template to print a yaml value during helm execution (and continue execution).
    Note: This requires custom build sprig and helm library or will fail */}}
{{- define "debug.yaml" -}}
{{/* Disabling this until helm/sprig accept Elton's PR for the pass function (might be renamed to something else like "print") */}}
{{/* {{- . | toYaml | printf "%s" | pass -}} */}}
{{- end -}}

{{/* Validate that placeholder values have been replaced */}}
{{- if hasPrefix "REPLACE_WITH" .Values.harmonize.urls.base -}}
  {{- fail "\n\nError: Domain not configured!\n\nPlease replace 'REPLACE_WITH_YOUR_DOMAIN' in harmonize.urls.base with your actual domain (e.g., 'myapp.example.com').\n" -}}
{{- end -}}

{{- range $name, $component := .Values.components -}}

  {{/* Special handling for event-distribution-service parent component */}}
  {{- if eq $name "event-distribution-service" -}}
    {{- if dig "enabled" false $component -}}
      {{/* If parent EDS is enabled, inject child components with full configuration from values.yaml */}}
      {{- $apiComponent := index $.Values.components "event-distribution-service-api" | default dict -}}
      {{- $_ := set $apiComponent "enabled" true -}}
      {{- $_ := set $.Values.components "event-distribution-service-api" $apiComponent -}}
      
      {{- $processingComponent := index $.Values.components "event-distribution-service-processing" | default dict -}}
      {{- $_ := set $processingComponent "enabled" true -}}
      {{- $_ := set $.Values.components "event-distribution-service-processing" $processingComponent -}}

      {{/* Auto-enable event-processing when EDS is enabled */}}
      {{- $eventProcessingComponent := index $.Values.components "event-processing" | default dict -}}
      {{- $_ := set $eventProcessingComponent "enabled" true -}}
      {{- $_ := set $.Values.components "event-processing" $eventProcessingComponent -}}
    {{- end -}}
    {{/* Skip processing the parent component itself */}}
    {{- continue -}}
  {{- end -}}

  {{/* Check if this component is included */}}
  {{- if gt (len $.Values.harmonize.included_components) 0 -}}
    {{- if not (has $name $.Values.harmonize.included_components) -}}
      {{- continue -}}
    {{- end -}}
  {{- end -}}

  {{/* Check if this component is excluded */}}
  {{- if has $name $.Values.harmonize.excluded_components -}}
    {{- continue -}}
  {{- end -}}

  {{- if not (dig "enabled" true $component) -}}
    {{- continue -}}
  {{- end -}}

  {{- if and $.Values.harmonize.externalAmqp.enabledForCoreComponents $.Values.harmonize.internalAmqp.enabledForCoreComponents -}}
    {{- printf "\nError: Either internal or external AMQP can be used by core-components, but not both at the same time. Please disable one of them.\n" | fail }}
  {{- else if (not (or $.Values.harmonize.externalAmqp.enabledForCoreComponents $.Values.harmonize.internalAmqp.enabledForCoreComponents)) }}
    {{- printf "\nError: Either internal or external AMQP required by core-components. Please enable one of them.\n" | fail }}
  {{- end -}}
  
  {{/* Create environment copy */}}
  {{- $copy := mustDeepCopy $ -}}

  {{/* Add a reference to the original */}}
  {{- $_ := set $copy "Original" $ -}}
  
  {{/* Set chart name to <parent chart name><component name> */}}
  {{- $_ := set $copy.Values "nameOverride" (printf "%s-%s" $.Chart.Name $name) -}}
  
  {{/* Set chart name to <parent chart name><component name> */}}
  {{- $_ := mergeOverwrite $copy.Values $component -}}

  {{/* Include component rules, both common and component specific */}}

  {{- include "harmonize.components.all" $copy -}}
  {{- include (printf "harmonize.components.%s" $name) $copy -}}

  {{/* Store changed values back into the component so other components can use them */}}
  {{/* REMOVED: it makes the helm secret too big -*/}}
  {{/* - $_ := mergeOverwrite $component $copy.Values -*/}}

  {{/* With all the values set properly then render the component using the library chart */}}
  {{ include "bjw-s.common.loader.all" $copy }}
{{- end -}}
