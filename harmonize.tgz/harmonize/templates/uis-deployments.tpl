{{/*
UIS Deployments Orchestrator
Generates all Unified Indexer Service (UIS) component deployments based on enabled networks
This template creates ONE deployment per network per protocol (like charts-next) for proper
database isolation. Each network gets its own schema (e.g., uis_evm_arbitrum_sepolia).
*/}}

{{/* Make sure all variables are set properly */}}
{{- include "bjw-s.common.loader.init" . -}}

{{- $root := . -}}

{{/*
Helper: Check if a protocol has UIS enabled
Args: list with [root, protocolKey]
Returns: boolean
*/}}
{{- define "uis-deployments.hasUisEnabled" -}}
{{- $root := index . 0 -}}
{{- $protocolKey := index . 1 -}}
{{- $hasUis := false -}}
{{- $ledgers := index $root.Values.harmonize.ledgers $protocolKey -}}
{{- range $networkName, $network := $ledgers -}}
  {{- if and $network.enabled (index $network "enableUIS") -}}
    {{- $hasUis = true -}}
  {{- end -}}
{{- end -}}
{{- $hasUis -}}
{{- end -}}

{{/*
Helper: Render a UIS component deployment for a specific network
Args: list with [root, protocol, network, component]
Example: [., "evm", "arbitrum-sepolia", "indexer"]
*/}}
{{- define "uis-deployments.renderComponent" -}}
  {{- $root := index . 0 -}}
  {{- $protocol := index . 1 -}}
  {{- $network := index . 2 -}}
  {{- $component := index . 3 -}}
  {{- $componentType := printf "uis-%s" $component -}}
  {{- $copy := mustDeepCopy $root -}}
  {{/* Store original root context for shared resources (certificates, etc.) */}}
  {{/* This allows template strings to access the main chart context via ._originalRoot */}}
  {{- $_ := set $copy "Original" $root -}}
  {{/* Include network in deployment name for isolation: harmonize-uis-indexer-evm-arbitrum-sepolia */}}
  {{/* Truncate name to stay within K8s 63-char limit when combined with release name */}}
  {{- $truncatedName := include "harmonize.indexers.uis.truncated-name" (list $root.Release.Name $root.Chart.Name $componentType $protocol $network) -}}
  {{- $_ := set $copy.Values "nameOverride" $truncatedName -}}
  {{/* Store network in Values for template access */}}
  {{- $_ := set $copy.Values "_uisNetwork" $network -}}
  {{/* Merge UIS component values from uis.<component> (e.g., uis.indexer, uis.processor) */}}
  {{- $_ := mergeOverwrite $copy.Values (index $root.Values.uis $component) -}}
  {{- if hasKey (index $root.Values.uis $component) $protocol -}}
    {{- $_ := mergeOverwrite $copy.Values (index $root.Values.uis $component $protocol) -}}
  {{- end -}}
  {{- $_ := include "harmonize.components.all" $copy -}}
  {{- $_ := include (printf "harmonize.indexers.%s-%s" $componentType $protocol) $copy -}}
{{ include "bjw-s.common.loader.all" $copy }}
---
{{- end -}}

{{/*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
AUTO-BUILD PROTOCOL LIST FROM METADATA
Components list is derived from hasAdapter in _uis-metadata.tpl
No need to manually maintain this list - just add protocol to metadata!
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
*/}}
{{- $protocols := list -}}
{{- $allProtocolNames := include "harmonize.indexers.uis.all-protocols" . | fromJsonArray -}}
{{- range $protocolName := $allProtocolNames -}}
  {{- $components := include "harmonize.indexers.uis.protocol-components" $protocolName | fromJsonArray -}}
  {{- $protocols = append $protocols (dict "name" $protocolName "components" $components) -}}
{{- end -}}

{{/*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
VALIDATION: Check network configurations against metadata
Fails early with clear error messages if misconfigured
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
*/}}
{{- range $protocol := $protocols -}}
  {{- $protocolName := $protocol.name -}}
  {{- $ledgers := index $root.Values.harmonize.ledgers $protocolName | default dict -}}
  {{- range $networkName, $networkConfig := $ledgers -}}
    {{- if $networkConfig -}}
      {{- include "harmonize.indexers.uis.validate-network-config" (list $root $protocolName $networkName $networkConfig) -}}
    {{- end -}}
  {{- end -}}
{{- end -}}

{{/* Check which protocols have UIS enabled and build enabled map */}}
{{- $enabledProtocols := dict -}}
{{- range $protocols -}}
  {{- $protocolKey := .name -}}
  {{- $hasUis := include "uis-deployments.hasUisEnabled" (list $root $protocolKey) | trim | eq "true" -}}
  {{- if $hasUis -}}
    {{- $_ := set $enabledProtocols .name . -}}
  {{- end -}}
{{- end -}}

{{- $hasAnyUis := gt (len $enabledProtocols) 0 -}}

{{/* UIS is only deployed when uis.enabled=true AND at least one protocol has enableUIS=true */}}
{{- if and $root.Values.uis.enabled $hasAnyUis -}}

---
{{/* ========== EVENTS API ========== */}}
{{/* Shared events storage service - single deployment for all UIS components */}}
{{/* Automatically deployed when UIS is enabled - no separate eventsApi.enabled flag needed */}}
{{- $copy := mustDeepCopy $root -}}
{{/* Preserve Original reference for imagePullSecrets resolution */}}
{{- $_ := set $copy "Original" $root -}}
{{- $_ := set $copy.Values "nameOverride" (printf "%s-events-api" $root.Chart.Name) -}}
{{/* Merge UIS events-api values from uis.events-api */}}
{{- $_ := mergeOverwrite $copy.Values (index $root.Values.uis "events-api") -}}
{{- $_ := include "harmonize.components.all" $copy -}}
{{- $_ := include "harmonize.components.events-api" $copy -}}
{{ include "bjw-s.common.loader.all" $copy }}
---
{{/* ========== API-MANAGEMENT-UIS ========== */}}
{{/* YARP reverse proxy for routing requests to Events API or UIS API based on path prefix */}}
{{/* Automatically deployed when UIS is enabled */}}
{{- $copy = mustDeepCopy $root -}}
{{/* Preserve Original reference for shared resources */}}
{{- $_ := set $copy "Original" $root -}}
{{- $_ := set $copy.Values "nameOverride" (printf "%s-api-management-uis" $root.Chart.Name) -}}
{{/* Merge UIS api-management-uis values from uis.api-management-uis */}}
{{- $_ := mergeOverwrite $copy.Values (index $root.Values.uis "api-management-uis") -}}
{{- $_ := include "harmonize.components.all" $copy -}}
{{- $_ := include "harmonize.components.api-management-uis" $copy -}}
{{ include "bjw-s.common.loader.all" $copy }}
---

{{/* ========== UIS COMPONENT DEPLOYMENTS ========== */}}
{{/* Generate ONE deployment per network per protocol for proper database isolation */}}
{{/* Each network gets its own schema (e.g., uis_evm_arbitrum_sepolia) */}}
{{/* Order: indexer -> processor -> api -> adapter (for protocols that have adapters) */}}

{{- $componentOrder := list "indexer" "processor" "api" "adapter" -}}
{{- range $componentName := $componentOrder -}}
  {{- range $protocolName, $protocolConfig := $enabledProtocols -}}
    {{- if has $componentName $protocolConfig.components -}}
      {{/* Get enabled networks for this protocol - iterate directly over ledgers */}}
      {{- $ledgers := index $root.Values.harmonize.ledgers $protocolName -}}
      {{- range $network, $networkConfig := $ledgers -}}
        {{- if and $networkConfig.enabled (index $networkConfig "enableUIS") -}}
{{/* ========== UIS {{ upper $componentName }} - {{ upper $protocolName }} - {{ $network }} ========== */}}
{{- include "uis-deployments.renderComponent" (list $root $protocolName $network $componentName) -}}
        {{- end -}}
      {{- end -}}
    {{- end -}}
  {{- end -}}
{{- end -}}

{{- end -}}
