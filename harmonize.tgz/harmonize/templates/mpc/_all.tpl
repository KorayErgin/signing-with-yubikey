{{/*
These changes are applied to all harmonize components
*/}}
{{- define "harmonize.mpc.all" -}}

{{- include "harmonize.components.all" . -}}

  {{- $_ := merge .Values (include "harmonize.mpc.PRIVATE.hardcoded_values" . | fromYaml) -}}
  
{{- end -}}

{{/*
Templates defined after this line are private and only used in this file
*/}}

{{- define "harmonize.mpc.PRIVATE.hardcoded_values" -}}

{{- if contains "kms_" .Values.platform }}
secrets:
  {{- include "harmonize.defines.kms.secrets" . | nindent 2 }}
sidecars:
  {{- include "harmonize.defines.kms.sidecars" . | nindent 2 }}
persistence:
  {{- include "harmonize.defines.kms.volumes" . | nindent 2 }}
{{- end }}

{{- end -}}

{{- define "harmonize.mpc-node.url.internal" -}}
  {{ printf "http://%s-%s" ( include "bjw-s.common.lib.chart.names.fullname" (.Original | default .) ) .node.name }}
{{- end -}}