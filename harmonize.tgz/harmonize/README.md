# harmonize

![Version: 1.26.5](https://img.shields.io/badge/Version-1.26.5-informational?style=flat-square) ![AppVersion: 1.26.5](https://img.shields.io/badge/AppVersion-1.26.5-informational?style=flat-square)

Metaco Digital Assets solution

## Concept

This chart aims to simplify the installation of Harmonize by providing meaningful defaults
and avoiding repetitions [DRY](https://en.wikipedia.org/wiki/Don%27t_repeat_yourself) At the same time, it allows for tuning each component to match
the target environment. This is achieved by using a [common library chart](https://github.com/bjw-s/helm-charts/blob/main/charts/library/common).

Each Harmonize component under `components.<component name>` it is an instance of the library
chart so you can override or extend any settings there. If you need the same settings for multiple
components, the `common` section might be used. `components.<component name>` values will take
priority thought.

Similarly, each Harmonize indexer under `indexers.<ledger name>` it is an instance of the library
chart so you can override or extend any settings there as well. Each indexer will be instantiated
using the values under `indexer.<ledger name>`. If you need the same settings for multiple
indexers, the `common` section might be used. `indexers.<ledger name>` values will take
priority thought.

The settings affecting multiple components such as the connection to the database are defined in the
`harmonize` section.

**WARNING**: This chart is still WIP. It is also not compatible with the previous Harmonize helm charts.

## Installing the Chart

To install the chart with the release name `my-release`:

1. Create a file `my-values.yaml` with the values you want to set as you do not want to override the main values.yaml file. For example:

```yaml
harmonize:

  urls:
    base: example.com

  repository:
    metaco:
      enabled: true
      registry: metaco.azurecr.io
      username: <user name provided by Metaco for the public repo (e.g metaco.azurecr.io)>
      password: <password provided by Metaco for the public repo (e.g metaco.azurecr.io)>
    metacoservices:
      enabled: true
      registry: metacoservices.azurecr.io
      username: <user name provided by Tech Services for the public repo (e.g metacoservices.azurecr.io)>
      password: <password provided by  Tech Services for the public repo (e.g metacoservices.azurecr.io)>
 
  ledgers:
    ethereum:
      testnet-goerli:
        enabled: true
        type: Geth
        uri: <url provided by your node provider>
    logging: <Default log level is info and this section can be skipped, but trace may be useful for PoCs to debug issues>
      logLevel: trace

common: <Optional but generally needs to be set depending on k8s distro. A nginx (or other tool) deployment may need to be done if no ingress exists>
  ingress:
    main:
      ingressClassName: 'nginx'
```

2. Deploy chart:

```bash
helm upgrade -i my-release oci://metacoservices.azurecr.io/flat/harmonize --version 1.26.5 -f my-values.yaml
```

3. Wait a few minutes until all pods are online and do the Genesis with:

```bash
API_URL=<API end point>
curl --request POST $API_URL/v1/genesis --header 'Content-Type: application/json' --data @genesis_settings.json
```

You can then check the Genesis worked fine by querying the Notary public key with

```bash
curl $API_URL/internal/v1/system/information
```

You should get something like:

```json
{
  "notary": {
    "apiPublicKey": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE58+P4KQxfMoxqOAMYJ3rMqI+yNcAsS8FBcSvRmiCxuMCLFzy39Fmy723QS+C556NAtOjRAdChR4VFXJNRJGDHQ==",
    "messagingPublicKey": "MCowBQYDK2VwAyEAC0eF2V7nvBjcYQoRf5+Lra/v+/QVhAyI/VLDsYe1mVI="
  },
  "authentication": {
    "oidcDiscoveryUrl": "http://auth.metaco.local/.well-known/openid-configuration"
  }
}
```

4. Note, in the case of re-deployment or new deployment in the same namespace, the PVCs must be cleaned manually as `helm uninstall` does not automatically delete them by default. Wiping out the PVCs will also require re-genesis.

## Using a local Container registry (RECOMMENDED)

You should keep a local copy of the container images used in this chart. This avoid that you
need to pull each time from Metaco repositories which adds latency and would prevent you
to deploy in case of network problems. It is also usually a pre-requisite for you to scan
the images before rolling them to production.

You can achieve this by:

1. Query the required docker images needed by this chart:

```bash
helm template my-release oci://metacoservices.azurecr.io/flat/harmonize --version 1.26.5|grep image:|awk '{print $NF}'
```

2. Pull them and push them to your local repository:

```bash
#!/bin/bash

CLIENT_ID=<YOUR ID>
TOKEN_PWD=<YOUR PASSWORD>

echo $TOKEN_PWD | sudo helm registry login --username $CLIENT_ID --password-stdin metaco.azurecr.io

# Define the Helm release and chart information
CHART_LOCATION=oci://metacoservices.azurecr.io/flat/harmonize
CHART_VERSION=v1.7.23

# Extract the image names from the Helm chart and outputs the pull statements
IMAGES=$(helm template $RELEASE_NAME $CHART_LOCATION --version $CHART_VERSION | grep image: | awk '{print $NF}')
for image in $IMAGES
do
  echo "docker pull --platform linux/amd64  $image"
done
```

Review and run the docker pull output commands.

## Installing on Rancher Desktop

If you want to run Metaco Harmonize standalone in your laptop, you might do this with [Rancher Desktop](https://rancherdesktop.io/)
which is available for Windows, Mac and Linux and brings a Kubernetes cluster.

After installing Rancher Desktop and before running the helm commands to install Metaco Harmonize you
need the following preparation steps:

1. Add the following entries to /etc/hosts

```bash
127.0.0.1       metaco.local
127.0.0.1       api.metaco.local
127.0.0.1       auth.metaco.local
```

2. Add the following entries to the Rancher Kubernetes DNS `NodeHosts` section:

```bash
kubectl edit cm coredns -n kube-system
```

```bash
NodeHosts:
  192.168.5.15 lima-rancher-desktop <
  192.168.5.15 metaco.local
  192.168.5.15 auth.metaco.local
  192.168.5.15 api.metaco.local
```

  Note, that the IP address is the one of your Rancher Desktop VM. You can find it with:

```bash
limactl list
```

  or by looking at the 1st line of the output of NodeHosts.

3. Do the [Helm chart install](#installing-the-chart) with `base: metaco.local`

4. Install the Metaco App in your laptop:
   1. from the Apple Store if you have a laptop with Apple Silicon. **NOTE:** you will
      need to use you cell phone to take a picture of the QR in your browser when connected
      to [http://metaco.local](http://metaco.local) and show it back to your laptop camera
      while running the Metaco app.
   2. using the Windows app with a Yubikey

**Homepage:** <https://metaco.com>

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| Angel Nunez Mencias | <angel.nunez@metaco.com> |  |
| Elton de Souza | <elton.desouza@metaco.com> |  |
| Clement | <clement.stauner@metaco.com> |  |

## Requirements

Kubernetes: `>=1.16.0-0`

| Repository | Name | Version |
|------------|------|---------|
| https://bjw-s-labs.github.io/helm-charts | common | 1.5.1 |
| https://charts.bitnami.com/bitnami | postgresql | 12.5.6 |
| https://open-telemetry.github.io/opentelemetry-helm-charts | opentelemetry-collector | 0.117.3 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| harmonize | object | See values bellow | Global Harmonize settings |
| harmonize.repository.base | string | `"metaco.azurecr.io/harmonize"` | Base URL where the harmonize components are. This might be either the default Azure Registry provided by Metaco (default) or a copy. |
| harmonize.urls.base | string | `"flat.m3t4c0.fun"` | **REQUIRED** - Base URL for Harmonize. Other URLs are subdomains of this base by default. |
| harmonize.urls.tls | bool | `false` | use TLS for ingress |
| harmonize.urls.frontend | string | `<base url>` | UI URL |
| harmonize.urls.frontend-v2 | string | `v2.<base url>` | Frontend V2 URL |
| harmonize.urls.api | string | `api.<base url>` | API URL |
| harmonize.urls.graphapi | string | `graphapi.<base url>` | GraphQL API URL |
| harmonize.urls.auth | string | `auth.<base url>` | auth URL |
| harmonize.urls.token | string | `auth.<base url>` | token URL for backward compat with previous OAuth2 endpoint. Valid when the OIDC feature is on. |
| harmonize.urls.oidc | string | `oidc.<base url>` | oidc URL |
| harmonize.urls.notary-bridge | string | `bridge.<base url>` | notary bridge URL |
| harmonize.urls.vault-bridge | string | `bridge.<base url>` | vault bridge URL |
| harmonize.urls.cb | string | `cb.<base url>` | cb adapter URL |
| harmonize.urls.eod-reconciliation | string | `eod-reconciliation.<base url>` | eod-reconciliation URL |
| harmonize.postgresql | object | `{"database":"postgres","dotNetParams":"","host":"","maxConnections":"8","password":"","port":"","sslcert":"","sslcertpfx":"","sslkey":"","sslkeypkcs8":"","sslmode":"","sslrootcert":"","urlParams":"","username":""}` | Postgres Connection String Parameters |
| harmonize.postgresql.host | string | `""` | Database server host |
| harmonize.postgresql.port | string | `""` | Database server host |
| harmonize.postgresql.database | string | `"postgres"` | Specifies the name of the database to connect to. |
| harmonize.postgresql.urlParams | string | `""` | Extra connection parameters for Java containers. |
| harmonize.postgresql.dotNetParams | string | `""` | Extra connection parameters for .NET containers. |
| harmonize.postgresql.sslmode | string | `""` | This option determines whether or with what priority a secure SSL TCP/IP connection will be negotiated with the server. There are six modes. disable: only try a non-SSL connection allow: first try a non-SSL connection; if that fails, try an SSL connection prefer: first try an SSL connection; if that fails, try a non-SSL connection require: only try an SSL connection. If a root CA file is present, verify the certificate in the same way as if verify-ca was specified verify-ca: only try an SSL connection, and verify that the server certificate is issued by a trusted certificate authority (CA) verify-full: only try an SSL connection, verify that the server certificate is issued by a trusted CA and that the requested server host name matches that in the certificate Reference: https://www.postgresql.org/docs/current/libpq-connect.html#LIBPQ-CONNSTRING |
| harmonize.postgresql.sslrootcert | string | `""` | This parameter specifies the name of a file containing SSL certificate authority (CA) certificate(s) |
| harmonize.postgresql.sslcert | string | `""` | This parameter specifies the file name of the client SSL certificate |
| harmonize.postgresql.sslcertpfx | string | `""` | This parameter specifies the location for the secret key used for the client certificate in PKCS12 format |
| harmonize.postgresql.sslkey | string | `""` | This parameter specifies the location for the secret key used for the client certificate in PEM format |
| harmonize.postgresql.sslkeypkcs8 | string | `""` | This parameter specifies the location for the secret key used for the client certificate in PKCS8 format |
| harmonize.postgresql.username | string | `""` | Database user name |
| harmonize.postgresql.password | string | `""` | Database password |
| harmonize.postgresql.maxConnections | string | `"8"` | Determines the maximum number of concurrent connections to the database server |
| harmonize.features | object | `{"aml":false,"external_accounts":false,"hedera_tokens":true,"login_ids":true,"notifications":false,"oidc":true,"optional_maximum_fee":true,"xrpl_fungible_tokens":false}` | Feature flags for Harmonize |
| harmonize.features.hedera_tokens | bool | `true` | Enable Hedera token support @default - true |
| harmonize.features.notifications | bool | `false` | Enable the use of notifications @default - false |
| harmonize.features.optional_maximum_fee | bool | `true` | Enable the optional maximum fee feature @default - true |
| harmonize.features.external_accounts | bool | `false` | Enable the optional external account feature @default - false |
| harmonize.features.aml | bool | `false` | Enable the optional Harmonize AML @default - false |
| harmonize.features.xrpl_fungible_tokens | bool | `false` | Enable the optional xrpl fungible tokens feature @default - false |
| harmonize.features.oidc | bool | `true` | Use new OIDC provider. Required for Single sign-on (SSO) Reference: https://docs.ripple.com/products/custody/support/change-history/v115#single-sign-on-sso @default - false |
| harmonize.features.login_ids | bool | `true` | Have multiple identities in User profiles. Required for Single sign-on (SSO) and identity federation Reference: https://docs.ripple.com/products/custody/support/change-history/v115#single-sign-on-sso @default - false |
| harmonize.externalAmqp | object | `{"amqpProtocolVersion":"v1","authType":"plain-authentication","enabledForCoreComponents":false,"existingSecret":null,"host":null,"password":"","port":null,"sslEnabled":null,"topicName":null,"username":null,"vhost":null}` | External AMQP is needed for event-processing but may optionally be used by core-components. |
| harmonize.externalAmqp.enabledForCoreComponents | bool | `false` | By default core-components use internal AMQP but setting this to true forced all amqp transactions to go through external AMQP    There might be slight performance impact so care should be taken to minimize latency between HMZ and external AMQP @default - false |
| harmonize.internalAmqp | object | `{"amqpProtocolVersion":"v09","enabledForCoreComponents":true,"existingSecret":"","host":null,"port":5672,"sslEnabled":true,"username":"user","vhost":"harmonize"}` | Internal AMQP may be used by core components but never for event-processing. |
| harmonize.internalAmqp.enabledForCoreComponents | bool | `true` | Either internal or external AMQP can be used for core-components, but not both.     If both internalAmqp.enabledForCoreComponents and externalAmqp.enabledForCoreComponents are true, an error will be thrown during deployment. @default - true |
| harmonize.internalAmqp.existingSecret | string | `""` | Existing, pre-populated secret in the same namespace. It must have the following keys:   rabbitmq-erlang-cookie:   rabbitmq-password:   AMQP_URI: "amqp://$username:$password@host:$port/$vhost" |
| harmonize.internalAmqp.host | string | `nil` | Host for internal AMQP. @default - '<helm chart full name>' |
| harmonize.internalAmqp.username | string | `"user"` | RabbitMQ user |
| harmonize.internalAmqp.vhost | string | `"harmonize"` | RabbitMQ vhost |
| harmonize.internalAmqp.port | int | `5672` | RabbitMQ port @default - 5672 |
| harmonize.internalAmqp.sslEnabled | bool | `true` | RabbitMQ ssl enabled @default - true |
| harmonize.genesis.enabled | bool | `true` | Enable Auto-genesis after deploying HMZ and connecting the Notary. Changes here have no effect after Genesis have been performed once. |
| harmonize.genesis.value | string | `"{\n  \"rootDomainSetup\": {\n    \"id\": \"5cd224fe-193e-8bce-c94c-c6c05245e2d1\",\n    \"alias\": \"My root domain\",\n    \"lock\": \"Unlocked\",\n    \"governingStrategy\": \"CoerceDescendants\",\n    \"permissions\": {\n      \"readAccess\": {\n        \"domains\": [\n          \"manager\",\n          \"compliance\",\n          \"director\"\n        ],\n        \"users\": [\n          \"manager\",\n          \"compliance\",\n          \"director\"\n        ],\n        \"endpoints\": [\n          \"manager\",\n          \"compliance\",\n          \"director\"\n        ],\n        \"policies\": [\n          \"manager\",\n          \"compliance\",\n          \"director\"\n        ],\n        \"accounts\": [\n          \"manager\",\n          \"compliance\",\n          \"director\"\n        ],\n        \"transactions\": [\n          \"manager\",\n          \"compliance\",\n          \"director\"\n        ],\n        \"requests\": [\n          \"manager\",\n          \"compliance\",\n          \"director\"\n        ],\n        \"events\": [\n          \"manager\",\n          \"compliance\",\n          \"director\"\n        ]\n      }\n    },\n    \"description\": \"The root domain\",\n    \"customProperties\": {},\n    \"users\": [\n      {\n        \"id\": \"6ac20654-450e-29e4-65e2-1bdecb7db7c4\",\n        \"alias\": \"hmz@metaco.com\",\n        \"publicKey\": \"MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE0qPYorNOs+hRnB0tBt/YTHzh3vZHlFwdWUbYQbk3s5gWEw3JPK2J/a+ffK4cRwgGdHwzU2jfAC6X+LnDOEFeVA==\",\n        \"roles\": [\n          \"manager\",\n          \"compliance\",\n          \"director\"\n        ],\n        \"lock\": \"Unlocked\",\n        \"description\": \"hmz user\",\n        \"customProperties\": {}\n      },\n      {\n        \"id\": \"f0ca2fb4-369f-4617-aaa3-6a2f3370e931\",\n        \"alias\": \"support1@metaco.com\",\n        \"publicKey\": \"MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEaSCFPTkam1dA1QK1wb9a2cxMPtbaz31kX1wDin6hNY43S0wpZixFeN3fOc853ncXWUMEho1N3heHFQlYxZgdFw==\",\n        \"roles\": [\n          \"manager\",\n          \"compliance\"\n        ],\n        \"lock\": \"Unlocked\",\n        \"description\": \"support1 user\",\n        \"customProperties\": {}\n      }\n    ],\n    \"policies\": [\n      {\n        \"id\": \"00000000-0000-0000-0000-000000000000\",\n        \"alias\": \"Catch-All policy\",\n        \"rank\": 20,\n        \"intentTypes\": null,\n        \"scope\": \"Self\",\n        \"scriptingEngine\": \"Javascript_v0\",\n        \"condition\": {\n          \"expression\": \"context.references.users[context.request.author.id].roles.includes('manager')\",\n          \"type\": \"Expression\"\n        },\n        \"workflow\": [\n          {\n            \"role\": \"manager\",\n            \"quorum\": 1,\n            \"type\": \"RoleQuorum\"\n          }\n        ],\n        \"lock\": \"Unlocked\",\n        \"description\": \"For demo purpose\",\n        \"customProperties\": {}\n      },\n      {\n        \"id\": \"00000000-0000-0000-0000-000000000001\",\n        \"alias\": \"Coercive Policy\",\n        \"rank\": 1000,\n        \"intentTypes\": null,\n        \"scope\": \"Descendants\",\n        \"scriptingEngine\": \"Javascript_v0\",\n        \"condition\": {\n          \"expression\": \"context.references.users[context.request.author.id].roles.includes('manager') && context.request.author.domainId =='5cd224fe-193e-8bce-c94c-c6c05245e2d1'\",\n          \"type\": \"Expression\"\n        },\n        \"workflow\": [\n          {\n            \"role\": \"manager\",\n            \"quorum\": 2,\n            \"type\": \"RoleQuorum\"\n          }\n        ],\n        \"lock\": \"Unlocked\",\n        \"description\": \"For demo purpose\",\n        \"customProperties\": {}\n      }\n    ],\n    \"type\": \"v0_CreateDomain\"\n  },\n  \"cryptoSetup\": {\n    \"apiSigning\": \"Secp256k1\",\n    \"collectionSigning\": \"Secp256k1\",\n    \"messageSigning\": \"Secp256k1\"\n  }\n}\n"` | Genesis configuration. **NOTE:** the default value is intended for PoCs and Demos only as it includes a test user (hmz@metaco.com) which uses a known private/public key set. |
| harmonize.notary.protocol | string | `"grpc"` | Protocol used between the Notary and the Notary-bridge |
| harmonize.logging.logLevel | string | `"info"` | Default log Level for all components not having its own value Possible values : trace | debug | info | warning | error | fatal |
| harmonize.telemetry.type | string | `"{{ (index .Values \"opentelemetry-collector\").enabled | ternary `otlp` `disabled` }}"` | Type of server to send metrics to. Possible values: `otlp` | `azure` | `jeager` | `disabled` |
| harmonize.telemetry.host | string | `"{{ (index .Values \"opentelemetry-collector\").enabled | ternary (printf \"%s-%s\" .Release.Name (index .Values \"opentelemetry-collector\").nameOverride) `` }}"` | Metric server host. |
| harmonize.telemetry.protocol | string | `"http"` | Metric server protocol. Possible values: `http` | `https` |
| harmonize.telemetry.port | int | `4317` | Metric server port. Open Telemetry (gRPC: 4317, HTTP: 4318) |
| harmonize.resources.set_requests_with_limit_values | object | `{"cpu":false,"memory":false}` | When this is set to true, then requested resources will be set to the same value as the limits. This results in larger resource amounts being allocated in idle cases but it will avoid spikes: Harmonize will always use the same amount of resources |
| harmonize.ledgers | object | `{"algorand":{"mainnet":{"enabled":false,"http":null},"testnet":{"enabled":false,"http":null}},"avalanche-c-chain":{"mainnet":{"enabled":false,"uri":null},"testnet-fuji":{"enabled":false,"uri":null}},"bitcoin":{"mainnet":{"enabled":false,"fallbackFeeRate":null,"nodeEndpoint":null,"password":null,"url":null,"user":null},"regtest-1":{"enabled":false,"fallbackFeeRate":null,"nodeEndpoint":null,"password":null,"url":null,"user":null},"testnet":{"enabled":false,"fallbackFeeRate":null,"nodeEndpoint":null,"password":null,"url":null,"user":null}},"bsc":{"mainnet":{"enabled":false,"uri":null},"testnet":{"enabled":false,"uri":null}},"cardano":{"mainnet":{"enabled":false,"http":null,"ws":null},"preprod":{"enabled":false,"http":null,"ws":null},"preview":{"enabled":false,"http":null,"ws":null},"testnet":{"enabled":false,"http":null,"ws":null}},"dash":{"mainnet":{"enabled":false,"fallbackFeeRate":null,"nodeEndpoint":null,"password":null,"url":null,"user":null},"regtest-1":{"enabled":false,"fallbackFeeRate":null,"nodeEndpoint":null,"password":null,"url":null,"user":null},"testnet":{"enabled":false,"fallbackFeeRate":null,"nodeEndpoint":null,"password":null,"url":null,"user":null}},"dogecoin":{"mainnet":{"enabled":false,"fallbackFeeRate":null,"nodeEndpoint":null,"password":null,"url":null,"user":null},"regtest-1":{"enabled":false,"fallbackFeeRate":null,"nodeEndpoint":null,"password":null,"url":null,"user":null},"testnet":{"enabled":false,"fallbackFeeRate":null,"nodeEndpoint":null,"password":null,"url":null,"user":null}},"ethereum":{"geth-dev":{"enabled":false,"uri":null},"mainnet":{"enabled":false,"uri":null},"parity-dev":{"enabled":false,"uri":null},"pow-mainnet":{"enabled":false,"uri":null},"testnet-goerli":{"enabled":false,"uri":null},"testnet-sepolia":{"enabled":false,"uri":null}},"hedera":{"mainnet":{"enabled":false,"http":null},"testnet":{"enabled":false,"http":null}},"litecoin":{"mainnet":{"enabled":false,"fallbackFeeRate":null,"nodeEndpoint":null,"password":null,"url":null,"user":null},"regtest-1":{"enabled":false,"fallbackFeeRate":null,"nodeEndpoint":null,"password":null,"url":null,"user":null},"testnet":{"enabled":false,"fallbackFeeRate":null,"nodeEndpoint":null,"password":null,"url":null,"user":null}},"polygon":{"mainnet":{"enabled":false,"uri":null},"testnet-mumbai":{"enabled":false,"uri":null}},"solana":{"devnet":{"enabled":false,"passphrase":null,"url":null},"mainnet":{"enabled":false,"passphrase":null,"url":null}},"stellar":{"devnet":{"enabled":false,"passphrase":null,"url":null},"mainnet":{"enabled":false,"passphrase":null,"url":null}},"substrate":{"dev":{"enabled":false,"sidecar":null,"ws":null},"kusama":{"enabled":false,"sidecar":null,"ws":null},"polkadot":{"enabled":false,"sidecar":null,"ws":null},"westend":{"enabled":false,"sidecar":null,"ws":null}},"tezos":{"mainnet":{"enabled":false,"uri":null},"sandbox":{"enabled":false,"uri":null},"testnet":{"enabled":false,"uri":null}},"xrpl":{"devnet":{"enabled":false,"uri":null},"mainnet":{"enabled":false,"uri":null},"regtest-1":{"enabled":false,"uri":null},"testnet":{"enabled":false,"uri":null}}}` | Defining ledgers in the this section will:<br> Automatically configure the ledger accounting component, pointing to the desired indexer.<br><br> The desired indexer can either be:<br> - Manually deployed, when defining the `network.indexerUrl` property (example: `bitcoin.mainnet.network.indexerUrl`),   pointing to the manually deployed indexer. <br> - Automatically deployed, according to the defined "network" that will be injected into the right automatically deployed indexer. <br><br> The general automatic deployment behavior is that one indexer will be deployed per chain and per network. <br> The specific case of NBXplorer, as it managed multiple chains and for backward compatibility is different. |
| harmonize.vaults.00000000-0000-0000-0000-000000000000.platform | string | `"mock"` | Type of KMS platform to use Depending on what you select you need to fill one of the sections bellow as well Possible values: mock \| luna \| andro \| kms_blocksafe \| ibm \| kms_mock \| kms-blocksafe \| kms-andromeda \| kms_soft \| kms_luna |
| harmonize.vaults.00000000-0000-0000-0000-000000000000.kms_mock | object | See values.yaml | Configure kms_mock if platform is set as kms_mock |
| harmonize.vaults.00000000-0000-0000-0000-000000000000.kms_mock.phrase | string | `nil` | kms_mock phrase |
| harmonize.vaults.00000000-0000-0000-0000-000000000000.kms_mock.norandom | bool | `false` | kms_mock noRandom |
| harmonize.vaults.00000000-0000-0000-0000-000000000000.kms_soft | object | See values.yaml | Configure kms_soft if platform is set as kms_soft |
| harmonize.vaults.00000000-0000-0000-0000-000000000000.kms_soft.master | string | `nil` | kms_soft master key |
| harmonize.vaults.00000000-0000-0000-0000-000000000000.kms_soft.kms_rewrapping_key | string | `nil` | Optional: kms_soft rewrapping key |
| harmonize.vaults.00000000-0000-0000-0000-000000000000.kms_soft.gcp_json | string | `nil` | Optional: gcp credentials in case the kms_rewrapping_key is set and it starts with "gcp:" |
| harmonize.vaults.00000000-0000-0000-0000-000000000000.kms_luna | object | See values.yaml | Configure kms_luna if platform is set as kms_luna |
| harmonize.vaults.00000000-0000-0000-0000-000000000000.kms_luna.host | string | `nil` | kms_luna host |
| harmonize.vaults.00000000-0000-0000-0000-000000000000.kms_luna.port | string | `nil` | kms_luna port |
| harmonize.vaults.00000000-0000-0000-0000-000000000000.kms_luna.slot | string | `nil` | kms_luna slot |
| harmonize.vaults.00000000-0000-0000-0000-000000000000.kms_luna.pin | string | `nil` | kms_luna pin |
| harmonize.vaults.00000000-0000-0000-0000-000000000000.kms_luna.client | object | See values.yaml | Configure kms_luna client |
| harmonize.vaults.00000000-0000-0000-0000-000000000000.kms_luna.client.certificate | string | `nil` | kms_luna client certificate |
| harmonize.vaults.00000000-0000-0000-0000-000000000000.kms_luna.client.key | string | `nil` | kms_luna client key |
| harmonize.vaults.00000000-0000-0000-0000-000000000000.kms_luna.server | object | See values.yaml | Configure kms_luna server |
| harmonize.vaults.00000000-0000-0000-0000-000000000000.kms_luna.server.certificate | string | `nil` | kms_luna server certificate |
| harmonize.vaults.00000000-0000-0000-0000-000000000000.kms_ibm | object | See values.yaml | Configure kms_ibm if platform is set as kms_ibm HPCS stands for Hyper Protect Crypto Service, a cloud HSM by IBM |
| harmonize.vaults.00000000-0000-0000-0000-000000000000.kms_ibm.system | string | `"cloud"` | kms_ibm system. This configuration ONLY supports "cloud" |
| harmonize.vaults.00000000-0000-0000-0000-000000000000.kms_ibm.instance | string | `nil` | kms_ibm HPCS instance ID |
| harmonize.vaults.00000000-0000-0000-0000-000000000000.kms_ibm.endpoint | string | `nil` | kms_ibm HPCS EP11 endpoint |
| harmonize.vaults.00000000-0000-0000-0000-000000000000.kms_ibm.apikey | string | `nil` | kms_ibm ApiKey to get access to HPCS |
| harmonize.vaults.00000000-0000-0000-0000-000000000000.kms_blocksafe | object | See values.yaml | Configure kms_blocksafe if platform is set as kms_blocksafe |
| harmonize.vaults.00000000-0000-0000-0000-000000000000.kms_blocksafe.secretRef | string | None. Values below are the default | kms_blocksafe secretRef with format: device: 3001@localhost slot: 0 pin: m3t4c0@tivoli2 |
| harmonize.vaults.00000000-0000-0000-0000-000000000000.kms_blocksafe.device | string | 3001@localhost (simulator) | kms_blocksafe device format: port@ip |
| harmonize.vaults.00000000-0000-0000-0000-000000000000.kms_blocksafe.slot | int | `0` | kms_blocksafe slot |
| harmonize.vaults.00000000-0000-0000-0000-000000000000.kms_blocksafe.pin | string | `"m3t4c0@tivoli2"` | kms_blocksafe pin |
| harmonize.coinbase-adapter.platform | string | `"kms_mock"` | Type of KMS platform to use Depending on what you select you need to fill one of the sections bellow as well Possible values: kms_mock \| kms_soft \| kms_blocksafe \| kms_luna \| kms_andro |
| harmonize.coinbase-adapter.hmz_comm_pub_key | string | `"toto"` | Notary Public Key |
| harmonize.coinbase-adapter.provider_uuid | string | `"00000000-0000-0000-0000-000000000000"` | Coinbase Provider UUID |
| harmonize.coinbase-adapter.access_secrets | object | See values.yaml | Coinbase Access Secrets |
| harmonize.coinbase-adapter.access_secrets.key | string | `"toto"` | Coinbase Access Key |
| harmonize.coinbase-adapter.access_secrets.passphrase | string | `"toto"` | Coinbase Passphrase |
| harmonize.coinbase-adapter.access_secrets.signingKey | string | `"toto"` | Coinbase Signing Key |
| harmonize.coinbase-adapter.kms_mock | object | See values.yaml | Configure kms_mock if platform is set as kms_mock |
| harmonize.coinbase-adapter.kms_mock.phrase | string | `nil` | kms_mock phrase |
| harmonize.coinbase-adapter.kms_mock.norandom | bool | `false` | kms_mock noRandom |
| harmonize.coinbase-adapter.kms_soft | object | See values.yaml | Configure kms_soft if platform is set as kms_soft |
| harmonize.coinbase-adapter.kms_soft.master | string | `nil` | kms_soft master key |
| harmonize.coinbase-adapter.kms_soft.kms_rewrapping_key | string | `nil` | Optional: kms_soft rewrapping key |
| harmonize.coinbase-adapter.kms_soft.gcp_json | string | `nil` | Optional: gcp credentials in case the kms_rewrapping_key is set and it starts with "gcp:" |
| harmonize.coinbase-adapter.kms_luna | object | See values.yaml | Configure kms_luna if platform is set as kms_luna |
| harmonize.coinbase-adapter.kms_luna.host | string | `nil` | kms_luna host |
| harmonize.coinbase-adapter.kms_luna.port | string | `nil` | kms_luna port |
| harmonize.coinbase-adapter.kms_luna.slot | string | `nil` | kms_luna slot |
| harmonize.coinbase-adapter.kms_luna.pin | string | `nil` | kms_luna pin |
| harmonize.coinbase-adapter.kms_luna.client | object | See values.yaml | Configure kms_luna client |
| harmonize.coinbase-adapter.kms_luna.client.certificate | string | `nil` | kms_luna client certificate |
| harmonize.coinbase-adapter.kms_luna.client.key | string | `nil` | kms_luna client key |
| harmonize.coinbase-adapter.kms_luna.server | object | See values.yaml | Configure kms_luna server |
| harmonize.coinbase-adapter.kms_luna.server.certificate | string | `nil` | kms_luna server certificate |
| harmonize.coinbase-adapter.kms_blocksafe | object | See values.yaml | Configure kms_blocksafe if platform is set as kms_blocksafe |
| harmonize.coinbase-adapter.kms_blocksafe.device | string | 3001@localhost (simulator) | kms_blocksafe device format: port@ip |
| harmonize.coinbase-adapter.kms_blocksafe.slot | int | `0` | kms_blocksafe slot |
| harmonize.coinbase-adapter.kms_blocksafe.pin | string | `"m3t4c0@tivoli2"` | kms_blocksafe pin |
| harmonize.coinbase-adapter.self_signed_ca_cert | string | `nil` | Self Signed CA Certificate in case of Proxy |
| harmonize.eod-reconciliation.provider_uuid | string | `"00000000-0000-0000-0000-000000000000"` | Coinbase Provider UUID |
| harmonize.eod-reconciliation.access_secrets | object | See values.yaml | Coinbase Access Secrets |
| harmonize.eod-reconciliation.access_secrets.key | string | `"toto"` | Coinbase Access Key |
| harmonize.eod-reconciliation.access_secrets.passphrase | string | `"toto"` | Coinbase Passphrase |
| harmonize.eod-reconciliation.access_secrets.signingKey | string | `"toto"` | Coinbase Signing Key |
| harmonize.eod-reconciliation.self_signed_ca_cert | string | `nil` | Self Signed CA Certificate in case of Proxy |
| harmonize.included_components | list | `[]` | List of harmonize components installed by this Helm chart. If left empty, all available components are installed. Possible values : see <components> section bellow. |
| common | object | See values bellow | Common settings for all Metaco components according to the [common library chart](https://github.com/bjw-s/helm-charts/blob/main/charts/library/common/values.yaml) |
| common.imagePullSecrets | list | `[]` | Secrets used to pull from private repository |
| common.image.pullPolicy | string | `"Always"` | Image pull policy |
| common.ingress.main.annotations | object | `{}` | Provide additional annotations which may be required. |
| common.ingress.main.labels | object | `{}` | Provide additional labels which may be required. |
| common.ingress.main.ingressClassName | string | `nil` | Set the ingressClass that is used for this ingress. |
| components | object | See values bellow | Settings for individual components according to the [common library chart](https://github.com/bjw-s/helm-charts/blob/main/charts/library/common/values.yaml) |
| components.keycloak | object | see bellow values | SSO support via Keycloak component used for auth in Harmonize. |
| components.keycloak.image.repository | string | <harmonize.repository.base>/keycloak | image repository |
| components.keycloak.image.tag | string | `"1.22.11"` | image tag |
| components.keycloak.persistence.rootca.enabled | string | .Values.harmonize.certificates.rootCA.enabled | Enable configmap with rootCA |
| components.keycloak.persistence.realm-import.enabled | bool | `true` | Realm import for OIDC |
| components.keycloak.secrets.oidc-credentials.secretRef | string | `nil` | Existing secret reference |
| components.keycloak.secrets.oidc-credentials.enabled | string | `"{{ not (index .Values `components` `keycloak` `secrets` `oidc-credentials` `secretRef`) }}"` | Enables or disables the Secret |
| components.keycloak.secrets.oidc-credentials.stringData | object | `{"OAUTH_SERVER_CLIENT_ID":"{{ tpl .Values.components.oauth.clients.keycloak.client_id . }}","OAUTH_SERVER_CLIENT_SECRET":"{{ tpl .Values.components.oauth.clients.keycloak.client_secret . }}"}` | Secret stringData content. Helm template enabled. |
| components.keycloak.secrets.psql.secretRef | string | `nil` | Existing secret reference |
| components.keycloak.secrets.psql.enabled | string | `"{{ not .Values.components.keycloak.secrets.psql.secretRef }}"` | Enables or disables the Secret |
| components.keycloak.secrets.kc.secretRef | string | `nil` | Existing secret reference |
| components.keycloak.secrets.kc.enabled | string | `"{{ not .Values.components.keycloak.secrets.kc.secretRef }}"` | Enables or disables the Secret |
| components.keycloak.secrets.clients.secretRef | string | `nil` | Existing secret reference |
| components.keycloak.secrets.clients.enabled | string | `"{{ not .Values.components.keycloak.secrets.clients.secretRef }}"` | Enables or disables the Secret |
| components.keycloak.ingress.main | object | See values.yaml | Enable and configure ingress settings for the chart under this key. |
| components.oauth.image.repository | string | <harmonize.repository.base>/oauth | image repository |
| components.oauth.image.tag | string | `"5.26.25"` | image tag |
| components.oauth.persistence.rootca.enabled | bool | .Values.harmonize.certificates.rootCA.enabled | Enable configmap with rootCA. |
| components.oauth.secrets.server.secretRef | string | `nil` | Existing secret reference |
| components.oauth.secrets.server.enabled | string | `"{{ not (index .Values `components` `oauth` `secrets` `server` `secretRef`) }}"` | Enables or disables the Secret |
| components.oauth.secrets.server.stringData | object | `{"OAUTH_SERVER_KEY":null}` | Secret stringData content. Helm template enabled. |
| components.oauth.secrets.clients.secretRef | string | `nil` | Existing secret reference |
| components.oauth.secrets.clients.enabled | string | `"{{ not (index .Values `components` `oauth` `secrets` `clients` `secretRef`) }}"` | Enables or disables the Secret |
| components.oauth.secrets.clients.stringData | object | `{"OAUTH_CLIENTS":"{{ tpl (include \"harmonize.defines.oauth.clients\" .Values.clients) . }}"}` | Secret stringData content. Helm template enabled. |
| components.oauth.secrets.oidc-credentials.secretRef | string | `nil` | Existing secret reference |
| components.oauth.secrets.oidc-credentials.enabled | string | `"{{ not (index .Values `components` `oauth` `secrets` `oidc-credentials` `secretRef`) }}"` | Enables or disables the Secret |
| components.oauth.secrets.oidc-credentials.stringData | object | `{"OAUTH_SERVER_CLIENT_ID":"{{ tpl .Values.components.oauth.clients.oauth.client_id . }}","OAUTH_SERVER_CLIENT_SECRET":"{{ tpl .Values.components.oauth.clients.oauth.client_secret . }}"}` | Secret stringData content. Helm template enabled. |
| components.oauth.secrets.psql.secretRef | string | `nil` | Existing secret reference |
| components.oauth.secrets.psql.enabled | string | `"{{ not (index .Values `components` `oauth` `secrets` `psql` `secretRef`) }}"` | Enables or disables the Secret |
| components.oauth.secrets.psql.stringData | object | `{"POSTGRES_URL":"{{ include \"harmonize.defines.uris.node\" (list . \"oauth\") }}"}` | Secret stringData content. Helm template enabled. |
| components.oauth.env.LOG_LEVEL | string | `"{{ include \"defines.logging.loglevel.apps\" . }}"` | log level. Use `logLevel` value to set up |
| components.oauth.logging.logLevel | string | `<harmonize.logging.log>` | log Level |
| components.oauth.ingress.main | object | See values.yaml | Enable and configure ingress settings for the chart under this key. |
| components.oauth.ingress.token | object | `{"enabled":false}` | auth /token endpoint for backward compatibility with previous OAuth2 |
| components.frontend.image.repository | string | <harmonize.repository.base>/frontend | image repository |
| components.frontend.image.tag | string | `"5.26.25"` | image tag |
| components.frontend.persistence.rootca.enabled | bool | .Values.harmonize.certificates.rootCA.enabled | Enable configmap with rootCA. |
| components.frontend.secrets.oidc-credentials.secretRef | string | `nil` | Existing secret reference |
| components.frontend.secrets.oidc-credentials.enabled | string | `"{{ not (index .Values `components` `frontend` `secrets` `oidc-credentials` `secretRef`) }}"` | Enables or disables the Secret |
| components.frontend.secrets.oidc-credentials.stringData | object | `{"NEXTAUTH_SECRET":"{{ tpl .Values.components.oauth.clients.frontend.client_secret . | sha256sum }}","OAUTH_SERVER_CLIENT_ID":"{{ tpl .Values.components.oauth.clients.frontend.client_id . }}","OAUTH_SERVER_CLIENT_SECRET":"{{ tpl .Values.components.oauth.clients.frontend.client_secret . }}"}` | Secret stringData content. Helm template enabled. |
| components.frontend.env.LOG_LEVEL | string | `"{{ include \"defines.logging.loglevel.apps\" . }}"` | log level. Use `logLevel` value to set up |
| components.frontend.ingress.main | object | See values.yaml | Enable and configure ingress settings for the chart under this key. |
| components.frontend-v2.image.repository | string | <harmonize.repository.base>/frontend-v2 | image repository |
| components.frontend-v2.image.tag | string | `"5.26.25"` | image tag |
| components.frontend-v2.persistence.rootca.enabled | bool | .Values.harmonize.certificates.rootCA.enabled | Enable configmap with rootCA. |
| components.frontend-v2.secrets.oidc-credentials.secretRef | string | `nil` | Existing secret reference |
| components.frontend-v2.secrets.oidc-credentials.enabled | string | `"{{ not (index .Values `components` `frontend-v2` `secrets` `oidc-credentials` `secretRef`) }}"` | Enables or disables the Secret |
| components.frontend-v2.secrets.oidc-credentials.stringData | object | `{"NEXTAUTH_SECRET":"{{ tpl (index .Values.components.oauth.clients \"frontend-v2\" \"client_secret\") . | sha256sum }}","OAUTH_SERVER_CLIENT_ID":"{{ tpl (index .Values.components.oauth.clients \"frontend-v2\" \"client_id\") . }}","OAUTH_SERVER_CLIENT_SECRET":"{{ tpl (index .Values.components.oauth.clients \"frontend-v2\" \"client_secret\") . }}"}` | Secret stringData content. Helm template enabled. |
| components.frontend-v2.env.LOG_LEVEL | string | `"{{ include \"defines.logging.loglevel.apps\" . }}"` | log level. Use `logLevel` value to set up |
| components.frontend-v2.ingress.main | object | See values.yaml | Enable and configure ingress settings for the chart under this key. |
| components.amqp.host | string | `"{{ .Values.harmonize.internalAmqp.host }}"` | RabbitMQ host. @default - <helm chart full name> |
| components.amqp.username | string | `"{{ .Values.harmonize.internalAmqp.username }}"` | RabbitMQ user |
| components.amqp.vhost | string | `"{{ .Values.harmonize.internalAmqp.vhost }}"` | RabbitMQ vhost |
| components.amqp.version | string | `"{{ .Values.harmonize.internalAmqp.version }}"` | RabbitMQ version |
| components.amqp.image.repository | string | `"{{tpl .Values.harmonize.repository.base .}}/amqp"` | image repository |
| components.amqp.image.tag | string | `"3.13.7-management-alpine"` | image tag |
| components.amqp.image.pullSecret | string | `""` | Pull secret |
| components.amqp.controller.replicas | int | `1` | RabbitMQ replicas.    It is 0 when external AMQP is enabled for core-components @default - 1 or 0 depending on `harmonize.internalAmqp.enabled` |
| components.amqp.logging.logLevel | string | `<harmonize.logging.log>` | log Level |
| components.amqp.secrets.secret.secretRef | string | `nil` | Existing secret reference |
| components.amqp.secrets.secret.enabled | string | `"{{ not (index .Values `components` `amqp` `secrets` `secret` `secretRef`) }}"` | Enables or disables the Secret .external-configuration.secrets.amqp |
| components.gateway.image.repository | string | <harmonize.repository.base>/gateway | image repository |
| components.gateway.image.tag | string | `"1.22.11"` | image tag |
| components.gateway.logging.logLevel | string | `<harmonize.logging.log>` | log Level |
| components.gateway.env.HMZ_LOG_LEVEL | string | `"{{ include \"defines.logging.loglevel\" . }}"` | log level. Use `logLevel` value to set up |
| components.gateway.secrets.psql.secretRef | string | `nil` | Existing secret reference |
| components.gateway.secrets.psql.enabled | string | `"{{ not (index .Values `components` `gateway` `secrets` `psql` `secretRef`) }}"` | Enables or disables the Secret |
| components.notification.image.repository | string | <harmonize.repository.base>/notification | image repository |
| components.notification.image.tag | string | `"5.26.25"` | image tag |
| components.notification.persistence.rootca.enabled | bool | .Values.harmonize.certificates.rootCA.enabled | Enable configmap with rootCA. |
| components.notification.secrets.oidc-credentials.secretRef | string | `nil` | Existing secret reference |
| components.notification.secrets.oidc-credentials.enabled | string | `"{{ not (index .Values `components` `notification` `secrets` `oidc-credentials` `secretRef`) }}"` | Enables or disables the Secret |
| components.notification.secrets.oidc-credentials.stringData | object | `{"OAUTH_SERVER_CLIENT_ID":"{{ tpl .Values.components.oauth.clients.notification.client_id . }}","OAUTH_SERVER_CLIENT_SECRET":"{{ tpl .Values.components.oauth.clients.notification.client_secret . }}"}` | Secret stringData content. Helm template enabled. |
| components.notification.secrets.psql.secretRef | string | `nil` | Existing secret reference |
| components.notification.secrets.psql.enabled | string | `"{{ not (index .Values `components` `notification` `secrets` `psql` `secretRef`) }}"` | Enables or disables the Secret |
| components.notification.env.LOG_LEVEL | string | `"{{ include \"defines.logging.loglevel.apps\" . }}"` | log level. Use `logLevel` value to set up |
| components.notification.logging.logLevel | string | `<harmonize.logging.log>` | log Level |
| components.core-extensions.image.repository | string | <harmonize.repository.base>/core-extensions | image repository |
| components.core-extensions.image.tag | string | `"1.9.15"` | image tag |
| components.core-extensions.secrets.oidc-credentials.secretRef | string | `nil` | Existing secret reference |
| components.core-extensions.secrets.oidc-credentials.enabled | string | `"{{ not (index .Values `components` `core-extensions` `secrets` `oidc-credentials` `secretRef`) }}"` | Enables or disables the Secret |
| components.core-extensions.secrets.oidc-credentials.stringData | object | `{"Harmonize__OIDC__ClientId":"{{ tpl (index .Values.components.oauth.clients `core-extensions` `client_id`) . }}","Harmonize__OIDC__ClientSecret":"{{ tpl (index .Values.components.oauth.clients `core-extensions` `client_secret`) . }}"}` | Secret stringData content. Helm template enabled. |
| components.core-extensions.secrets.psql.secretRef | string | `nil` | Existing secret reference |
| components.core-extensions.secrets.psql.enabled | string | `"{{ not (index .Values `components` `core-extensions` `secrets` `psql` `secretRef`) }}"` | Enables or disables the Secret |
| components.core-extensions.secrets.smtp.secretRef | string | `nil` | Existing secret reference |
| components.core-extensions.secrets.smtp.stringData | object | `{"Notification__Email__Sender":"{{ tpl .Values.harmonize.notifications.email.sender . }}","Notification__Email__Smtp__Host":"{{ tpl .Values.harmonize.notifications.email.smtp.host . }}","Notification__Email__Smtp__Password":"{{ tpl .Values.harmonize.notifications.email.smtp.password . }}","Notification__Email__Smtp__Port":"{{ tpl .Values.harmonize.notifications.email.smtp.port . }}","Notification__Email__Smtp__UserName":"{{ tpl .Values.harmonize.notifications.email.smtp.username . }}"}` | Secret stringData content. Helm template enabled. |
| components.core-extensions.env.Logging__LogLevel__Default | string | `"{{ include \"defines.logging.loglevel.dotnet\" . }}"` | log level. Use `logLevel` value to set up |
| components.core-extensions.logging.logLevel | string | `<harmonize.logging.log>` | log Level |
| components.api-management.image.repository | string | <harmonize.repository.base>/api-management | image repository |
| components.api-management.image.tag | string | `"1.4.8"` | image tag |
| components.api-management.logging.logLevel | string | `<harmonize.logging.log>` | log Level |
| components.api-management.ingress.main | object | See values.yaml | Enable and configure ingress settings for the chart under this key. |
| components.graph-api.image.repository | string | <harmonize.repository.base>/graph-api | image repository |
| components.graph-api.image.tag | string | `"5.26.25"` | image tag |
| components.graph-api.secrets.oidc-credentials.secretRef | string | `nil` | Existing secret reference |
| components.graph-api.secrets.oidc-credentials.enabled | string | `"{{ not (index .Values `components` `graph-api` `secrets` `oidc-credentials` `secretRef`) }}"` | Enables or disables the Secret |
| components.graph-api.secrets.oidc-credentials.stringData | object | `{"OAUTH_SERVER_CLIENT_ID":"{{ tpl (index .Values.components.oauth.clients \"graph-api\" \"client_id\") . }}","OAUTH_SERVER_CLIENT_SECRET":"{{ include `harmonize.components.oauth.client_secret` (list . `graph-api`) }}"}` | Secret stringData content. Helm template enabled. |
| components.graph-api.secrets.psql.secretRef | string | `nil` | Existing secret reference |
| components.graph-api.secrets.psql.enabled | string | `"{{ not (index .Values `components` `graph-api` `secrets` `psql` `secretRef`) }}"` | Enables or disables the Secret |
| components.graph-api.env.LOG_LEVEL | string | `"{{ include \"defines.logging.loglevel.apps\" . }}"` | log level. Use `logLevel` value to set up |
| components.graph-api.persistence.rootca.enabled | string | .Values.harmonize.certificates.rootCA.enabled | Enable configmap with rootCA. |
| components.graph-api.ingress.main | object | See values.yaml | Enable and configure ingress settings for the chart under this key. |
| components.graph-api.logging.logLevel | string | `<harmonize.logging.log>` | log Level |
| components.replicator.image.repository | string | <harmonize.repository.base>/replicator | image repository |
| components.replicator.image.tag | string | `"5.26.25"` | image tag |
| components.replicator.secrets.oidc-credentials.secretRef | string | `nil` | Existing secret reference |
| components.replicator.secrets.oidc-credentials.enabled | string | `"{{ not (index .Values `components` `replicator` `secrets` `oidc-credentials` `secretRef`) }}"` | Enables or disables the Secret |
| components.replicator.secrets.oidc-credentials.stringData | object | `{"OAUTH_SERVER_CLIENT_ID":"{{ tpl (index .Values.components.oauth.clients \"replicator\" \"client_id\") . }}","OAUTH_SERVER_CLIENT_SECRET":"{{ include `harmonize.components.oauth.client_secret` (list . `replicator`) }}"}` | Secret stringData content. Helm template enabled. |
| components.replicator.secrets.psql.secretRef | string | `nil` | Existing secret reference |
| components.replicator.secrets.psql.enabled | string | `"{{ not (index .Values `components` `replicator` `secrets` `psql` `secretRef`) }}"` | Enables or disables the Secret |
| components.replicator.env.LOG_LEVEL | string | `"{{ include \"defines.logging.loglevel.apps\" . }}"` | log level. Use `logLevel` value to set up |
| components.replicator.persistence.rootca.enabled | string | .Values.harmonize.certificates.rootCA.enabled | Enable configmap with rootCA. |
| components.replicator.logging.logLevel | string | `<harmonize.logging.log>` | log Level |
| components.notary-bridge.image.repository | string | <harmonize.repository.base>/approval-bridge | image repository |
| components.notary-bridge.image.tag | string | `"1.22.11"` | image tag |
| components.notary-bridge.secrets.psql.secretRef | string | `nil` | Existing secret reference |
| components.notary-bridge.secrets.psql.enabled | string | `"{{ not (index .Values `components` `notary-bridge` `secrets` `psql` `secretRef`) }}"` | Enables or disables the Secret |
| components.notary-bridge.logging.logLevel | string | `<harmonize.logging.log>` | log Level |
| components.notary-bridge.ingress.main | object | See values.yaml | Enable and configure ingress settings for the chart under this key. |
| components.notary.image.repository | string | <harmonize.repository.base>/approval-notary | image repository |
| components.notary.image.tag | string | `"1.22.11"` | image tag |
| components.notary.image.kmsconnect.repository | string | `"{{tpl .Values.harmonize.repository.base .}}/{{ replace \"_\" \"-\" .Values.platform }}"` | kms connect sidecar image repository |
| components.notary.image.kmsconnect.tag | string | `"1.9.15"` | image tag |
| components.notary.platform | string | `"software_legacy"` | Type of KMS platform to use Depending on what you select you need to fill one of the sections bellow as well Possible values: software_legacy \| andromeda \| software \| luna \| kms-blocksafe \| kms-andromeda \| kms_mock \| kms_soft \| kms_luna |
| components.notary.kms_blocksafe | object | See values.yaml | Configure kms_blocksafe if platform is set as kms_blocksafe |
| components.notary.kms_blocksafe.device | string | 3001@localhost (simulator) | kms_blocksafe device format: port@ip |
| components.notary.kms_blocksafe.slot | int | `0` | kms_blocksafe slot |
| components.notary.kms_blocksafe.pin | string | `"m3t4c0@tivoli2"` | kms_blocksafe pin |
| components.notary.kms_mock | object | See values.yaml | Configure kms_mock if platform is set as kms_mock |
| components.notary.kms_mock.phrase | string | `nil` | kms_mock phrase |
| components.notary.kms_mock.norandom | bool | `false` | kms_mock noRandom |
| components.notary.kms_soft | object | See values.yaml | Configure kms_soft if platform is set as kms_soft |
| components.notary.kms_soft.master | string | `nil` | kms_soft master key |
| components.notary.kms_soft.kms_rewrapping_key | string | `nil` | Optional: kms_soft rewrapping key |
| components.notary.kms_soft.gcp_json | string | `nil` | Optional: gcp credentials in case the kms_rewrapping_key is set and it starts with "gcp:" |
| components.notary.kms_luna | object | See values.yaml | Configure kms_luna if platform is set as kms_luna |
| components.notary.kms_luna.host | string | `nil` | kms_luna host |
| components.notary.kms_luna.port | string | `nil` | kms_luna port |
| components.notary.kms_luna.slot | string | `nil` | kms_luna slot |
| components.notary.kms_luna.pin | string | `nil` | kms_luna pin |
| components.notary.kms_luna.client | object | See values.yaml | Configure kms_luna client |
| components.notary.kms_luna.client.certificate | string | `nil` | kms_luna client certificate |
| components.notary.kms_luna.client.key | string | `nil` | kms_luna client key |
| components.notary.kms_luna.server | object | See values.yaml | Configure kms_luna server |
| components.notary.kms_luna.server.certificate | string | `nil` | kms_luna server certificate |
| components.notary.kms_ibm | object | See values.yaml | Configure kms_ibm if platform is set as kms_ibm HPCS stands for Hyper Protect Crypto Service, a cloud HSM by IBM |
| components.notary.kms_ibm.system | string | `"cloud"` | kms_ibm system. This configuration ONLY supports "cloud" |
| components.notary.kms_ibm.instance | string | `nil` | kms_ibm HPCS instance ID |
| components.notary.kms_ibm.endpoint | string | `nil` | kms_ibm HPCS EP11 endpoint |
| components.notary.kms_ibm.apikey | string | `nil` | kms_ibm ApiKey to get access to HPCS |
| components.notary.logging.logLevel | string | `<harmonize.logging.log>` | log Level |
| components.vault-bridge.image.repository | string | <harmonize.repository.base>/vault-cold-bridge | image repository |
| components.vault-bridge.image.tag | string | `"1.27.4"` | image tag |
| components.vault-bridge.logging.logLevel | string | `<harmonize.logging.log>` | log Level |
| components.vault-bridge.ingress.main | object | See values.yaml | Enable and configure ingress settings for the chart under this key. |
| components.ledger-accounting.image.repository | string | <harmonize.repository.base>/ledger-accounting | image repository |
| components.ledger-accounting.image.tag | string | `"1.22.11"` | image tag |
| components.ledger-accounting.secrets.psql.secretRef | string | `nil` | Existing secret reference |
| components.ledger-accounting.secrets.psql.enabled | string | `"{{ not (index .Values `components` `ledger-accounting` `secrets` `psql` `secretRef`) }}"` | Enables or disables the Secret |
| components.web3connector.image.repository | string | <harmonize.repository.base>/web3-connector | image repository |
| components.web3connector.image.tag | string | `"5.26.25"` | image tag |
| components.web3connector.secrets.oidc-credentials.secretRef | string | `nil` | Existing secret reference |
| components.web3connector.secrets.oidc-credentials.enabled | string | `"{{ not (index .Values `components` `web3connector` `secrets` `oidc-credentials` `secretRef`) }}"` | Enables or disables the Secret |
| components.web3connector.secrets.oidc-credentials.stringData | object | `{"OAUTH_SERVER_CLIENT_ID":"{{ tpl .Values.components.oauth.clients.web3connector.client_id . }}","OAUTH_SERVER_CLIENT_SECRET":"{{ tpl .Values.components.oauth.clients.web3connector.client_secret . }}"}` | Secret stringData content. Helm template enabled. |
| components.web3connector.secrets.psql.secretRef | string | `nil` | Existing secret reference |
| components.web3connector.secrets.psql.enabled | string | `"{{ not (index .Values `components` `web3connector` `secrets` `psql` `secretRef`) }}"` | Enables or disables the Secret |
| components.compliance.image.repository | string | <harmonize.repository.base>/compliance | image repository |
| components.compliance.image.tag | string | `"0.5.2"` | image tag |
| components.compliance.secrets.psql.secretRef | string | `nil` | Existing secret reference |
| components.compliance.secrets.psql.enabled | string | `"{{ not (index .Values `components` `compliance` `secrets` `psql` `secretRef`) }}"` | Enables or disables the Secret |
| components.event-processing.image.repository | string | <harmonize.repository.base>/event-processing | image repository |
| components.event-processing.image.tag | string | `"1.22.11"` | image tag |
| components.event-processing.secrets.external-amqp.secretRef | string | `nil` | Existing secret reference |
| components.event-processing.secrets.external-amqp.enabled | string | `"{{ not (index .Values `components` `event-processing` `secrets` `external-amqp` `secretRef`) }}"` | Enables or disables the Secret |
| components.event-processing.secrets.external-amqp.stringData | object | `{"amqp-password":"{{ tpl .Values.harmonize.externalAmqp.password . }}"}` | Secret stringData content. Helm template enabled. |
| components.event-processing.secrets.psql.secretRef | string | `nil` | Existing secret reference |
| components.event-processing.secrets.psql.enabled | string | `"{{ not (index .Values `components` `event-processing` `secrets` `psql` `secretRef`) }}"` | Enables or disables the Secret |
| components.flows.image.repository | string | <harmonize.repository.base>/flows | image repository |
| components.flows.image.tag | string | `"1.9.4"` | image tag |
| components.flows.secrets.oidc-credentials.secretRef | string | `nil` | Existing secret reference |
| components.flows.secrets.oidc-credentials.enabled | string | `"{{ not (index .Values `components` `flows` `secrets` `oidc-credentials` `secretRef`) }}"` | Enables or disables the Secret |
| components.flows.secrets.oidc-credentials.stringData | object | `{"Harmonize__OIDC__ClientId":"{{ tpl .Values.components.oauth.clients.flows.client_id . }}","Harmonize__OIDC__ClientSecret":"{{ tpl .Values.components.oauth.clients.flows.client_secret . }}"}` | Secret stringData content. Helm template enabled. |
| components.flows.secrets.psql.secretRef | string | `nil` | Existing secret reference |
| components.flows.secrets.psql.enabled | string | `"{{ not (index .Values `components` `flows` `secrets` `psql` `secretRef`) }}"` | Enables or disables the Secret |
| components.flows.env.Logging__LogLevel__Default | string | `"{{ include \"defines.logging.loglevel.dotnet\" . }}"` | log level. Use `logLevel` value to set up |
| components.event-distribution-service.enabled | bool | `false` | Enable Event Distribution Service (both API and Processing components) |
| components.event-distribution-service-api.image.repository | string | `"{{tpl .Values.harmonize.repository.base .}}/eds-api-service"` | API Service image repository |
| components.event-distribution-service-api.secrets.psql.secretRef | string | `nil` | Existing secret reference |
| components.event-distribution-service-api.secrets.psql.enabled | string | `"{{ not (index .Values `components` `event-distribution-service-api` `secrets` `psql` `secretRef`) }}"` | Enables or disables the Secret |
| components.event-distribution-service-processing.image.repository | string | `"{{tpl .Values.harmonize.repository.base .}}/eds-event-processing"` | Processing Service image repository |
| components.event-distribution-service-processing.secrets.psql.secretRef | string | `nil` | Existing secret reference |
| components.event-distribution-service-processing.secrets.psql.enabled | string | `"{{ not (index .Values `components` `event-distribution-service-processing` `secrets` `psql` `secretRef`) }}"` | Enables or disables the Secret |
| components.event-distribution-service-processing.secrets.external-amqp.secretRef | string | `nil` | Existing secret reference |
| components.event-distribution-service-processing.secrets.external-amqp.enabled | string | `"{{ not (index .Values `components` `event-distribution-service-processing` `secrets` `external-amqp` `secretRef`) }}"` | Enables or disables the Secret   |
| components.virtual-accounting.image.repository | string | <harmonize.repository.base>/virtual-accounting | image repository |
| components.virtual-accounting.image.tag | string | `"1.9.15"` | image tag |
| components.virtual-accounting.secrets.private-key.secretRef | string | `nil` | Existing secret reference |
| components.virtual-accounting.secrets.private-key.enabled | string | `"{{ not (index .Values `components` `virtual-accounting` `secrets` `private-key` `secretRef`) }}"` | Enables or disables the Secret |
| components.virtual-accounting.secrets.private-key.stringData | object | `{"Harmonize__PrivateKey":"yourPrivateKey"}` | Secret stringData content. Helm template enabled. |
| components.virtual-accounting.secrets.oidc-credentials.secretRef | string | `nil` | Existing secret reference |
| components.virtual-accounting.secrets.oidc-credentials.enabled | string | `"{{ not (index .Values `components` `virtual-accounting` `secrets` `oidc-credentials` `secretRef`) }}"` | Enables or disables the Secret |
| components.virtual-accounting.secrets.oidc-credentials.stringData | object | `{"Harmonize__OIDC__ClientId":"{{ tpl .Values.components.oauth.clients.virtual_accounting.client_id . }}","Harmonize__OIDC__ClientSecret":"{{ tpl .Values.components.oauth.clients.virtual_accounting.client_secret . }}"}` | Secret stringData content. Helm template enabled. |
| components.virtual-accounting.secrets.psql.secretRef | string | `nil` | Existing secret reference |
| components.virtual-accounting.secrets.psql.enabled | string | `"{{ not (index .Values `components` `virtual-accounting` `secrets` `psql` `secretRef`) }}"` | Enables or disables the Secret |
| components.virtual-accounting.env.Logging__LogLevel__Default | string | `"{{ include \"defines.logging.loglevel.dotnet\" . }}"` | log level. Use `logLevel` value to set up |
| components.coinbase-adapter.image.repository | string | <harmonize.repository.base>/coinbase-adapter | image repository |
| components.coinbase-adapter.image.tag | string | `"1.4.5"` | image tag |
| components.coinbase-adapter.image.kmsconnect.repository | string | `"{{tpl .Values.harmonize.repository.base .}}/{{ replace \"_\" \"-\" .Values.platform }}"` | kms connect sidecar image repository |
| components.coinbase-adapter.image.kmsconnect.tag | string | `"1.9.15"` | image tag |
| components.coinbase-adapter.logging.logLevel | string | `<harmonize.logging.log>` | log Level |
| components.coinbase-adapter.secrets.psql.secretRef | string | `nil` | Existing secret reference |
| components.coinbase-adapter.secrets.psql.enabled | string | `"{{ not (index .Values `components` `coinbase-adapter` `secrets` `psql` `secretRef`) }}"` | Enables or disables the Secret |
| components.coinbase-adapter.secrets.access-secrets.secretRef | string | `nil` | Existing secret reference |
| components.coinbase-adapter.secrets.access-secrets.enabled | string | `"{{ not (index .Values `components` `coinbase-adapter` `secrets` `access-secrets` `secretRef`) }}"` | Enables or disables the Secret |
| components.coinbase-adapter.ingress.main | object | See values.yaml | Enable and configure ingress settings for the chart under this key. |
| components.eod-reconciliation.image.repository | string | <harmonize.repository.base>/eod-reconciliation | image repository |
| components.eod-reconciliation.image.tag | string | `"1.4.5"` | image tag |
| components.eod-reconciliation.logging.logLevel | string | `<harmonize.logging.log>` | log Level |
| components.eod-reconciliation.secrets.psql.secretRef | string | `nil` | Existing secret reference |
| components.eod-reconciliation.secrets.psql.enabled | string | `"{{ not (index .Values `components` `eod-reconciliation` `secrets` `psql` `secretRef`) }}"` | Enables or disables the Secret |
| components.eod-reconciliation.secrets.access-secrets.secretRef | string | `nil` | Existing secret reference |
| components.eod-reconciliation.secrets.access-secrets.enabled | string | `"{{ not (index .Values `components` `eod-reconciliation` `secrets` `access-secrets` `secretRef`) }}"` | Enables or disables the Secret |
| components.eod-reconciliation.ingress.main | object | See values.yaml | Enable and configure ingress settings for the chart under this key. |
| indexers.nbxplorer.image.repository | string | <harmonize.repository.base>/nbxplorer | image repository |
| indexers.nbxplorer.image.tag | string | `"6.2.10"` | image tag |
| indexers.nbxplorer.indexation_log_level | string | `"{{ include \"defines.logging.loglevel.apps\" . }}"` |  |
| indexers.nbxplorer.configMaps.httpProxy.enabled | string | `"{{ has \"nbxplorer\" $.Values.harmonize.httpProxy.indexers }}"` |  |
| indexers.nbxplorer.configMaps.httpProxy.data.HTTP_PROXY | string | `"{{ include \"harmonize.defines.http_proxy_uris.nbxplorer\" . }}"` |  |
| indexers.nbxplorer.configMaps.httpProxy.data.HTTPS_PROXY | string | `"{{ include \"harmonize.defines.http_proxy_uris.nbxplorer\" . }}"` |  |
| indexers.nbxplorer.secrets.psql.secretRef | string | `nil` | Existing secret reference |
| indexers.nbxplorer.secrets.psql.enabled | string | `"{{ not (index .Values `indexers` `nbxplorer` `secrets` `psql` `secretRef`) }}"` | Enables or disables the Secret |
| indexers.nbxplorer.secrets.psql.stringData.NBXPLORER_POSTGRES | string | `"{{ include \"harmonize.defines.uris.dotnet\" (list . (printf \"nbxplorer-btx-%s\" .Network_Name)) }}"` |  |
| indexers.nbxplorer.secrets.passwords.secretRef | string | `nil` | Existing secret reference |
| indexers.nbxplorer.secrets.passwords.enabled | string | `"{{ not (index .Values `indexers` `nbxplorer` `secrets` `passwords` `secretRef`) }}"` | Enables or disables the Secret |
| indexers.nbxplorer.secrets.passwords.stringData | object | `{}` |  |
| indexers.nbxplorer.resources.limits.memory | string | `"1536Mi"` |  |
| indexers.nbxplorer.resources.limits.cpu | string | `"1000m"` |  |
| indexers.nbxplorer.resources.requests.cpu | string | `"{{ .Values.harmonize.resources.set_requests_with_limit_values.cpu | ternary (.Values.resources.limits.cpu) `500m` }}"` |  |
| indexers.nbxplorer.resources.requests.memory | string | `"{{ .Values.harmonize.resources.set_requests_with_limit_values.memory | ternary (.Values.resources.limits.memory) `512Mi` }}"` |  |
| indexers.nbxplorer.env.Logging__LogLevel__Default | string | `"{{ include \"defines.logging.loglevel.dotnet\" . }}"` |  |
| indexers.nbxplorer.env.NBXPLORER_NETWORK | string | `"{{ .Network_Name }}"` |  |
| indexers.nbxplorer.env.NBXPLORER_BIND | string | `"{{ printf \"0.0.0.0:%s\" (toString .Values.service.main.ports.http.targetPort) }}"` |  |
| indexers.nbxplorer.env.NBXPLORER_NOAUTH | string | `"1"` |  |
| indexers.nbxplorer.env.NBXPLORER_DATADIR | string | `"{{ index .Values.persistence `nbx-datadir` `mountPath` }}"` |  |
| indexers.nbxplorer.service.main.ports.http.port | int | `80` |  |
| indexers.nbxplorer.service.main.ports.http.targetPort | int | `32838` |  |
| indexers.nbxplorer.probes.liveness.enabled | bool | `false` |  |
| indexers.nbxplorer.probes.startup.enabled | bool | `false` |  |
| indexers.nbxplorer.probes.readiness.initialDelaySeconds | int | `150` |  |
| indexers.nbxplorer.probes.readiness.timeoutSeconds | int | `60` |  |
| indexers.nbxplorer.probes.readiness.type | string | `"HTTP"` |  |
| indexers.nbxplorer.probes.readiness.path | string | `"/health"` |  |
| indexers.nbxplorer.persistence.nbx-datadir.enabled | bool | `true` |  |
| indexers.nbxplorer.persistence.nbx-datadir.type | string | `"emptyDir"` |  |
| indexers.nbxplorer.persistence.nbx-datadir.mountPath | string | `"/opt/app-root/data"` |  |
| indexers.ethindexer.image.repository | string | <harmonize.repository.base>/eth-indexer | image repository |
| indexers.ethindexer.image.tag | string | `"4.8.10"` | image tag |
| indexers.ethindexer.configMaps.httpProxy.enabled | string | `"{{ has \"ethindexer\" $.Values.harmonize.httpProxy.indexers }}"` |  |
| indexers.ethindexer.configMaps.httpProxy.data.HTTP_PROXY | string | `"{{ include \"harmonize.defines.http_proxy_uris.nbxplorer\" . }}"` |  |
| indexers.ethindexer.configMaps.httpProxy.data.HTTPS_PROXY | string | `"{{ include \"harmonize.defines.http_proxy_uris.nbxplorer\" . }}"` |  |
| indexers.ethindexer.secrets.psql.secretRef | string | `nil` | Existing secret reference |
| indexers.ethindexer.secrets.psql.enabled | string | `"{{ not (index .Values `indexers` `ethindexer` `secrets` `psql` `secretRef`) }}"` | Enables or disables the Secret |
| indexers.ethindexer.secrets.psql.stringData.POSTGRES_URL | string | `"{{ include \"harmonize.defines.uris.jdbc\" (list . (printf \"eth-indexer-%s-%s\" .Ledger_Name .Network_Name)) }}"` |  |
| indexers.ethindexer.resources.limits.memory | string | `"512Mi"` |  |
| indexers.ethindexer.resources.limits.cpu | string | `"500m"` |  |
| indexers.ethindexer.resources.requests.cpu | string | `"{{ .Values.harmonize.resources.set_requests_with_limit_values.cpu | ternary (.Values.resources.limits.cpu) `10m` }}"` |  |
| indexers.ethindexer.resources.requests.memory | string | `"{{ .Values.harmonize.resources.set_requests_with_limit_values.memory | ternary (.Values.resources.limits.memory) `384Mi` }}"` |  |
| indexers.ethindexer.service.main.ports.http.port | int | `80` |  |
| indexers.ethindexer.service.main.ports.http.targetPort | int | `3001` |  |
| indexers.ethindexer.service.main.ports.healthcheck.enabled | bool | `true` |  |
| indexers.ethindexer.service.main.ports.healthcheck.port | int | `3021` |  |
| indexers.ethindexer.service.main.ports.healthcheck.targetPort | int | `3021` |  |
| indexers.ethindexer.env.ETH_INDEXER_LOG_LEVEL | string | `"{{ include \"defines.logging.loglevel.apps\" . }}"` |  |
| indexers.ethindexer.env.ETH_INDEXER_INDEXATION_LOG_LEVEL | string | `"{{ include \"defines.logging.loglevel.apps\" . }}"` |  |
| indexers.ethindexer.env.ETH_INDEXER_NODE_TYPE | string | `"{{ .Network.type | default \"Geth\" }}"` |  |
| indexers.ethindexer.env.ETH_INDEXER_NODE_URI | string | `"{{ .Network.uri }}"` |  |
| indexers.ethindexer.env.ETH_INDEXER_NODE_ACCEPTABLE_NB_BLOCKS_NOT_YET_INDEXED | string | `"40"` |  |
| indexers.ethindexer.env.ETH_INDEXER_HTTPS_ENABLED | string | `"false"` |  |
| indexers.ethindexer.env.POSTGRES_AUTO_MIGRATE | string | `"true"` |  |
| indexers.ethindexer.env.ETH_INDEXER_MONITOR_BLOCKS_REORGANIZATION | bool | `false` |  |
| indexers.ethindexer.probes.liveness.type | string | `"HTTP"` |  |
| indexers.ethindexer.probes.liveness.port | string | `"healthcheck"` |  |
| indexers.ethindexer.probes.liveness.path | string | `"/node/alive"` |  |
| indexers.ethindexer.probes.startup.enabled | bool | `false` |  |
| indexers.ethindexer.probes.readiness.type | string | `"HTTP"` |  |
| indexers.ethindexer.probes.readiness.port | string | `"healthcheck"` |  |
| indexers.ethindexer.probes.readiness.path | string | `"/node/ready"` |  |
| indexers.xrplindexer.image.repository | string | <harmonize.repository.base>/xrp-indexer | image repository |
| indexers.xrplindexer.image.tag | string | `"4.2.2"` | image tag |
| indexers.xrplindexer.configMaps.httpProxy.enabled | string | `"{{ has \"xrplindexer\" $.Values.harmonize.httpProxy.indexers }}"` |  |
| indexers.xrplindexer.configMaps.httpProxy.data.HTTP_PROXY | string | `"{{ include \"harmonize.defines.http_proxy_uris.nbxplorer\" . }}"` |  |
| indexers.xrplindexer.configMaps.httpProxy.data.HTTPS_PROXY | string | `"{{ include \"harmonize.defines.http_proxy_uris.nbxplorer\" . }}"` |  |
| indexers.xrplindexer.secrets.psql.secretRef | string | `nil` | Existing secret reference |
| indexers.xrplindexer.secrets.psql.enabled | string | `"{{ not (index .Values `indexers` `xrplindexer` `secrets` `psql` `secretRef`) }}"` | Enables or disables the Secret |
| indexers.xrplindexer.secrets.psql.stringData.POSTGRES_URL | string | `"{{ include \"harmonize.defines.uris.jdbc\" (list . (printf \"xrpl-indexer-%s-%s\" .Ledger_Name .Network_Name)) }}"` |  |
| indexers.xrplindexer.resources.limits.memory | string | `"512Mi"` |  |
| indexers.xrplindexer.resources.limits.cpu | string | `"500m"` |  |
| indexers.xrplindexer.resources.requests.cpu | string | `"{{ .Values.harmonize.resources.set_requests_with_limit_values.cpu | ternary (.Values.resources.limits.cpu) `10m` }}"` |  |
| indexers.xrplindexer.resources.requests.memory | string | `"{{ .Values.harmonize.resources.set_requests_with_limit_values.memory | ternary (.Values.resources.limits.memory) `384Mi` }}"` |  |
| indexers.xrplindexer.service.main.ports.http.port | int | `80` |  |
| indexers.xrplindexer.service.main.ports.http.targetPort | int | `3005` |  |
| indexers.xrplindexer.service.main.ports.healthcheck.enabled | bool | `true` |  |
| indexers.xrplindexer.service.main.ports.healthcheck.port | int | `3025` |  |
| indexers.xrplindexer.service.main.ports.healthcheck.targetPort | int | `3025` |  |
| indexers.xrplindexer.env.XRP_INDEXER_LOG_LEVEL | string | `"{{ include \"defines.logging.loglevel\" . }}"` |  |
| indexers.xrplindexer.env.XRP_INDEXER_INDEXATION_LOG_LEVEL | string | `"{{ include \"defines.logging.loglevel\" . }}"` |  |
| indexers.xrplindexer.env.XRP_INDEXER_SERVER_URI | string | `"{{ .Network.uri }}"` |  |
| indexers.xrplindexer.env.POSTGRES_AUTO_MIGRATE | bool | `true` |  |
| indexers.xrplindexer.probes.liveness.type | string | `"HTTP"` |  |
| indexers.xrplindexer.probes.liveness.port | string | `"healthcheck"` |  |
| indexers.xrplindexer.probes.liveness.path | string | `"/node/alive"` |  |
| indexers.xrplindexer.probes.liveness.initialDelaySeconds | int | `40` |  |
| indexers.xrplindexer.probes.startup.enabled | bool | `false` |  |
| indexers.xrplindexer.probes.readiness.type | string | `"HTTP"` |  |
| indexers.xrplindexer.probes.readiness.port | string | `"healthcheck"` |  |
| indexers.xrplindexer.probes.readiness.path | string | `"/node/ready"` |  |
| indexers.xrplindexer.probes.readiness.initialDelaySeconds | int | `30` |  |
| indexers.xtzindexer.image.repository | string | <harmonize.repository.base>/tezos-indexer | image repository |
| indexers.xtzindexer.image.tag | string | `"2.4.3"` | image tag |
| indexers.xtzindexer.secrets.psql.secretRef | string | `nil` | Existing secret reference |
| indexers.xtzindexer.secrets.psql.enabled | string | `"{{ not (index .Values `indexers` `xtzindexer` `secrets` `psql` `secretRef`) }}"` | Enables or disables the Secret |
| indexers.xtzindexer.secrets.psql.stringData.POSTGRES_URL | string | `"{{ include \"harmonize.defines.uris.jdbc\" (list . (printf \"tezos-indexer-%s-%s\" .Ledger_Name .Network_Name)) }}"` |  |
| indexers.xtzindexer.resources.limits.memory | string | `"384Mi"` |  |
| indexers.xtzindexer.resources.limits.cpu | string | `"500m"` |  |
| indexers.xtzindexer.resources.requests.cpu | string | `"{{ .Values.harmonize.resources.set_requests_with_limit_values.cpu | ternary (.Values.resources.limits.cpu) `100m` }}"` |  |
| indexers.xtzindexer.resources.requests.memory | string | `"{{ .Values.harmonize.resources.set_requests_with_limit_values.memory | ternary (.Values.resources.limits.memory) `384Mi` }}"` |  |
| indexers.xtzindexer.service.main.ports.http.port | int | `80` |  |
| indexers.xtzindexer.service.main.ports.http.targetPort | int | `3001` |  |
| indexers.xtzindexer.service.main.ports.healthcheck.enabled | bool | `true` |  |
| indexers.xtzindexer.service.main.ports.healthcheck.port | int | `3021` |  |
| indexers.xtzindexer.service.main.ports.healthcheck.targetPort | int | `3021` |  |
| indexers.xtzindexer.env.TEZOS_INDEXER_LOG_LEVEL | string | `"{{ include \"defines.logging.loglevel\" . }}"` |  |
| indexers.xtzindexer.env.TEZOS_INDEXER_INDEXATION_LOG_LEVEL | string | `"{{ include \"defines.logging.loglevel\" . }}"` |  |
| indexers.xtzindexer.env.TEZOS_INDEXER_NODE_URI | string | `"{{ .Network.uri }}"` |  |
| indexers.xtzindexer.env.POSTGRES_AUTO_MIGRATE | bool | `true` |  |
| indexers.xtzindexer.probes.liveness.type | string | `"HTTP"` |  |
| indexers.xtzindexer.probes.liveness.port | string | `"healthcheck"` |  |
| indexers.xtzindexer.probes.liveness.path | string | `"/node/alive"` |  |
| indexers.xtzindexer.probes.startup.enabled | bool | `false` |  |
| indexers.xtzindexer.probes.readiness.type | string | `"HTTP"` |  |
| indexers.xtzindexer.probes.readiness.port | string | `"healthcheck"` |  |
| indexers.xtzindexer.probes.readiness.path | string | `"/node/ready"` |  |
| indexers.substrate-indexer.image.repository | string | <harmonize.repository.base>/substrate-indexer | image repository |
| indexers.substrate-indexer.image.tag | string | `"1.3.2"` | image tag |
| indexers.substrate-indexer.secrets.psql.secretRef | string | `nil` | Existing secret reference |
| indexers.substrate-indexer.secrets.psql.enabled | string | `"{{ not (index .Values `indexers` `substrate-indexer` `secrets` `psql` `secretRef`) }}"` | Enables or disables the Secret |
| indexers.substrate-indexer.secrets.psql.stringData.POSTGRES | string | `"{{ include \"harmonize.defines.uris.dotnet\" (list . (printf \"substrate-indexer-%s\" .Network_Name)) }}"` |  |
| indexers.substrate-indexer.resources.limits.memory | string | `"256Mi"` |  |
| indexers.substrate-indexer.resources.limits.cpu | string | `"500m"` |  |
| indexers.substrate-indexer.resources.requests.cpu | string | `"{{ .Values.harmonize.resources.set_requests_with_limit_values.cpu | ternary (.Values.resources.limits.cpu) `100m` }}"` |  |
| indexers.substrate-indexer.resources.requests.memory | string | `"{{ .Values.harmonize.resources.set_requests_with_limit_values.memory | ternary (.Values.resources.limits.memory) `128Mi` }}"` |  |
| indexers.substrate-indexer.service.main.ports.http.port | int | `80` |  |
| indexers.substrate-indexer.service.main.ports.http.targetPort | int | `3000` |  |
| indexers.substrate-indexer.env.LOGREQUESTS | string | `"{{ ternary \"true\" \"false\" (eq ((include \"defines.logging.loglevel\" .)) \"TRACE\") }}"` |  |
| indexers.substrate-indexer.env.VERBOSE | string | `"{{ ternary \"true\" \"false\" (eq ((include \"defines.logging.loglevel\" .)) \"TRACE\") }}"` |  |
| indexers.substrate-indexer.env.ASPNETCORE_URLS | string | `"http://+:3000"` |  |
| indexers.substrate-indexer.env.NETWORK | string | `"{{ .Network_Name }}"` |  |
| indexers.substrate-indexer.env.WS_URL | string | `"{{ .Network.ws }}"` |  |
| indexers.substrate-indexer.env.SIDECAR_URL | string | `"{{ .Network.sidecar }}"` |  |
| indexers.substrate-indexer.probes.liveness.type | string | `"HTTP"` |  |
| indexers.substrate-indexer.probes.liveness.port | string | `"http"` |  |
| indexers.substrate-indexer.probes.liveness.path | string | `"/health"` |  |
| indexers.substrate-indexer.probes.startup.enabled | bool | `false` |  |
| indexers.substrate-indexer.probes.readiness.type | string | `"HTTP"` |  |
| indexers.substrate-indexer.probes.readiness.port | string | `"http"` |  |
| indexers.substrate-indexer.probes.readiness.path | string | `"/health"` |  |
| indexers.stellar-indexer.image.repository | string | <harmonize.repository.base>/stellar-indexer | image repository |
| indexers.stellar-indexer.image.tag | string | `"0.3.1"` | image tag |
| indexers.stellar-indexer.secrets.psql.secretRef | string | `nil` | Existing secret reference |
| indexers.stellar-indexer.secrets.psql.enabled | string | `"{{ not (index .Values `indexers` `stellar-indexer` `secrets` `psql` `secretRef`) }}"` | Enables or disables the Secret |
| indexers.stellar-indexer.secrets.psql.stringData.ConnectionStrings__postgres | string | `"{{ include \"harmonize.defines.uris.dotnet\" (list . (printf \"stellar-indexer-xlm-%s\" .Network_Name)) }}"` |  |
| indexers.stellar-indexer.resources.limits.memory | string | `"256Mi"` |  |
| indexers.stellar-indexer.resources.limits.cpu | string | `"500m"` |  |
| indexers.stellar-indexer.resources.requests.cpu | string | `"{{ .Values.harmonize.resources.set_requests_with_limit_values.cpu | ternary (.Values.resources.limits.cpu) `100m` }}"` |  |
| indexers.stellar-indexer.resources.requests.memory | string | `"{{ .Values.harmonize.resources.set_requests_with_limit_values.memory | ternary (.Values.resources.limits.memory) `128Mi` }}"` |  |
| indexers.stellar-indexer.env.Logging__LogLevel__Default | string | `"{{ include \"defines.logging.loglevel.dotnet\" . }}"` |  |
| indexers.stellar-indexer.env.Stellar__LedgerHistory | string | `"AppEpoch"` |  |
| indexers.stellar-indexer.env.Stellar__NetworkPassPhrase | string | `"{{ .Network.passphrase }}"` |  |
| indexers.stellar-indexer.env.Stellar__Url | string | `"{{ .Network.url }}"` |  |
| indexers.stellar-indexer.service.main.ports.http.port | int | `80` |  |
| indexers.stellar-indexer.service.main.ports.http.targetPort | int | `8080` |  |
| indexers.stellar-indexer.probes.liveness.enabled | bool | `false` |  |
| indexers.stellar-indexer.probes.startup.enabled | bool | `false` |  |
| indexers.stellar-indexer.probes.readiness.initialDelaySeconds | int | `150` |  |
| indexers.stellar-indexer.probes.readiness.timeoutSeconds | int | `60` |  |
| indexers.stellar-indexer.probes.readiness.type | string | `"HTTP"` |  |
| indexers.stellar-indexer.probes.readiness.path | string | `"/health"` |  |
| indexers.solana-indexer.image.repository | string | <harmonize.repository.base>/solana-indexer | image repository |
| indexers.solana-indexer.image.tag | string | `"0.4.2"` | image tag |
| indexers.solana-indexer.secrets.psql.secretRef | string | `nil` | Existing secret reference |
| indexers.solana-indexer.secrets.psql.enabled | string | `"{{ not (index .Values `indexers` `solana-indexer` `secrets` `psql` `secretRef`) }}"` | Enables or disables the Secret |
| indexers.solana-indexer.secrets.psql.stringData.POSTGRES | string | `"{{ include \"harmonize.defines.uris.dotnet\" (list . (printf \"solana-indexer-xlm-%s\" .Network_Name)) }}"` |  |
| indexers.solana-indexer.resources.limits.memory | string | `"256Mi"` |  |
| indexers.solana-indexer.resources.limits.cpu | string | `"500m"` |  |
| indexers.solana-indexer.resources.requests.cpu | string | `"{{ .Values.harmonize.resources.set_requests_with_limit_values.cpu | ternary (.Values.resources.limits.cpu) `100m` }}"` |  |
| indexers.solana-indexer.resources.requests.memory | string | `"{{ .Values.harmonize.resources.set_requests_with_limit_values.memory | ternary (.Values.resources.limits.memory) `128Mi` }}"` |  |
| indexers.solana-indexer.env.LOGREQUESTS | string | `"{{ ternary \"true\" \"false\" (eq (include \"defines.logging.loglevel\" .) \"TRACE\") }}"` |  |
| indexers.solana-indexer.env.VERBOSE | string | `"{{ ternary \"true\" \"false\" (eq (include \"defines.logging.loglevel\" .) \"TRACE\") }}"` |  |
| indexers.solana-indexer.env.ASPNETCORE_URLS | string | `"http://+:8080"` |  |
| indexers.solana-indexer.env.NETWORK | string | `"{{ .Network_Name }}"` |  |
| indexers.solana-indexer.env.SOLWSRPC | string | `"{{ .Network.ws }}"` |  |
| indexers.solana-indexer.env.SOLRPC | string | `"{{ .Network.http }}"` |  |
| indexers.solana-indexer.service.main.ports.http.port | int | `80` |  |
| indexers.solana-indexer.service.main.ports.http.targetPort | int | `8080` |  |
| indexers.solana-indexer.probes.liveness.enabled | bool | `false` |  |
| indexers.solana-indexer.probes.startup.enabled | bool | `false` |  |
| indexers.solana-indexer.probes.readiness.initialDelaySeconds | int | `150` |  |
| indexers.solana-indexer.probes.readiness.timeoutSeconds | int | `60` |  |
| indexers.solana-indexer.probes.readiness.type | string | `"HTTP"` |  |
| indexers.solana-indexer.probes.readiness.path | string | `"/health"` |  |
| indexers.cardano.image.repository | string | <harmonize.repository.base>/cardano-indexer | image repository |
| indexers.cardano.image.tag | string | `"0.4.2"` | image tag |
| indexers.cardano.secrets.psql.secretRef | string | `nil` | Existing secret reference |
| indexers.cardano.secrets.psql.enabled | string | `"{{ not (index .Values `indexers` `cardano` `secrets` `psql` `secretRef`) }}"` | Enables or disables the Secret |
| indexers.cardano.secrets.psql.stringData.POSTGRES | string | `"{{ include \"harmonize.defines.uris.dotnet\" (list . (printf \"cardano-indexer-xlm-%s\" .Network_Name)) }}"` |  |
| indexers.cardano.resources.limits.memory | string | `"256Mi"` |  |
| indexers.cardano.resources.limits.cpu | string | `"500m"` |  |
| indexers.cardano.resources.requests.cpu | string | `"{{ .Values.harmonize.resources.set_requests_with_limit_values.cpu | ternary (.Values.resources.limits.cpu) `100m` }}"` |  |
| indexers.cardano.resources.requests.memory | string | `"{{ .Values.harmonize.resources.set_requests_with_limit_values.memory | ternary (.Values.resources.limits.memory) `128Mi` }}"` |  |
| indexers.cardano.env.LOGREQUESTS | string | `"{{ ternary \"true\" \"false\" (eq (include \"defines.logging.loglevel\" .) \"TRACE\") }}"` |  |
| indexers.cardano.env.VERBOSE | string | `"{{ ternary \"true\" \"false\" (eq (include \"defines.logging.loglevel\" .) \"TRACE\") }}"` |  |
| indexers.cardano.env.ASPNETCORE_URLS | string | `"http://+:8080"` |  |
| indexers.cardano.env.NETWORK | string | `"{{ replace \"testnet-\" \"\" .Network_Name }}"` |  |
| indexers.cardano.env.OGMIOS | string | `"{{ .Network.ws }}"` |  |
| indexers.cardano.service.main.ports.http.port | int | `80` |  |
| indexers.cardano.service.main.ports.http.targetPort | int | `8080` |  |
| indexers.cardano.probes.liveness.enabled | bool | `false` |  |
| indexers.cardano.probes.startup.enabled | bool | `false` |  |
| indexers.cardano.probes.readiness.initialDelaySeconds | int | `150` |  |
| indexers.cardano.probes.readiness.timeoutSeconds | int | `60` |  |
| indexers.cardano.probes.readiness.type | string | `"HTTP"` |  |
| indexers.cardano.probes.readiness.path | string | `"/health"` |  |
| indexers.algorandindexer.image.repository | string | <harmonize.repository.base>/algorand-indexer | image repository |
| indexers.algorandindexer.image.tag | string | `"0.2.1"` | image tag |
| indexers.algorandindexer.secrets.psql.secretRef | string | `nil` | Existing secret reference |
| indexers.algorandindexer.secrets.psql.enabled | string | `"{{ not (index .Values `indexers` `algorandindexer` `secrets` `psql` `secretRef`) }}"` | Enables or disables the Secret |
| indexers.algorandindexer.secrets.psql.stringData.ConnectionStrings__postgres | string | `"{{ include \"harmonize.defines.uris.dotnet\" (list . \"\") }}"` |  |
| indexers.algorandindexer.resources.limits.memory | string | `"256Mi"` |  |
| indexers.algorandindexer.resources.limits.cpu | string | `"500m"` |  |
| indexers.algorandindexer.resources.requests.cpu | string | `"{{ .Values.harmonize.resources.set_requests_with_limit_values.cpu | ternary (.Values.resources.limits.cpu) `100m` }}"` |  |
| indexers.algorandindexer.resources.requests.memory | string | `"{{ .Values.harmonize.resources.set_requests_with_limit_values.memory | ternary (.Values.resources.limits.memory) `128Mi` }}"` |  |
| indexers.algorandindexer.env.LOGREQUESTS | string | `"{{ ternary \"true\" \"false\" (eq (include \"defines.logging.loglevel\" .) \"TRACE\") }}"` |  |
| indexers.algorandindexer.env.VERBOSE | string | `"{{ ternary \"true\" \"false\" (eq (include \"defines.logging.loglevel\" .) \"TRACE\") }}"` |  |
| indexers.algorandindexer.env.ASPNETCORE_URLS | string | `"http://+:8080"` |  |
| indexers.algorandindexer.env.NETWORK | string | `"{{ .Network_Name }}"` |  |
| indexers.algorandindexer.env.Algorand__Url | string | `"TBD"` |  |
| indexers.algorandindexer.env.Algorand__Authorization | string | `"TBD"` |  |
| indexers.algorandindexer.service.main.ports.http.port | int | `80` |  |
| indexers.algorandindexer.service.main.ports.http.targetPort | int | `8080` |  |
| indexers.algorandindexer.probes.liveness.enabled | bool | `false` |  |
| indexers.algorandindexer.probes.startup.enabled | bool | `false` |  |
| indexers.algorandindexer.probes.readiness.initialDelaySeconds | int | `150` |  |
| indexers.algorandindexer.probes.readiness.timeoutSeconds | int | `60` |  |
| indexers.algorandindexer.probes.readiness.type | string | `"HTTP"` |  |
| indexers.algorandindexer.probes.readiness.path | string | `"/health"` |  |
| indexers.hederaindexer.image.repository | string | <harmonize.repository.base>/hedera-indexer | image repository |
| indexers.hederaindexer.image.tag | string | `"0.3.4"` | image tag |
| indexers.hederaindexer.secrets.psql.secretRef | string | `nil` | Existing secret reference |
| indexers.hederaindexer.secrets.psql.enabled | string | `"{{ not (index .Values `indexers` `hederaindexer` `secrets` `psql` `secretRef`) }}"` | Enables or disables the Secret |
| indexers.hederaindexer.secrets.psql.stringData.ConnectionStrings__postgres | string | `"{{ include \"harmonize.defines.uris.dotnet\" (list . \"\") }}"` |  |
| indexers.hederaindexer.resources.limits.memory | string | `"256Mi"` |  |
| indexers.hederaindexer.resources.limits.cpu | string | `"500m"` |  |
| indexers.hederaindexer.resources.requests.cpu | string | `"{{ .Values.harmonize.resources.set_requests_with_limit_values.cpu | ternary (.Values.resources.limits.cpu) `100m` }}"` |  |
| indexers.hederaindexer.resources.requests.memory | string | `"{{ .Values.harmonize.resources.set_requests_with_limit_values.memory | ternary (.Values.resources.limits.memory) `128Mi` }}"` |  |
| indexers.hederaindexer.env.LOGREQUESTS | string | `"{{ ternary \"true\" \"false\" (eq (include \"defines.logging.loglevel\" .) \"TRACE\") }}"` |  |
| indexers.hederaindexer.env.VERBOSE | string | `"{{ ternary \"true\" \"false\" (eq (include \"defines.logging.loglevel\" .) \"TRACE\") }}"` |  |
| indexers.hederaindexer.env.ASPNETCORE_URLS | string | `"http://+:8080"` |  |
| indexers.hederaindexer.env.NETWORK | string | `"{{ .Network_Name }}"` |  |
| indexers.hederaindexer.env.ASPNETCORE_ENVIRONMENT | string | `""` |  |
| indexers.hederaindexer.env.Hedera__MirrorNodeUrl | string | `"{{ .Network.http }}"` |  |
| indexers.hederaindexer.env.Hedera__ConsensusNodeIpPort | string | `""` |  |
| indexers.hederaindexer.env.Hedera__ConsensusNodeId | string | `""` |  |
| indexers.hederaindexer.env.Hedera__PredefinedFee | string | `""` |  |
| indexers.hederaindexer.service.main.ports.http.port | int | `80` |  |
| indexers.hederaindexer.service.main.ports.http.targetPort | int | `8080` |  |
| indexers.hederaindexer.probes.liveness.enabled | bool | `false` |  |
| indexers.hederaindexer.probes.startup.enabled | bool | `false` |  |
| indexers.hederaindexer.probes.readiness.initialDelaySeconds | int | `150` |  |
| indexers.hederaindexer.probes.readiness.timeoutSeconds | int | `60` |  |
| indexers.hederaindexer.probes.readiness.type | string | `"HTTP"` |  |
| indexers.hederaindexer.probes.readiness.path | string | `"/health"` |  |
| vault.image.repository | string | <harmonize.repository.base>/vault-releases | image repository |
| vault.image.tag | string | `"1.27.4"` | image tag |
| vault.image.kmsconnect.repository | string | `"{{tpl .Values.harmonize.repository.base .}}/{{ replace \"_\" \"-\" .Values.platform }}"` | kms connect sidecar image repository |
| vault.image.kmsconnect.tag | string | `"1.9.15"` | image tag |
| vault.env.HMZ_FEATURE_OTLP_IN_STDOUT | string | `"{{ index .Values `opentelemetry-collector` `enabled` | toString}}"` |  |
| vault.env.PLATFORM | string | `"{{ contains \"kms_\" .Values.platform  | ternary \"kms\" .Values.platform }}"` |  |
| vault.env.VAULT_LOGLEVEL | string | `"{{ include \"defines.logging.loglevel.vault\" . }}"` |  |
| vault.env.VAULT_BRIDGE_LOGLEVEL | string | `"{{ include \"defines.logging.loglevel.vault\" . }}"` |  |
| vault.env.VAULT_ID | string | `"{{ .Values.vault_id }}"` |  |
| vault.env.VAULT_CORE_ADDRESS | string | `"localhost:10054"` |  |
| vault.env.HARMONIZE_CORE_ENDPOINT | string | `"{{ include \"harmonize.components.gateway.url.internal\" . }}/internal/v1"` |  |
| vault.env.VAULT_TRUSTED_SIG | string | `"{{ .Values.notary_public_key }}"` |  |
| vault.envFrom[0].configMapRef.name | string | `"{{ include \"harmonize.telemetry-config.open-telemetry-sdk-grpc\" . }}"` |  |
| vault.envFrom[0].configMapRef.optional | bool | `true` |  |
| vault.envFrom[1].configMapRef.name | string | `"{{ include \"harmonize.telemetry-config.syslog.configmap_name\" . }}"` |  |
| vault.envFrom[1].configMapRef.optional | bool | `true` |  |
| vault.envFrom[2].configMapRef.name | string | `"{{ include \"harmonize.features.configmap_name\" . }}"` |  |
| vault.envFrom[2].configMapRef.optional | bool | `true` |  |
| vault.configMaps.luna.enabled | string | `"{{ eq .Values.platform \"luna\"  }}"` |  |
| vault.configMaps.luna.data.VAULT_LUNA_HOST | string | `"{{ .Values.luna.host  }}"` |  |
| vault.configMaps.luna.data.VAULT_LUNA_PORT | string | `"{{ .Values.luna.port }}"` |  |
| vault.configMaps.andro.enabled | string | `"{{ eq .Values.platform \"andro\"  }}"` |  |
| vault.configMaps.andro.data.VAULT_ANDRO_SEED | string | `"{{ .Values.andro.seed }}"` |  |
| vault.configMaps.mock.enabled | string | `"{{ eq .Values.platform \"mock\"  }}"` |  |
| vault.configMaps.mock.data.VAULT_MOCK_PHRASE | string | `"{{ .Release.Name }}"` |  |
| vault.configMaps.kms.enabled | string | `"{{ contains \"kms_\" .Values.platform   }}"` |  |
| vault.configMaps.kms.data.VAULT_KMS_ENDPOINT | string | `"localhost:10000"` |  |
| vault.secrets.config.secretRef | string | `nil` | Existing secret reference |
| vault.secrets.config.enabled | string | `"{{ not (index .Values `vault` `secrets` `config` `secretRef`) }}"` | Enables or disables the Secret |
| vault.secrets.config.stringData."clientKey.pem" | string | `"{{ eq .Values.platform \"luna\" | ternary .Values.luna.client.key  \"\" }}"` |  |
| vault.secrets.config.stringData."client.pem" | string | `"{{ eq .Values.platform \"luna\" | ternary .Values.luna.client.cert \"\" }}"` |  |
| vault.secrets.config.stringData."server.pem" | string | `"{{ eq .Values.platform \"luna\" | ternary .Values.luna.server.cert \"\" }}"` |  |
| vault.secrets.secretsibm.secretRef | string | `nil` | Existing secret reference |
| vault.secrets.secretsibm.enabled | string | `"{{ eq .Values.platform \"ibm\"  }}"` | Enables or disables the Secret |
| vault.secrets.secretsibm.stringData."secrets.json" | string | `"{{ .Values.ibm.hpcssecrets  }}"` |  |
| vault.persistence.config.enabled | string | `"{{ eq .Values.platform \"luna\"  }}"` |  |
| vault.persistence.config.name | string | `"{{ printf \"%s-config\" ( include \"bjw-s.common.lib.chart.names.fullname\" . ) }}"` |  |
| vault.persistence.config.type | string | `"secret"` |  |
| vault.persistence.config.mountPath | string | `"/opt/vault-core/cfg/luna"` |  |
| vault.persistence.temp.enabled | bool | `true` |  |
| vault.persistence.temp.mountPath | string | `"/tmp"` |  |
| vault.persistence.temp.size | string | `"200Mi"` |  |
| vault.persistence.temp.type | string | `"emptyDir"` |  |
| vault.probes.liveness.enabled | bool | `false` |  |
| vault.probes.readiness.enabled | bool | `false` |  |
| vault.probes.startup.custom | bool | `true` |  |
| vault.probes.startup.spec.exec.command[0] | string | `"pgrep"` |  |
| vault.probes.startup.spec.exec.command[1] | string | `"supervisord"` |  |
| vault.probes.startup.spec.failureThreshold | int | `10` |  |
| vault.probes.startup.spec.periodSeconds | int | `3` |  |
| vault.resources.limits.cpu | string | `"200m"` |  |
| vault.resources.limits.memory | string | `"64Mi"` |  |
| vault.resources.requests.cpu | string | `"{{ .Values.harmonize.resources.set_requests_with_limit_values.cpu | ternary (.Values.resources.limits.cpu) `20m` }}"` |  |
| vault.resources.requests.memory | string | `"{{ .Values.harmonize.resources.set_requests_with_limit_values.memory | ternary (.Values.resources.limits.memory) `32Mi` }}"` |  |
| vault.logging.logLevel | string | `<harmonize.logging.log>` | log Level |
| vault.service.main.enabled | bool | `false` |  |
| mpc.node.image.repository | string | <harmonize.repository.base>/mpc-core | image repository |
| mpc.node.image.tag | string | `"1.3.12"` | image tag |
| mpc.node.image.kmsconnect.repository | string | `"{{tpl .Values.harmonize.repository.base .}}/{{ replace \"_\" \"-\" .Values.platform }}"` | kms connect sidecar image repository |
| mpc.node.image.kmsconnect.tag | string | `"1.4.6"` | image tag |
| mpc.node.env.RUST_LOG | string | `"{{ include \"defines.logging.loglevel.apps\" . }}"` |  |
| mpc.node.persistence.config.enabled | bool | `true` | Enable configmap with MPC Config |
| mpc.node.persistence.config.name | string | `"{{ printf \"%s-config\" ( include \"bjw-s.common.lib.chart.names.fullname\" . ) }}"` |  |
| mpc.node.persistence.config.type | string | `"configMap"` |  |
| mpc.node.persistence.config.mountPath | string | `"/app/config.json"` |  |
| mpc.node.persistence.config.subPath | string | `"config.json"` |  |
| mpc.node.configMaps.config.enabled | bool | `true` | Enables or disables the configMap |
| mpc.node.configMaps.config.data | object | `{"config.json":"{\n  {{- if $.Values.harmonize.mpc.relay.enable }}\n  \"relay\": {\n      \"peer_id\": \"{{ printf \"/dns4/%s/tcp/%d/p2p/%s\" (printf \"%s-%s-%s\" $.Release.Name $.Chart.Name $.Values.harmonize.mpc.relay.name) (int $.Values.harmonize.mpc.relay.port) $.Values.harmonize.mpc.relay.public_key }}\"\n  },\n  {{- end }}\n  \"nodes\": [\n    {\n      \"peer_id\": \"{{ printf \"/ip4/%s/tcp/%s/p2p/%s\" \"0.0.0.0\" \"6000\" .Values.public_key }}\",\n      \"own\": true,\n      \"can_initiate\": {{ if eq .Values.node_name \"index-0\" }}true{{ else }}false{{ end }}\n    }\n    {{- range $i, $node := $.Values.harmonize.mpc.nodes }}\n    {{- if ne $node.name $.Values.node_name }}\n    ,{\n      \"peer_id\": \"{{ printf \"/dns4/%s/tcp/%s/p2p/%s\" (printf \"%s-%s-mpc-node-%s\" $.Release.Name $.Chart.Name $node.name) \"6000\" $node.public_key }}\",\n      \"own\": false,\n      \"can_initiate\": {{ if eq $node.name \"index-0\" }}true{{ else }}false{{ end }}\n    }\n    {{- end }}\n    {{- end }}\n  ],\n  \"http_port\": 8888,\n  \"kek_provider\":  {\n    \"KMS\": {\n      \"url\": \"http://localhost:10000\",\n      \"timeout_ms\": 500\n    }\n  }\n}\n"}` | configMap data content. Helm template enabled. |
| mpc.node.volumeMounts[0].mountPath | string | `"/app/config.json"` |  |
| mpc.node.volumeMounts[0].subPath | string | `"config.json"` |  |
| mpc.node.volumeMounts[0].readOnly | bool | `false` |  |
| mpc.node.secrets.key-pair.enabled | bool | `true` | Enables or disables the Secret |
| mpc.node.secrets.key-pair.stringData | object | `{"NOISE_ID":"{{ .Values.key_pair }}"}` | Secret stringData content. Helm template enabled. |
| mpc.node.service.main.ports.http.port | int | `8888` |  |
| mpc.node.service.main.ports.http.targetPort | int | `8888` |  |
| mpc.node.service.main.ports.p2p.enable | bool | `true` |  |
| mpc.node.service.main.ports.p2p.port | int | `6000` |  |
| mpc.node.service.main.ports.p2p.targetPort | int | `6000` |  |
| mpc.node.resources.requests.memory | string | `"128Mi"` |  |
| mpc.node.resources.requests.cpu | string | `"200m"` |  |
| mpc.node.securityContext.readOnlyRootFilesystem | bool | `false` |  |
| mpc.node.platform | string | `"mock"` | Type of KMS platform to use Depending on what you select you need to fill one of the sections bellow as well Possible values: software_legacy \| andromeda \| software \| luna \| kms-blocksafe \| kms-andromeda \| kms_mock \| kms_soft \| kms_luna |
| mpc.node.kms_mock | object | See values.yaml | Configure kms_mock if platform is set as kms_mock |
| mpc.node.kms_mock.phrase | string | `nil` | kms_mock phrase |
| mpc.node.kms_mock.norandom | bool | `false` | kms_mock noRandom |
| mpc.node.kms_soft | object | See values.yaml | Configure kms_soft if platform is set as kms_soft |
| mpc.node.kms_soft.master | string | `nil` | kms_soft master key |
| mpc.node.kms_soft.kms_rewrapping_key | string | `nil` | Optional: kms_soft rewrapping key |
| mpc.node.kms_soft.gcp_json | string | `nil` | Optional: gcp credentials in case the kms_rewrapping_key is set and it starts with "gcp:" |
| mpc.relay.image.repository | string | <harmonize.repository.base>/mpc-core | image repository |
| mpc.relay.image.tag | string | `"1.3.12"` | image tag |
| mpc.relay.env.RUST_LOG | string | `"{{ include \"defines.logging.loglevel.apps\" . }}"` |  |
| mpc.relay.env.P2P_PORT | string | `"{{ .Values.port }}"` |  |
| mpc.relay.command[0] | string | `"/bin/sh"` |  |
| mpc.relay.command[1] | string | `"-c"` |  |
| mpc.relay.args[0] | string | `"exec /app/relay --port \"$P2P_PORT\" --secret-key-seed \"$SECRET_KEY_SEED\""` |  |
| mpc.relay.secrets.secret-key-seed.enabled | bool | `true` |  |
| mpc.relay.secrets.secret-key-seed.stringData.SECRET_KEY_SEED | string | `"{{ .Values.secret_key_seed }}"` |  |
| mpc.relay.service.main.type | string | `"NodePort"` |  |
| mpc.relay.service.main.ports.http.enabled | bool | `false` | Enables or disables the port |
| mpc.relay.service.main.ports.p2p.enable | bool | `true` |  |
| mpc.relay.service.main.ports.p2p.port | int | `6000` |  |
| mpc.relay.service.main.ports.p2p.targetPort | int | `6000` |  |
| mpc.relay.probes.liveness.type | string | `"TCP"` |  |
| mpc.relay.probes.liveness.port | string | `"p2p"` |  |
| mpc.relay.probes.startup.enabled | bool | `false` |  |
| mpc.relay.probes.readiness.type | string | `"TCP"` |  |
| mpc.relay.probes.readiness.port | string | `"p2p"` |  |
| mpc.relay.resources.requests.memory | string | `"128Mi"` |  |
| mpc.relay.resources.requests.cpu | string | `"200m"` |  |
| postgresql | object | see bellow | Bitnami postgres chart. For more options see <https://github.com/bitnami/charts/tree/master/bitnami/postgresql> |
| postgresql.enabled | bool | `true` | By default uses an internal postgres. Disable if you use your own Postgres. |
| postgresql.auth.username | string | `"postgres"` | Postgres database user name |
| postgresql.auth.postgresPassword | string | `"change_me"` | Postgres admin database password |
| postgresql.auth.password | string | `"change_me"` | Postgres database password |
| postgresql.auth.database | string | `"harmonize"` | Postgres database |
| postgresql.persistence.enabled | bool | `false` | if database is stored to a PVC. Set to true when you are done testing. |
| opentelemetry-collector.enabled | bool | `false` |  |
| opentelemetry-collector.nameOverride | string | `"otlp-collector"` |  |
| opentelemetry-collector.mode | string | `"deployment"` |  |
| opentelemetry-collector.resources.limits.cpu | string | `"512m"` |  |
| opentelemetry-collector.resources.limits.memory | string | `"1024Mi"` |  |
| opentelemetry-collector.ports.syslog.enabled | bool | `true` |  |
| opentelemetry-collector.ports.syslog.containerPort | int | `54526` |  |
| opentelemetry-collector.ports.syslog.servicePort | int | `54526` |  |
| opentelemetry-collector.ports.syslog.hostPort | int | `54526` |  |
| opentelemetry-collector.ports.syslog.protocol | string | `"TCP"` |  |
| opentelemetry-collector.config.exporters.logging.loglevel | string | `"warn"` |  |
| opentelemetry-collector.config.receivers.syslog.tcp.listen_address | string | `"{{ printf \"0.0.0.0:%d\" 54526 }}"` |  |
| opentelemetry-collector.config.receivers.syslog.protocol | string | `"rfc5424"` |  |
| opentelemetry-collector.config.service.pipelines.logs/syslog.receivers[0] | string | `"syslog"` |  |
| opentelemetry-collector.config.service.pipelines.logs/syslog.processors[0] | string | `"batch"` |  |
| opentelemetry-collector.config.service.pipelines.logs/syslog.exporters[0] | string | `"logging"` |  |
| opentelemetry-collector.config.service.pipelines.logs.receivers[0] | string | `"otlp"` |  |
| opentelemetry-collector.config.service.pipelines.logs.processors[0] | string | `"batch"` |  |
| opentelemetry-collector.config.service.pipelines.logs.exporters[0] | string | `"logging"` |  |
| opentelemetry-collector.config.service.pipelines.traces.receivers[0] | string | `"otlp"` |  |
| opentelemetry-collector.config.service.pipelines.traces.processors[0] | string | `"tail_sampling"` |  |
| opentelemetry-collector.config.service.pipelines.traces.exporters[0] | string | `"logging"` |  |
| opentelemetry-collector.config.service.pipelines.metrics.receivers[0] | string | `"otlp"` |  |
| opentelemetry-collector.config.service.pipelines.metrics.processors[0] | string | `"batch"` |  |
| opentelemetry-collector.config.service.pipelines.metrics.exporters[0] | string | `"logging"` |  |
| opentelemetry-collector.config.processors.tail_sampling.decision_wait | string | `"30s"` |  |
| opentelemetry-collector.config.processors.tail_sampling.num_traces | int | `50000` |  |
| opentelemetry-collector.config.processors.tail_sampling.expected_new_traces_per_sec | int | `50` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[0].name | string | `"take-all-domain-related"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[0].type | string | `"string_attribute"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[0].string_attribute.key | string | `"domain-id"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[0].string_attribute.values[0] | string | `".*"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[0].string_attribute.enabled_regex_matching | bool | `true` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[0].string_attribute.cache_max_size | int | `10` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[1].name | string | `"take-all-authenticated-request"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[1].type | string | `"string_attribute"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[1].string_attribute.key | string | `"harmonize.user"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[1].string_attribute.values[0] | string | `".*"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[1].string_attribute.enabled_regex_matching | bool | `true` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[1].string_attribute.cache_max_size | int | `10` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[2].name | string | `"take-all-enforced"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[2].type | string | `"string_attribute"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[2].string_attribute.key | string | `"force-log"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[2].string_attribute.values[0] | string | `".*"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[2].string_attribute.enabled_regex_matching | bool | `true` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[2].string_attribute.cache_max_size | int | `10` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[3].name | string | `"filter-out-target"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[3].type | string | `"string_attribute"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[3].string_attribute.key | string | `"http.target"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[3].string_attribute.values[0] | string | `"/health"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[3].string_attribute.values[1] | string | `"/metrics"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[3].string_attribute.values[2] | string | `"/internal/v1/notary/request"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[3].string_attribute.values[3] | string | `"/internal/v1/manifests/pending"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[3].string_attribute.values[4] | string | `"healthcheck"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[3].string_attribute.enabled_regex_matching | bool | `true` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[3].string_attribute.invert_match | bool | `true` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[4].name | string | `"filter-out-location"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[4].type | string | `"string_attribute"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[4].string_attribute.key | string | `"source.location"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[4].string_attribute.values[0] | string | `"healthcheck"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[4].string_attribute.enabled_regex_matching | bool | `true` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[4].string_attribute.invert_match | bool | `true` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[5].name | string | `"filter-out-already-known-tx-indexer-response"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[5].type | string | `"string_attribute"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[5].string_attribute.key | string | `"payload.response"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[5].string_attribute.values[0] | string | `"(already known)"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[5].string_attribute.enabled_regex_matching | bool | `true` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[5].string_attribute.invert_match | bool | `true` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[6].name | string | `"filter-out-already-known-tx-indexer-error"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[6].type | string | `"string_attribute"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[6].string_attribute.key | string | `"payload.error"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[6].string_attribute.values[0] | string | `"(already known)"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[6].string_attribute.enabled_regex_matching | bool | `true` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[6].string_attribute.invert_match | bool | `true` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[7].name | string | `"take-all-slow"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[7].type | string | `"latency"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[7].latency.threshold_ms | int | `2000` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[8].name | string | `"take-all-errors"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[8].type | string | `"status_code"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[8].status_code.status_codes[0] | string | `"ERROR"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[8].status_code.status_codes[1] | string | `"UNSET"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[9].name | string | `"take-all-failures"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[9].type | string | `"numeric_attribute"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[9].numeric_attribute.key | string | `"otel.status_code"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[9].numeric_attribute.min_value | int | `1` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[9].numeric_attribute.max_value | int | `1000` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[10].name | string | `"take-all-http-not-ok"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[10].type | string | `"numeric_attribute"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[10].numeric_attribute.key | string | `"http.status_code"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[10].numeric_attribute.min_value | int | `203` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[10].numeric_attribute.max_value | int | `1000` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[11].name | string | `"samples-some"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[11].type | string | `"probabilistic"` |  |
| opentelemetry-collector.config.processors.tail_sampling.policies[11].probabilistic.sampling_percentage | float | `0.1` |  |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)
